# -*- coding: utf-8 -*-
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
LOGS = BASE / "logs"
BACKUPS = BASE / "backups"
DATA.mkdir(exist_ok=True)
LOGS.mkdir(exist_ok=True)
BACKUPS.mkdir(exist_ok=True)
DB_FILE = DATA / "sms_manager.db"
