SMS Manager v81 – Rubika API6 dependency fix

- Rubika API6 login remains enabled.
- API6 AES/RSA operations now use PyCryptodome (the same crypto dependency used by Rubpy), so a separate `cryptography` package is NOT required.
- requirements.txt no longer includes cryptography.
- The data/ folder and database are intentionally excluded from this ZIP.

Test: run install.bat if dependencies are needed, then run the application and test Rubika Web -> دریافت کد.
