SMS Manager v71 - Rubika Web Discovery + API6 Diagnostics

Changes:
- Rubika Web authentication no longer uses the legacy fixed API host for the main OTP request.
- First checks getdcmess.iranlms.ir Discovery and DNS reachability.
- Uses Rubpy's API6 crypto/transport stack only after Discovery succeeds, with Web client metadata:
  app_name=Main, app_version=3.2.1, platform=Web, package=web.rubika.ir, lang_code=fa.
- Adds "تشخیص شبکه روبیکا" to show DNS/HTTP status for Discovery and Web.
- Country remains Iran (+98); phone is normalized to 98xxxxxxxxxx.
- No data/SQLite database is included in the ZIP.
- No OTP or session secret is written into the ZIP.

Test order:
1) Replace project files, keeping your existing data folder untouched.
2) Open اتصال حساب روبیکا.
3) Click تشخیص شبکه روبیکا and keep the result if OTP still does not arrive.
4) Then click دریافت کد Web.
