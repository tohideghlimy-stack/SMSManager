@echo off
cd /d "%~dp0"
setlocal
python -m pip install --upgrade pip
if errorlevel 1 goto :pip_error
python -m pip install -r requirements.txt
if errorlevel 1 goto :pip_error

echo.
echo ==============================================
echo SMS Manager dependencies installed successfully.
echo ==============================================
echo.
pause
exit /b 0

:pip_error
echo.
echo [ERROR] Installing dependencies failed.
echo Please check your internet connection and run install.bat again.
pause
exit /b 1
