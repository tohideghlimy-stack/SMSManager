# Local pure-Python crypto helpers for Rubika API6.
# Uses only Python standard library. AES-256-CBC, RSA-1024 OAEP(SHA1), RSA PKCS#1 v1.5(SHA256).
import base64, hashlib, math, os, secrets

SBOX = [
0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16]
INV_SBOX=[0]*256
for i,v in enumerate(SBOX): INV_SBOX[v]=i
RCON=[0,1,2,4,8,16,32,64,128,27,54]

def _xtime(a): return ((a<<1)^ (0x11b if a&0x80 else 0)) & 0xff
def _gmul(a,b):
    r=0
    for _ in range(8):
        if b&1:r^=a
        a=_xtime(a); b>>=1
    return r

def _key_expand(key):
    if len(key)!=32: raise ValueError('AES-256 key must be 32 bytes')
    w=[list(key[i:i+4]) for i in range(0,32,4)]
    for i in range(8,60):
        t=w[i-1][:]
        if i%8==0:
            t=t[1:]+t[:1]; t=[SBOX[x] for x in t]; t[0]^=RCON[i//8]
        elif i%8==4:
            t=[SBOX[x] for x in t]
        w.append([w[i-8][j]^t[j] for j in range(4)])
    return [sum(w[4*r:4*r+4],[]) for r in range(15)]

def _add_round(s,rk):
    return [a^b for a,b in zip(s,rk)]
def _sub(s): return [SBOX[x] for x in s]
def _invsub(s): return [INV_SBOX[x] for x in s]
def _shift(s):
    # column-major AES state
    return [s[0],s[5],s[10],s[15], s[4],s[9],s[14],s[3], s[8],s[13],s[2],s[7], s[12],s[1],s[6],s[11]]
def _invshift(s):
    return [s[0],s[13],s[10],s[7], s[4],s[1],s[14],s[11], s[8],s[5],s[2],s[15], s[12],s[9],s[6],s[3]]
def _mix(s):
    out=[0]*16
    for c in range(4):
        a=s[4*c:4*c+4]
        out[4*c]=_gmul(a[0],2)^_gmul(a[1],3)^a[2]^a[3]
        out[4*c+1]=a[0]^_gmul(a[1],2)^_gmul(a[2],3)^a[3]
        out[4*c+2]=a[0]^a[1]^_gmul(a[2],2)^_gmul(a[3],3)
        out[4*c+3]=_gmul(a[0],3)^a[1]^a[2]^_gmul(a[3],2)
    return out
def _invmix(s):
    out=[0]*16
    for c in range(4):
        a=s[4*c:4*c+4]
        out[4*c]=_gmul(a[0],14)^_gmul(a[1],11)^_gmul(a[2],13)^_gmul(a[3],9)
        out[4*c+1]=_gmul(a[0],9)^_gmul(a[1],14)^_gmul(a[2],11)^_gmul(a[3],13)
        out[4*c+2]=_gmul(a[0],13)^_gmul(a[1],9)^_gmul(a[2],14)^_gmul(a[3],11)
        out[4*c+3]=_gmul(a[0],11)^_gmul(a[1],13)^_gmul(a[2],9)^_gmul(a[3],14)
    return out

def aes_encrypt_block(block,key):
    rks=_key_expand(key); s=_add_round(list(block),rks[0])
    for r in range(1,14): s=_add_round(_mix(_shift(_sub(s))),rks[r])
    return bytes(_add_round(_shift(_sub(s)),rks[14]))
def aes_decrypt_block(block,key):
    rks=_key_expand(key); s=_add_round(list(block),rks[14])
    for r in range(13,0,-1):
        s=_invshift(s); s=_invsub(s); s=_add_round(s,rks[r]); s=_invmix(s)
    s=_invshift(s); s=_invsub(s); s=_add_round(s,rks[0])
    return bytes(s)

def aes_cbc_encrypt(data,key,iv=b'\0'*16):
    pad=16-len(data)%16; data+=bytes([pad])*pad; out=[]; prev=iv
    for i in range(0,len(data),16):
        blk=bytes(a^b for a,b in zip(data[i:i+16],prev)); prev=aes_encrypt_block(blk,key); out.append(prev)
    return b''.join(out)
def aes_cbc_decrypt(data,key,iv=b'\0'*16):
    if len(data)%16: raise ValueError('invalid AES ciphertext length')
    out=[]; prev=iv
    for i in range(0,len(data),16):
        blk=aes_decrypt_block(data[i:i+16],key); out.append(bytes(a^b for a,b in zip(blk,prev))); prev=data[i:i+16]
    raw=b''.join(out); p=raw[-1]
    if not 1<=p<=16 or raw[-p:]!=bytes([p])*p: raise ValueError('invalid AES padding')
    return raw[:-p]

def _i2b(x,n=None):
    if n is None:n=max(1,(x.bit_length()+7)//8)
    return x.to_bytes(n,'big')
def _b2i(b):return int.from_bytes(b,'big')
def _egcd(a,b):
    if b==0:return (a,1,0)
    g,x,y=_egcd(b,a%b); return g,y,x-(a//b)*y
def _inv(a,m):
    g,x,_=_egcd(a,m)
    if g!=1: raise ValueError('inverse unavailable')
    return x%m

def _is_probable_prime(n):
    if n<2:return False
    small=(2,3,5,7,11,13,17,19,23,29,31,37)
    for p in small:
        if n%p==0:return n==p
    d=n-1;s=0
    while d%2==0:s+=1;d//=2
    for a in (2,3,5,7,11,13,17,19,23,29,31):
        if a>=n:continue
        x=pow(a,d,n)
        if x in (1,n-1):continue
        for _ in range(s-1):
            x=pow(x,2,n)
            if x==n-1:break
        else:return False
    return True

def _prime(bits):
    while True:
        n=secrets.randbits(bits)|(1<<(bits-1))|1
        if _is_probable_prime(n):return n

def rsa_generate(bits=1024):
    e=65537
    while True:
        p=_prime(bits//2); q=_prime(bits//2)
        if p==q:continue
        phi=(p-1)*(q-1)
        if math.gcd(e,phi)==1:break
    n=p*q; d=_inv(e,phi)
    return n,e,d,p,q

def _der_len(n):
    if n<128:return bytes([n])
    b=_i2b(n);return bytes([0x80|len(b)])+b
def der_int(x):
    b=_i2b(x)
    if b[0]&0x80:b=b'\0'+b
    return b'\x02'+_der_len(len(b))+b
def der_seq(*parts):
    b=b''.join(parts);return b'\x30'+_der_len(len(b))+b
def pem(label,data):
    enc=base64.b64encode(data).decode(); return '-----BEGIN '+label+'-----\n'+'\n'.join(enc[i:i+64] for i in range(0,len(enc),64))+'\n-----END '+label+'-----\n'
def rsa_private_pem(n,e,d,p,q):
    dp=d%(p-1);dq=d%(q-1);qi=_inv(q,p)
    der=der_seq(*[der_int(x) for x in (0,n,e,d,p,q,dp,dq,qi)])
    return pem('RSA PRIVATE KEY',der)
def rsa_public_pem(n,e):
    # PKCS#1 RSA PUBLIC KEY, matching PyCryptodome export_key(format='PEM')
    return pem('PUBLIC KEY',der_seq(der_seq(b'\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01',b'\x05\x00'), b'\x03'+_der_len(len(der_seq(der_int(n),der_int(e)))+1)+b'\0'+der_seq(der_int(n),der_int(e))))

def _mgf1(seed,n,hashfn=hashlib.sha1):
    out=b''
    for i in range((n+hashfn().digest_size-1)//hashfn().digest_size):out+=hashfn(seed+i.to_bytes(4,'big')).digest()
    return out[:n]
def rsa_oaep_decrypt(n,d,ciphertext,label=b''):
    k=(n.bit_length()+7)//8; h=hashlib.sha1; hs=h().digest_size
    if len(ciphertext)!=k: raise ValueError('RSA ciphertext size mismatch')
    em=_i2b(pow(_b2i(ciphertext),d,n),k)
    if len(em)<2*hs+2 or em[0]!=0:raise ValueError('RSA OAEP decryption failed')
    maskedSeed=em[1:1+hs]; maskedDB=em[1+hs:]
    seed=bytes(a^b for a,b in zip(maskedSeed,_mgf1(maskedDB,hs,h)))
    db=bytes(a^b for a,b in zip(maskedDB,_mgf1(seed,k-hs-1,h)))
    if db[:hs]!=h(label).digest():raise ValueError('RSA OAEP label mismatch')
    try:i=db.index(b'\x01',hs)
    except ValueError:raise ValueError('RSA OAEP decryption failed')
    if any(db[hs:i]):raise ValueError('RSA OAEP decryption failed')
    return db[i+1:]

def rsa_sign_sha256(n,d,data):
    digest=hashlib.sha256(data).digest()
    T=bytes.fromhex('3031300d060960864801650304020105000420')+digest
    k=(n.bit_length()+7)//8
    if len(T)+11>k:raise ValueError('RSA key too small')
    em=b'\0\1'+b'\xff'*(k-len(T)-3)+b'\0'+T
    return _i2b(pow(_b2i(em),d,n),k)

def transform_auth(a):
    out=''
    for c in a:
        if 'a'<=c<='z':out+=chr(((32-(ord(c)-97))%26)+97)
        elif 'A'<=c<='Z':out+=chr(((29-(ord(c)-65))%26)+65)
        elif '0'<=c<='9':out+=chr(((13-(ord(c)-48))%10)+48)
        else:out+=c
    return out

def passphrase(auth):
    if len(auth)!=32:raise ValueError('Rubika key must be 32 chars')
    chunks=[auth[i:i+8] for i in range(0,32,8)]
    s=chunks[2]+chunks[0]+chunks[3]+chunks[1]
    out=''
    for c in s:
        if '0'<=c<='9':out+=chr(((ord(c)-48+5)%10)+48)
        elif 'a'<=c<='z':out+=chr(((ord(c)-97+9)%26)+97)
        elif 'A'<=c<='Z':out+=chr(((ord(c)-65+9)%26)+65)
        else:out+=c
    return out.encode()
