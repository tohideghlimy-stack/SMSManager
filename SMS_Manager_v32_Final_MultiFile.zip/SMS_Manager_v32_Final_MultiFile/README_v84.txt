SMS Manager v84 - Rubika API6 protocol alignment

- API6 envelope aligned with Rubpy 7.3.5: exact JSON serialization, PWA client profile and m.rubika.ir origin/referer.
- Local pure-Python AES/RSA implementation remains; no cryptography/Crypto package required.
- data directory/database intentionally excluded from ZIP.
