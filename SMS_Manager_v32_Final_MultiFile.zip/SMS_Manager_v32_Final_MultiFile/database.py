# -*- coding: utf-8 -*-
import sqlite3, threading
from config import DB_FILE

class DB:
    def __init__(self):
        self._connect()

    def _connect(self):
        self.c = sqlite3.connect(str(DB_FILE), check_same_thread=False)
        self.c.row_factory = sqlite3.Row
        self.lock = threading.Lock()
        self.init()
    def q(self, sql, args=(), many=False):
        with self.lock:
            cur=self.c.cursor()
            if many: cur.executemany(sql,args)
            else: cur.execute(sql,args)
            self.c.commit()
            return cur
    def init(self):
        self.q("""CREATE TABLE IF NOT EXISTS contacts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL DEFAULT '',
            last_name TEXT NOT NULL DEFAULT '',
            mobile TEXT UNIQUE,
            phone TEXT DEFAULT '',
            birth_date TEXT DEFAULT '',
            gender TEXT DEFAULT '',
            email TEXT DEFAULT '',
            company TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        for col, definition in [("rubika_chat_id", "TEXT DEFAULT ''"),("eitaa_chat_id", "TEXT DEFAULT ''"),("bale_chat_id", "TEXT DEFAULT ''"),("rubika_link_code", "TEXT DEFAULT ''")]:
            try: self.q(f'ALTER TABLE contacts ADD COLUMN {col} {definition}')
            except Exception: pass
        for col, definition in [
            ('rubika_chat_id', "TEXT DEFAULT ''"),
            ('eitaa_chat_id', "TEXT DEFAULT ''"),
            ('bale_chat_id', "TEXT DEFAULT ''"),
            ('rubika_link_code', "TEXT DEFAULT ''")]:
            try: self.q(f'ALTER TABLE contacts ADD COLUMN {col} {definition}')
            except Exception: pass
        self.q("""CREATE TABLE IF NOT EXISTS groups(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        self.q("""CREATE TABLE IF NOT EXISTS contact_groups(
            contact_id INTEGER, group_id INTEGER,
            PRIMARY KEY(contact_id,group_id))""")
        self.q("""CREATE TABLE IF NOT EXISTS reminders(
            id INTEGER PRIMARY KEY AUTOINCREMENT, contact_id INTEGER,
            title TEXT NOT NULL, reminder_date TEXT NOT NULL,
            reminder_time TEXT DEFAULT '', notes TEXT DEFAULT '',
            repeat_type TEXT DEFAULT 'بدون تکرار', is_done INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        self.q("""CREATE TABLE IF NOT EXISTS campaigns(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, channel TEXT,
            group_id INTEGER, message TEXT, scheduled_at TEXT DEFAULT '',
            status TEXT DEFAULT 'Draft', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            source_type TEXT DEFAULT 'local_group', source_id INTEGER,
            audience_count INTEGER DEFAULT 0, valid_count INTEGER DEFAULT 0,
            invalid_count INTEGER DEFAULT 0)""")
        for col, ddl in [
            ('source_type', "ALTER TABLE campaigns ADD COLUMN source_type TEXT DEFAULT 'local_group'"),
            ('source_id', 'ALTER TABLE campaigns ADD COLUMN source_id INTEGER'),
            ('audience_count', 'ALTER TABLE campaigns ADD COLUMN audience_count INTEGER DEFAULT 0'),
            ('valid_count', 'ALTER TABLE campaigns ADD COLUMN valid_count INTEGER DEFAULT 0'),
            ('invalid_count', 'ALTER TABLE campaigns ADD COLUMN invalid_count INTEGER DEFAULT 0')]:
            try: self.q(ddl)
            except Exception: pass
        self.q("""CREATE TABLE IF NOT EXISTS campaign_targets(
            id INTEGER PRIMARY KEY AUTOINCREMENT, campaign_id INTEGER NOT NULL,
            source_row_key TEXT DEFAULT '', mobile TEXT DEFAULT '', email TEXT DEFAULT '',
            first_name TEXT DEFAULT '', last_name TEXT DEFAULT '', target TEXT DEFAULT '',
            status TEXT DEFAULT 'Ready', error TEXT DEFAULT '', source_json TEXT DEFAULT '{}',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        self.q("""CREATE TABLE IF NOT EXISTS send_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT, campaign_id INTEGER,
            contact_id INTEGER, channel TEXT, target TEXT, message TEXT,
            status TEXT, error TEXT DEFAULT '', sent_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        self.q("""CREATE TABLE IF NOT EXISTS lotteries(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, question TEXT,
            correct_answer TEXT, start_at TEXT, end_at TEXT,
            winner_count INTEGER DEFAULT 1, status TEXT DEFAULT 'Draft',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        self.q("""CREATE TABLE IF NOT EXISTS lottery_entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT, lottery_id INTEGER,
            mobile TEXT, message TEXT, received_at TEXT,
            is_valid INTEGER DEFAULT 0, UNIQUE(lottery_id,mobile))""")
        self.q("""CREATE TABLE IF NOT EXISTS lottery_winners(
            id INTEGER PRIMARY KEY AUTOINCREMENT, lottery_id INTEGER,
            mobile TEXT, selected_at TEXT)""")
        self.q("""CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT)""")
        self.q("""CREATE TABLE IF NOT EXISTS devices(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, kind TEXT NOT NULL, target TEXT DEFAULT '',
            provider TEXT DEFAULT '', config_json TEXT DEFAULT '{}',
            status TEXT DEFAULT 'Unknown', is_default INTEGER DEFAULT 0,
            enabled INTEGER DEFAULT 1, last_checked TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(kind,target)
        )""")
        self.q("""CREATE TABLE IF NOT EXISTS data_sources(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, db_type TEXT NOT NULL DEFAULT 'sqlserver',
            host TEXT DEFAULT '', port TEXT DEFAULT '', database_name TEXT DEFAULT '',
            username TEXT DEFAULT '', password TEXT DEFAULT '', driver TEXT DEFAULT '',
            connection_string TEXT DEFAULT '', query_text TEXT DEFAULT '',
            mobile_column TEXT DEFAULT '', email_column TEXT DEFAULT '',
            first_name_column TEXT DEFAULT '', last_name_column TEXT DEFAULT '',
            status TEXT DEFAULT 'نیازمند تنظیمات', last_checked TEXT DEFAULT '',
            enabled INTEGER DEFAULT 1, refresh_enabled INTEGER DEFAULT 0, refresh_interval_minutes INTEGER DEFAULT 1440,
            last_refresh TEXT DEFAULT '', next_refresh TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )""")
        # Backward-compatible columns for existing installations
        for col, definition in [
            ('refresh_enabled','INTEGER DEFAULT 0'),
            ('refresh_interval_minutes','INTEGER DEFAULT 1440'),
            ('last_refresh',"TEXT DEFAULT ''"),
            ('next_refresh',"TEXT DEFAULT ''")]:
            try: self.q(f'ALTER TABLE data_sources ADD COLUMN {col} {definition}')
            except Exception: pass
        for k,v in [
            ("sms_provider","Panel API"),("panel_url",""),("panel_api_key",""),
            ("smtp_host",""),("smtp_port","587"),("smtp_user",""),("smtp_password",""),
            ("smtp_ssl","0"),("company_name","SMS Manager"),
            ("default_device_id",""),("gammu_path",""),("adb_path",""),
            ("telegram_bot_token",""),("whatsapp_token",""),("whatsapp_phone_number_id",""),("whatsapp_graph_version","v23.0"),("instagram_token",""),("instagram_user_id",""),("bale_bot_token",""),("bale_test_url",""),("eitaa_token",""),("eitaa_test_url",""),("rubika_token",""),("rubika_test_url",""),("telegram_chat_id",""),("telegram_api_base","https://api.telegram.org"),("whatsapp_business_account_id",""),("whatsapp_webhook_verify_token",""),("instagram_page_id",""),("instagram_graph_version","v23.0"),("bale_chat_id",""),("bale_api_base",""),("bale_webhook",""),("eitaa_chat_id",""),("eitaa_api_base",""),("eitaa_webhook",""),("rubika_chat_id",""),("rubika_api_base",""),("rubika_webhook",""),("rubika_user_session",""),("rubika_user_group_guid","")]: 
            if not self.q("SELECT 1 FROM settings WHERE key=?",(k,)).fetchone():
                self.q("INSERT INTO settings(key,value) VALUES(?,?)",(k,v))
    def get(self,k,default=""):
        r=self.q("SELECT value FROM settings WHERE key=?",(k,)).fetchone()
        return r["value"] if r else default
    def set(self,k,v):
        self.q("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)",(k,str(v)))
