# -*- coding: utf-8 -*-
from datetime import date

JALALI_MONTHS = ["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"]

def gregorian_to_jalali(gy, gm, gd):
    gdm=[31,29 if gy%4==0 and (gy%100!=0 or gy%400==0) else 28,31,30,31,30,31,31,30,31,30,31]
    gy0=gy-1600; gm0=gm-1; gd0=gd-1
    gdn=365*gy0+(gy0+3)//4-(gy0+99)//100+(gy0+399)//400
    gdn += sum(gdm[:gm0])+gd0
    jdn=gdn-79
    jnp=jdn//12053; jdn%=12053
    jy=979+33*jnp+4*(jdn//1461); jdn%=1461
    if jdn>=366:
        jy += (jdn-1)//365; jdn=(jdn-1)%365
    if jdn<186: jm=1+jdn//31; jd=jdn%31+1
    else: jm=7+(jdn-186)//30; jd=(jdn-186)%30+1
    return jy,jm,jd

def jalali_to_gregorian(jy, jm, jd):
    jy0=jy-979
    jdn=365*jy0+(jy0//33)*8+((jy0%33+3)//4)+jd-1
    if jm<7: jdn+=(jm-1)*31
    else: jdn+=(jm-7)*30+186
    gdn=jdn+79
    gy=1600+400*(gdn//146097); gdn%=146097
    leap=True
    if gdn>=36525:
        gdn-=1; gy+=100*(gdn//36524); gdn%=36524
        if gdn>=365: gdn+=1
        else: leap=False
    gy+=4*(gdn//1461); gdn%=1461
    if gdn>=366:
        leap=False; gdn-=1; gy+=gdn//365; gdn%=365
    gdm=[31,29 if leap else 28,31,30,31,30,31,31,30,31,30,31]
    gm=1
    while gdn>=gdm[gm-1]: gdn-=gdm[gm-1]; gm+=1
    return gy,gm,gdn+1

def jalali_to_iso(text):
    text=(text or '').strip().replace('/', '-')
    parts=text.split('-')
    if len(parts)!=3: raise ValueError('تاریخ شمسی باید مانند 1405-01-15 باشد.')
    jy,jm,jd=map(int,parts)
    if not (1<=jm<=12): raise ValueError('ماه شمسی نامعتبر است.')
    maxd=31 if jm<=6 else (30 if jm<=11 else 29)
    if jm==12 and jd==30:
        try: jalali_to_gregorian(jy,12,30)
        except Exception: raise ValueError('روز اسفند نامعتبر است.')
        maxd=30
    if not (1<=jd<=maxd): raise ValueError('روز شمسی نامعتبر است.')
    gy,gm,gd=jalali_to_gregorian(jy,jm,jd)
    return f'{gy:04d}-{gm:02d}-{gd:02d}'

def iso_to_jalali(text):
    text=(text or '').strip()
    try: gy,gm,gd=map(int,text[:10].split('-'))
    except Exception: return text
    jy,jm,jd=gregorian_to_jalali(gy,gm,gd)
    return f'{jy:04d}-{jm:02d}-{jd:02d}'

def jalali_month_days(year, month):
    if month <= 6: return 31
    if month <= 11: return 30
    # Esfand has 29 or 30 days; derive it from the next year's Nowruz.
    try:
        a=jalali_to_gregorian(year,12,1)
        b=jalali_to_gregorian(year+1,1,1)
        from datetime import date

        return (date(*b)-date(*a)).days
    except Exception: return 29
