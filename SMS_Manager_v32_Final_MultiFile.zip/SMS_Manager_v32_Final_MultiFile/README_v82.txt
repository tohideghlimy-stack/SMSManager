SMS Manager v82 - Rubika API6 Self-Contained Crypto

این نسخه برای ورود API6 روبیکا به نصب جداگانه cryptography یا pycryptodome نیاز ندارد.
رمزنگاری AES-256-CBC، RSA-1024/OAEP و RSA PKCS#1 v1.5/SHA-256 در فایل
rubika_crypto_local.py با Python استاندارد داخل پروژه قرار گرفته است.

پوشه data و دیتابیس داخل این ZIP قرار نگرفته و نباید جایگزین شوند.

مسیر تست:
1) برنامه را اجرا کنید.
2) ورود حساب روبیکا/Web را باز کنید.
3) شماره را وارد کنید و دریافت کد Web را بزنید.
4) گزارش کامل مرحله sendCode را بررسی کنید.
5) پس از دریافت OTP، ورود و ذخیره Session را بزنید.
