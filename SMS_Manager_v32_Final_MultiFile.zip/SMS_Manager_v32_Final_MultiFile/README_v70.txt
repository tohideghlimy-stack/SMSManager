SMS Manager v70 - Rubika Web Authentication Bootstrap

Changes:
- Rubika account code request no longer uses Rubpy.
- Uses Web Rubika-style HTTPS sendCode request.
- Country selector is fixed to Iran (+98) for this first phase.
- Iranian phone normalization: 09xxxxxxxxx -> 989xxxxxxxxx.
- Web headers include Origin/Referer web.rubika.ir and fa-IR locale.
- 18 second network timeout with clear error reporting.
- Opens web.rubika.ir from the app for manual comparison.
- No fake session is saved. Full signIn/session crypto remains disabled until the current Web response format is verified.
- Existing database/data folder is intentionally excluded from the release ZIP.

Important:
Country selection changes phone normalization and locale headers only. It does not change the computer's public IP. If the network route must appear from Iran, an Iran-based VPN/proxy is required.
