v79 - Rubika Web Discovery + corrected sendCode headers/envelope. Database/data are intentionally excluded.
