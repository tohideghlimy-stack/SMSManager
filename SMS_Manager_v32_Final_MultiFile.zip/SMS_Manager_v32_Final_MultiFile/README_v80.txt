SMS Manager v80 — Rubika Web API6 OTP/Login

این نسخه API3 legacy را کنار گذاشته و برای ورود حساب روبیکا از مسیر API6 Web استفاده می‌کند:
1) Discovery
2) ساخت tmp_session و رمزنگاری AES-CBC data_enc
3) sendCode با API6
4) پس از OTP: signIn با RSA public key
5) decrypt auth و ذخیره auth + private key در تنظیمات برنامه

مهم:
- پوشه data و دیتابیس در این ZIP وجود ندارد تا اطلاعات قبلی کاربر حفظ شود.
- برای رمزنگاری API6، بسته cryptography به requirements اضافه شده است.
- مقادیر حساس auth/private key در گزارش نمایش داده نمی‌شوند.
