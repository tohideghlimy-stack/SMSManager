SMS Manager v83 - Rubika API6 client-profile fix

این نسخه بر اساس ساختار واقعی Rubpy اصلاح شده است:
- sendCode با API6 و tmp_session باقی مانده است.
- client پیش‌فرض PWA دقیقاً مطابق Rubpy تنظیم شده: Main / 2.4.6 / PWA / m.rubika.ir.
- اگر PWA روی یک سرور رد شود، همان سرور یک بار با client=Web نیز امتحان می‌شود.
- رمزنگاری همچنان فقط با کد داخلی پروژه انجام می‌شود و نصب cryptography یا Crypto لازم نیست.
- پوشه data و دیتابیس عمداً در این ZIP قرار داده نشده‌اند.
