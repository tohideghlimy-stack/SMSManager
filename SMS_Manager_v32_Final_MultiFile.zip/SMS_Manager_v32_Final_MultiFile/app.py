# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import sqlite3, csv, random, smtplib, ssl, socket, threading, time, subprocess, shutil, platform, json, urllib.request, urllib.error, re, zipfile, os, uuid, webbrowser
from pathlib import Path
from datetime import datetime, timedelta
from email.message import EmailMessage
from config import BASE, DATA, LOGS, BACKUPS, DB_FILE
from utils import *
from database import DB

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.db=DB()
        self.app_name=(self.db.get("app_name") or "SMS Manager").strip() or "SMS Manager"
        self.company_name=(self.db.get("company_name") or "").strip()
        self.title(f"{self.app_name} | سامانه مدیریت پیامک، مخاطبین و قرعه‌کشی")
        self.geometry("1380x820"); self.minsize(1120,680); self.configure(bg="#f4f7fb")
        self.backup_stop = threading.Event()
        self.backup_lock = threading.Lock()
        self.backup_thread = None
        self._backup_scheduler_start()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.style=ttk.Style(self)
        try:self.style.theme_use("clam")
        except:pass
        # ---------- UI theme / visual polish ----------
        self.colors={
            "bg":"#f5f7fb","nav":"#0f3557","nav2":"#16466f","primary":"#1677b8",
            "primary_dark":"#0e5f96","accent":"#23a6d5","text":"#17324d","muted":"#6b7c8f",
            "border":"#dbe4ee","card":"#ffffff","soft":"#edf5fb","success":"#16805b",
            "warning":"#b7791f","danger":"#c0392b"
        }
        self.configure(bg=self.colors["bg"])
        self.style.configure("Treeview", background="#ffffff", foreground="#26384a",
                             fieldbackground="#ffffff", rowheight=34, font=("Segoe UI",9))
        self.style.map("Treeview", background=[("selected",self.colors["primary"])],
                       foreground=[("selected","white")])
        self.style.configure("Treeview.Heading", background="#eaf2f9", foreground=self.colors["text"],
                             font=("Tahoma",9,"bold"), relief="flat", padding=(8,9))
        self.style.map("Treeview.Heading", background=[("active","#dcecf8")])
        self.style.configure("TNotebook", background=self.colors["bg"], borderwidth=0)
        self.style.configure("TNotebook.Tab", background="#e8f0f7", foreground=self.colors["text"],
                             padding=(18,9), font=("Tahoma",9,"bold"))
        self.style.map("TNotebook.Tab", background=[("selected",self.colors["primary"])],
                       foreground=[("selected","white")])
        self.style.configure("TCombobox", padding=5, font=("Tahoma",9))
        self.style.configure("TScrollbar", troughcolor="#edf2f7", background="#b9c8d6",
                             bordercolor="#edf2f7", arrowcolor="#526273")
        # Windows-like green progress indicator used by all long-running operations.
        self.style.configure("Green.Horizontal.TProgressbar", troughcolor="#e8edf1",
                             background="#20a464", lightcolor="#20a464", darkcolor="#16804e",
                             bordercolor="#d7e1e8", thickness=16)
        self.sidebar(); self.main=tk.Frame(self,bg=self.colors["bg"]); self.main.pack(side="right",fill="both",expand=True)
        self.show_dashboard()
    def sidebar(self):
        s=tk.Frame(self,bg=self.colors["nav"],width=270);s.pack(side="left",fill="y");s.pack_propagate(False)
        brand=tk.Frame(s,bg=self.colors["nav"]);brand.pack(fill="x",padx=18,pady=(22,18))
        self.brand_title_label=tk.Label(brand,text=self.app_name.upper(),bg=self.colors["nav"],fg="white",font=("Segoe UI",20,"bold"))
        self.brand_title_label.pack(anchor="e")
        self.brand_sub_label=tk.Label(brand,text=(self.company_name or "CRM  •  پیامک  •  مخاطبین"),bg=self.colors["nav"],fg="#a9c2dc",font=("Tahoma",9))
        self.brand_sub_label.pack(anchor="e",pady=(3,0))
        tk.Frame(s,bg="#2a5578",height=1).pack(fill="x",padx=18,pady=(0,12))
        items=[("▦   داشبورد",self.show_dashboard),("◉   مخاطبین و گروه‌ها",self.show_contacts_groups),
               ("◷   یادآوری‌ها",self.show_reminders),("◉   دستگاه‌ها و کانال‌ها",self.show_devices)]
        for t,c in items:
            b=tk.Button(s,text=t,command=c,anchor="e",padx=22,pady=11,relief="flat",bd=0,
                      bg=self.colors["nav"],fg="#f4f8fc",activebackground=self.colors["nav2"],activeforeground="white",
                      font=("Tahoma",10),cursor="hand2")
            b.pack(fill="x",padx=10,pady=2)
            b.bind("<Enter>",lambda e,btn=b: btn.configure(bg=self.colors["nav2"]))
            b.bind("<Leave>",lambda e,btn=b: btn.configure(bg=self.colors["nav"]))
        rest=[("🗄   پایگاه داده شرکت",self.show_data_sources),("✉   کمپین SMS",self.show_sms),("📣   کمپین شبکه‌های داخلی",self.show_internal_campaigns),("✉   ایمیل",self.show_email),
              ("★   قرعه‌کشی",self.show_lottery),("▤   گزارش‌ها",self.show_reports),("💾   پشتیبان‌گیری و بازیابی",self.show_backup),("⚙   تنظیمات",self.show_settings)]
        for t,c in rest:
            b=tk.Button(s,text=t,command=c,anchor="e",padx=22,pady=11,relief="flat",bd=0,
                      bg=self.colors["nav"],fg="#f4f8fc",activebackground=self.colors["nav2"],activeforeground="white",
                      font=("Tahoma",10),cursor="hand2")
            b.pack(fill="x",padx=10,pady=2)
            b.bind("<Enter>",lambda e,btn=b: btn.configure(bg=self.colors["nav2"]))
            b.bind("<Leave>",lambda e,btn=b: btn.configure(bg=self.colors["nav"]))
        footer=tk.Frame(s,bg=self.colors["nav"]);footer.pack(side="bottom",fill="x",padx=18,pady=18)
        tk.Frame(footer,bg="#2a5578",height=1).pack(fill="x",pady=(0,12))
        tk.Label(footer,text="نسخه ۳۲  •  ساده و حرفه‌ای",bg=self.colors["nav"],fg="#9eb5ca",font=("Tahoma",8)).pack(anchor="e")
        tk.Label(footer,text="SQLite + Tkinter",bg=self.colors["nav"],fg="#718da7",font=("Tahoma",8)).pack(anchor="e",pady=(2,0))
    def clear(self):
        for w in self.main.winfo_children():w.destroy()
    def header(self,t,sub=""):
        box=tk.Frame(self.main,bg=self.colors["bg"]);box.pack(fill="x",padx=28,pady=(22,10))
        tk.Label(box,text=t,bg=self.colors["bg"],fg=self.colors["text"],font=("Tahoma",21,"bold")).pack(anchor="e")
        if sub:tk.Label(box,text=sub,bg=self.colors["bg"],fg=self.colors["muted"],font=("Tahoma",9)).pack(anchor="e",pady=(4,0))
    def button(self,p,text,cmd,primary=False):
        bg=self.colors["primary"] if primary else "#ffffff"; fg="white" if primary else self.colors["primary_dark"]
        b=tk.Button(p,text=text,command=cmd,bg=bg,fg=fg,activebackground=self.colors["primary_dark"] if primary else "#edf5fb",
                     activeforeground="white" if primary else self.colors["primary_dark"],relief="flat",bd=0,
                     padx=13,pady=7,font=("Tahoma",9,"bold" if primary else "normal"),cursor="hand2")
        if not primary:
            b.configure(highlightthickness=1,highlightbackground=self.colors["border"],highlightcolor=self.colors["primary"])
        return b
    def card(self,p,title,value):
        f=tk.Frame(p,bg=self.colors["card"],highlightthickness=1,highlightbackground=self.colors["border"])
        f.pack(side="left",fill="both",expand=True,padx=5,ipady=2)
        tk.Label(f,text=str(value),bg=self.colors["card"],fg=self.colors["text"],font=("Segoe UI",20,"bold")).pack(anchor="e",padx=14,pady=(8,0))
        tk.Label(f,text=title,bg=self.colors["card"],fg=self.colors["muted"],font=("Tahoma",8)).pack(anchor="e",padx=14,pady=(0,8))
    def run_with_progress(self, title, task_text, total, worker, done=None):
        """Run a potentially long operation without freezing Tkinter.
        worker(progress, status) runs in a background thread; progress is 0..100.
        done(result, error) is called on the Tk main thread.
        """
        dlg=tk.Toplevel(self)
        dlg.title(title)
        dlg.geometry("560x205")
        dlg.resizable(False,False)
        dlg.configure(bg="white")
        dlg.transient(self)
        dlg.grab_set()
        dlg.protocol("WM_DELETE_WINDOW", lambda: None)
        tk.Label(dlg,text=title,bg="white",fg="#17324d",font=("Tahoma",14,"bold")).pack(anchor="e",padx=28,pady=(24,6))
        status_var=tk.StringVar(value=task_text)
        tk.Label(dlg,textvariable=status_var,bg="white",fg="#5b6b7a",font=("Tahoma",9),anchor="e").pack(fill="x",padx=28,pady=(0,12))
        bar=ttk.Progressbar(dlg,maximum=100,mode="determinate",style="Green.Horizontal.TProgressbar")
        bar.pack(fill="x",padx=28)
        percent_var=tk.StringVar(value="0٪")
        tk.Label(dlg,textvariable=percent_var,bg="white",fg="#16804e",font=("Segoe UI",11,"bold")).pack(anchor="e",padx=28,pady=(7,0))
        dlg.update_idletasks()

        def progress(value, text=None):
            value=max(0,min(100,float(value)))
            def ui():
                if not dlg.winfo_exists(): return
                bar['value']=value
                percent_var.set(f"{int(value)}٪")
                if text: status_var.set(text)
                dlg.update_idletasks()
            self.after(0,ui)

        def finish(result=None, error=None):
            try: dlg.grab_release()
            except Exception: pass
            try: dlg.destroy()
            except Exception: pass
            if done: done(result,error)

        def runner():
            try:
                result=worker(progress)
                self.after(0,lambda: finish(result,None))
            except Exception as e:
                self.after(0,lambda: finish(None,e))
        threading.Thread(target=runner,daemon=True).start()
    def birthday_contacts_today(self):
        """Return contacts whose Jalali birth month/day matches today's Jalali month/day."""
        now=datetime.now()
        _, jm, jd = gregorian_to_jalali(now.year, now.month, now.day)
        rows=self.db.c.execute("SELECT id,first_name,last_name,mobile,birth_date FROM contacts WHERE birth_date IS NOT NULL AND birth_date!='' ORDER BY first_name,last_name").fetchall()
        out=[]
        for r in rows:
            try:
                by,bm,bd=map(int, iso_to_jalali(r['birth_date']).split('-'))
                if bm==jm and bd==jd:
                    out.append(r)
            except Exception:
                continue
        return out, (jm,jd)

    def _reminder_date_to_gregorian(self, text):
        """Accept ISO/Gregorian or Jalali dates and return (gy,gm,gd)."""
        raw=(text or '').strip().replace('/', '-')
        parts=raw[:10].split('-')
        if len(parts)!=3:
            return None
        try:
            y,m,d=map(int,parts)
            if 1200 <= y <= 1600:
                return jalali_to_gregorian(y,m,d)
            return y,m,d
        except Exception:
            return None

    def reminders_due_today(self):
        """Return active reminders that are due today, including recurring reminders."""
        now=datetime.now()
        gy,gm,gd=now.year,now.month,now.day
        jy,jm,jd=gregorian_to_jalali(gy,gm,gd)
        today=(gy,gm,gd)
        rows=self.db.c.execute("""
            SELECT r.*, c.first_name, c.last_name, c.mobile, c.email
            FROM reminders r JOIN contacts c ON c.id=r.contact_id
            WHERE COALESCE(r.is_done,0)=0
            ORDER BY r.reminder_date, r.reminder_time, c.first_name, c.last_name
        """).fetchall()
        out=[]
        for r in rows:
            start=self._reminder_date_to_gregorian(r['reminder_date'])
            if not start:
                continue
            repeat=(r['repeat_type'] or 'بدون تکرار').strip()
            due=False; status='امروز'
            if repeat in ('بدون تکرار',''):
                due = start == today
                if start < today:
                    due=True; status='عقب‌افتاده'
            elif repeat == 'روزانه':
                due = start <= today
            elif repeat == 'هفتگی':
                due = start <= today and start[0:3] != (0,0,0) and datetime(*today).weekday() == datetime(*start).weekday()
            elif repeat == 'ماهانه':
                due = start <= today and gd == start[2]
            elif repeat == 'سالانه':
                due = start <= today and gm == start[1] and gd == start[2]
            else:
                # Future/custom values remain visible only when their date is today.
                due = start == today
            if due:
                item=dict(r)
                item['due_status']=status
                item['date_jalali']=iso_to_jalali(f'{start[0]:04d}-{start[1]:02d}-{start[2]:02d}')
                out.append(item)
        return out, (jy,jm,jd)

    def show_reminders_today(self):
        rows,(jy,jm,jd)=self.reminders_due_today()
        w=tk.Toplevel(self); w.title('🔔 یادآوری‌های امروز'); w.geometry('1050x650'); w.minsize(780,520); w.configure(bg='#f4f7fb'); w.transient(self)
        tk.Label(w,text='🔔 یادآوری‌ها و هشدارهای امروز',bg='#f4f7fb',fg='#17324d',font=('Tahoma',18,'bold')).pack(anchor='e',padx=25,pady=(20,4))
        tk.Label(w,text=f'{JALALI_MONTHS[jm-1]} {jd:02d} {jy:04d} — شامل یادآوری‌های تکرارشونده و موارد عقب‌افتاده',bg='#f4f7fb',fg='#6b7c8f',font=('Tahoma',9)).pack(anchor='e',padx=25,pady=(0,12))
        top=tk.Frame(w,bg='white',highlightthickness=1,highlightbackground='#dbe4ee'); top.pack(fill='x',padx=25,pady=5)
        tk.Label(top,text=f'موارد قابل پیگیری: {len(rows):,}',bg='white',fg='#1769aa',font=('Tahoma',11,'bold')).pack(anchor='e',padx=18,pady=12)
        cols=('contact','mobile','title','date','time','repeat','status','notes')
        tr=ttk.Treeview(w,columns=cols,show='headings')
        for c,t,ww in [('contact','مخاطب',190),('mobile','موبایل',130),('title','عنوان',190),('date','تاریخ',110),('time','ساعت',75),('repeat','تکرار',95),('status','وضعیت',95),('notes','یادداشت',260)]:
            tr.heading(c,text=t); tr.column(c,width=ww,anchor='center')
        sb=ttk.Scrollbar(w,orient='vertical',command=tr.yview); tr.configure(yscrollcommand=sb.set)
        tr.pack(side='left',fill='both',expand=True,padx=(25,0),pady=10); sb.pack(side='right',fill='y',padx=(0,25),pady=10)
        for r in rows:
            tr.insert('', 'end', values=(f"{r['first_name']} {r['last_name']}",r['mobile'],r['title'],r['date_jalali'],r['reminder_time'] or '—',r['repeat_type'] or 'بدون تکرار',r['due_status'],r['notes'] or ''))
        actions=tk.Frame(w,bg='#f4f7fb'); actions.pack(fill='x',padx=25,pady=(0,18))
        def selected_contacts():
            ids=[rows[int(i)] for i in tr.selection() if str(i).isdigit() and int(i)<len(rows)]
            return ids
        def prepare_sms():
            chosen=selected_contacts() or rows
            if not chosen:
                messagebox.showinfo('یادآوری‌ها','برای امروز یادآوری فعالی وجود ندارد.',parent=w); return
            now=datetime.now(); _,tm,td=gregorian_to_jalali(now.year,now.month,now.day)
            group_name=f'🔔 یادآوری {tm:02d}/{td:02d}'
            gr=self.db.c.execute('SELECT id FROM groups WHERE name=?',(group_name,)).fetchone()
            if gr: gid=gr['id']
            else:
                self.db.q('INSERT INTO groups(name,description) VALUES(?,?)',(group_name,'گروه خودکار یادآوری‌های امروز برای آماده‌سازی پیامک'))
                gid=self.db.c.execute('SELECT id FROM groups WHERE name=?',(group_name,)).fetchone()['id']
            self.db.q('DELETE FROM contact_groups WHERE group_id=?',(gid,))
            for r in chosen:
                self.db.q('INSERT OR IGNORE INTO contact_groups(contact_id,group_id) VALUES(?,?)',(r['contact_id'],gid))
            w.destroy(); self.campaign_page('SMS',preselect_group_id=gid,prefill_message='سلام، این یک یادآوری از طرف مجموعه ماست.')
        self.button(actions,'📱 آماده‌سازی پیامک برای موارد انتخاب‌شده',prepare_sms,True).pack(side='right',padx=3)
        self.button(actions,'بستن',w.destroy).pack(side='left',padx=3)
        if not rows:
            tk.Label(w,text='امروز یادآوری یا هشدار فعالی وجود ندارد.',bg='white',fg='#718096',font=('Tahoma',10)).place(relx=.5,rely=.5,anchor='center')

    def show_birthday_today(self):
        rows,(jm,jd)=self.birthday_contacts_today()
        w=tk.Toplevel(self); w.title("🎂 متولدین امروز"); w.geometry("850x620"); w.minsize(700,500); w.configure(bg="#f4f7fb"); w.transient(self)
        tk.Label(w,text="🎂 متولدین امروز",bg="#f4f7fb",fg="#17324d",font=("Tahoma",18,"bold")).pack(anchor="e",padx=25,pady=(20,4))
        tk.Label(w,text=f"تولدهای {JALALI_MONTHS[jm-1]} {jd:02d} — بدون توجه به سال تولد",bg="#f4f7fb",fg="#6b7c8f",font=("Tahoma",9)).pack(anchor="e",padx=25,pady=(0,12))
        top=tk.Frame(w,bg="white",highlightthickness=1,highlightbackground="#dbe4ee"); top.pack(fill="x",padx=25,pady=5)
        tk.Label(top,text=f"تعداد متولدین امروز: {len(rows):,} نفر",bg="white",fg="#1769aa",font=("Tahoma",11,"bold")).pack(anchor="e",padx=18,pady=12)
        cols=("name","mobile","birth")
        tr=ttk.Treeview(w,columns=cols,show="headings",selectmode="extended")
        for c,t,ww in [("name","نام و نام خانوادگی",300),("mobile","موبایل",180),("birth","تاریخ تولد",150)]:
            tr.heading(c,text=t); tr.column(c,width=ww,anchor="center")
        sb=ttk.Scrollbar(w,orient="vertical",command=tr.yview); tr.configure(yscrollcommand=sb.set)
        tr.pack(side="left",fill="both",expand=True,padx=(25,0),pady=10); sb.pack(side="right",fill="y",padx=(0,25),pady=10)
        for r in rows:
            tr.insert("","end",iid=str(r['id']),values=(f"{r['first_name']} {r['last_name']}",r['mobile'],iso_to_jalali(r['birth_date'])))
        actions=tk.Frame(w,bg="#f4f7fb"); actions.pack(fill="x",padx=25,pady=(0,18))
        def prepare_sms():
            if not rows:
                messagebox.showinfo("متولدین امروز","امروز مخاطب متولدشده‌ای پیدا نشد.",parent=w); return
            now=datetime.now(); _,tm,td=gregorian_to_jalali(now.year,now.month,now.day)
            group_name=f"🎂 تولد {tm:02d}/{td:02d}"
            gr=self.db.c.execute("SELECT id FROM groups WHERE name=?",(group_name,)).fetchone()
            if gr: gid=gr['id']
            else:
                self.db.q("INSERT INTO groups(name,description) VALUES(?,?)",(group_name,"گروه خودکار متولدین امروز برای آماده‌سازی پیامک"))
                gid=self.db.c.execute("SELECT id FROM groups WHERE name=?",(group_name,)).fetchone()['id']
            self.db.q("DELETE FROM contact_groups WHERE group_id=?",(gid,))
            for r in rows:
                self.db.q("INSERT OR IGNORE INTO contact_groups(contact_id,group_id) VALUES(?,?)",(r['id'],gid))
            w.destroy(); self.campaign_page("SMS",preselect_group_id=gid,prefill_message="تولدتان مبارک! 🌷🎂 آرزومندیم سالی سرشار از سلامتی، شادی و موفقیت داشته باشید.")
        self.button(actions,"📱 آماده‌سازی پیامک تولد",prepare_sms,True).pack(side="right",padx=3)
        self.button(actions,"بستن",w.destroy).pack(side="left",padx=3)
        if not rows:
            tk.Label(w,text="امروز موردی پیدا نشد.",bg="#ffffff",fg="#718096",font=("Tahoma",10)).place(relx=.5,rely=.5,anchor="center")

    def show_dashboard(self):
        self.clear(); self.header("داشبورد", "مرکز کنترل سریع سامانه")
        c=self.db.c
        jy,jm,jd=gregorian_to_jalali(datetime.now().year,datetime.now().month,datetime.now().day)

        # نوار بالایی: تاریخ + دسترسی سریع در یک ردیف جمع‌وجور
        top=tk.Frame(self.main,bg=self.colors['bg']); top.pack(fill='x',padx=24,pady=(0,6))
        tk.Label(top,text=f"امروز {jy:04d}/{jm:02d}/{jd:02d} | {JALALI_MONTHS[jm-1]}",
                 bg='#eaf3fb',fg='#1769aa',font=('Tahoma',8,'bold'),padx=10,pady=4).pack(side='right')
        self.button(top,"🔄 بروزرسانی",self.show_dashboard).pack(side='left',padx=2)

        # دسترسی سریع — کنار تاریخ، برای دسترسی فوری بدون اشغال یک ردیف جدا
        qa=tk.Frame(top,bg=self.colors['bg'])
        qa.pack(side='left',padx=(8,0))
        tk.Label(qa,text='⚡',bg=self.colors['bg'],fg='#17324d',font=('Tahoma',9,'bold')).pack(side='right',padx=(2,4))
        for text,cmd in [("➕ مخاطب",self.add_contact), ("📨 SMS",lambda:self.campaign_page('SMS')), ("📧 ایمیل",lambda:self.campaign_page('EMAIL')), ("📢 کمپین",lambda:self.campaign_page('SMS')), ("⚙ ارتباطات",self.show_devices)]:
            self.button(qa,text,cmd).pack(side='right',padx=1,pady=0)

        # اینترنت / VPN / Proxy — یک ردیف باریک
        self._dashboard_network_card(self.main, compact=True)

        # KPI های اصلی — کوتاه و جمع و جور
        vals=[("مخاطبین","SELECT COUNT(*) n FROM contacts"),
              ("گروه‌ها","SELECT COUNT(*) n FROM groups"),
              ("کمپین‌ها","SELECT COUNT(*) n FROM campaigns"),
              ("یادآوری فعال","SELECT COUNT(*) n FROM reminders WHERE is_done=0")]
        row=tk.Frame(self.main,bg=self.colors['bg']); row.pack(fill='x',padx=20,pady=(0,6))
        for title,sql in vals: self.card(row,title,c.execute(sql).fetchone()['n'])

        # کانال‌های واقعی
        self._dashboard_compact_channels(self.main)

        # نمودارها عمداً بلافاصله بعد از دسترسی سریع قرار گرفته‌اند تا در صفحه اول دیده شوند.
        self._dashboard_mini_charts(self.main, vals)

        # تولد و یادآوری — اطلاعات ثانویه، کم‌ارتفاع
        birthday_rows,_=self.birthday_contacts_today()
        reminder_rows,_=self.reminders_due_today()
        info=tk.Frame(self.main,bg=self.colors['bg']); info.pack(fill='x',padx=20,pady=(0,7))
        bday=tk.Frame(info,bg='#fff8ed',highlightthickness=1,highlightbackground='#f2d39b')
        bday.pack(side='right',fill='both',expand=True,padx=(4,0))
        tk.Label(bday,text=f"🎂 تولد امروز {len(birthday_rows):,}",bg='#fff8ed',fg='#9a5b00',font=('Tahoma',9,'bold')).pack(anchor='e',padx=10,pady=(5,1))
        preview="، ".join(f"{r['first_name']} {r['last_name']}" for r in birthday_rows[:2]) or "موردی ثبت نشده است."
        tk.Label(bday,text=preview,bg='#fff8ed',fg='#8a6a3d',font=('Tahoma',7)).pack(anchor='e',padx=10,pady=(0,5))
        self.button(bday,"مشاهده",self.show_birthday_today).pack(side='left',padx=8,pady=4)

        rem=tk.Frame(info,bg='#eef8f4',highlightthickness=1,highlightbackground='#b9ddcd')
        rem.pack(side='left',fill='both',expand=True,padx=(0,4))
        tk.Label(rem,text=f"🔔 یادآوری امروز {len(reminder_rows):,}",bg='#eef8f4',fg='#16734b',font=('Tahoma',9,'bold')).pack(anchor='e',padx=10,pady=(5,1))
        preview_r="، ".join(f"{r['first_name']} {r['last_name']} — {r['title']}" for r in reminder_rows[:2]) or "موردی ثبت نشده است."
        tk.Label(rem,text=preview_r,bg='#eef8f4',fg='#47715f',font=('Tahoma',7)).pack(anchor='e',padx=10,pady=(0,5))
        self.button(rem,"مشاهده",self.show_reminders_today).pack(side='left',padx=8,pady=4)

    def _dashboard_mini_charts(self, parent, vals):
        """Two compact, real-data charts kept above the fold."""
        c=self.db.c
        chart_area=tk.Frame(parent,bg=self.colors['bg']); chart_area.pack(fill='x',padx=20,pady=(0,7))

        # Chart 1: main system statistics
        left=tk.Frame(chart_area,bg='white',highlightthickness=1,highlightbackground='#dbe4ee')
        left.pack(side='left',fill='both',expand=True,padx=(0,4))
        tk.Label(left,text='آمار اصلی سامانه',bg='white',fg='#17324d',font=('Tahoma',9,'bold')).pack(anchor='e',padx=10,pady=(5,1))
        cv=tk.Canvas(left,bg='white',highlightthickness=0,height=105)
        cv.pack(fill='x',padx=7,pady=(0,4))
        labels=[x[0] for x in vals]
        numbers=[int(c.execute(x[1]).fetchone()['n'] or 0) for x in vals]
        def draw_bars(event=None):
            cv.delete('all'); w=max(cv.winfo_width(),330); h=105; mx=max(numbers+[1]);
            gap=12; bw=max(28,(w-gap*5)//4); base=78
            for i,(lab,num) in enumerate(zip(labels,numbers)):
                x=8+i*(bw+gap); bh=int(48*(num/mx)) if mx else 0; y=base-bh
                cv.create_rectangle(x,y,x+bw,base,fill='#1769aa',outline='')
                cv.create_text(x+bw/2,max(y-7,7),text=str(num),font=('Segoe UI',8,'bold'),fill='#17324d')
                cv.create_text(x+bw/2,95,text=lab,font=('Tahoma',6),fill='#526273')
        cv.bind('<Configure>',draw_bars); draw_bars()

        # Chart 2: real channel readiness
        right=tk.Frame(chart_area,bg='white',highlightthickness=1,highlightbackground='#dbe4ee')
        right.pack(side='right',fill='both',expand=True,padx=(4,0))
        tk.Label(right,text='وضعیت کانال‌ها',bg='white',fg='#17324d',font=('Tahoma',9,'bold')).pack(anchor='e',padx=10,pady=(5,1))
        cv2=tk.Canvas(right,bg='white',highlightthickness=0,height=105)
        cv2.pack(fill='x',padx=7,pady=(0,4))
        rows=[dict(r) for r in self._device_list()]
        groups=[('SMS',{'android','gsm','serial'}),('ایمیل',{'email'}),('پنل',{'panel'}),('داخلی',{'bale','eitaa','rubika'}),('خارجی',{'telegram','whatsapp','instagram'})]
        data=[]
        for label,kinds in groups:
            matched=[r for r in rows if r.get('kind') in kinds]; total=len(matched)
            ready=sum(1 for r in matched if str(r.get('status','')).strip().lower() in ('آماده','متصل','فعال','موفق','ready','connected','ok'))
            data.append((label,total,ready))
        def draw_channels(event=None):
            cv2.delete('all'); w=max(cv2.winfo_width(),330); x0=8; usable=w-16; row_h=18
            max_total=max([x[1] for x in data]+[1]);
            for i,(lab,total,ready) in enumerate(data):
                y=8+i*18
                cv2.create_text(x0,y+6,text=lab,font=('Tahoma',6,'bold'),fill='#526273',anchor='w')
                bx=x0+43; bw=max(70,usable-43);
                cv2.create_rectangle(bx,y,bx+bw,y+11,fill='#edf2f7',outline='')
                if total:
                    rw=int(bw*(ready/total)); cv2.create_rectangle(bx,y,bx+rw,y+11,fill='#20a464' if ready==total else '#e2a33b',outline='')
                cv2.create_text(bx+bw+2,y+6,text=f'{ready}/{total}',font=('Segoe UI',7,'bold'),fill='#17324d',anchor='w')
        cv2.bind('<Configure>',draw_channels); draw_channels()

    def _dashboard_compact_channels(self, parent):
        """Compact live cards using the real enabled device/channel records."""
        rows=[dict(r) for r in self._device_list()]
        groups=[
            ('📱','SMS','android,gsm,serial'),
            ('📧','ایمیل','email'),
            ('🌐','پنل SMS','panel'),
            ('🇮🇷','داخلی','bale,eitaa,rubika'),
            ('🌍','خارجی','telegram,whatsapp,instagram')]
        box=tk.Frame(parent,bg=self.colors['bg']); box.pack(fill='x',padx=20,pady=(0,7))
        for icon,title,kinds_text in groups:
            kinds=set(kinds_text.split(',')); matched=[r for r in rows if r.get('kind') in kinds]
            total=len(matched)
            ready=sum(1 for r in matched if str(r.get('status','')).strip().lower() in ('آماده','متصل','فعال','موفق','ready','connected','ok'))
            if total==0: state='بدون تنظیم'; fg='#718096'; bg='#f8fafc'; value='—'
            elif ready==total: state='متصل'; fg='#16734b'; bg='#eef8f4'; value=f'{ready}/{total}'
            elif ready>0: state='نیازمند بررسی'; fg='#b45309'; bg='#fff7ed'; value=f'{ready}/{total}'
            else: state='نیازمند بررسی'; fg='#b42318'; bg='#fff1f2'; value=f'0/{total}'
            card=tk.Frame(box,bg=bg,highlightthickness=1,highlightbackground='#dbe4ee')
            card.pack(side='left',fill='both',expand=True,padx=3)
            tk.Label(card,text=f'{icon} {title}',bg=bg,fg='#17324d',font=('Tahoma',7,'bold')).pack(anchor='e',padx=7,pady=(5,0))
            tk.Label(card,text=value,bg=bg,fg=fg,font=('Segoe UI',15,'bold')).pack(anchor='e',padx=7)
            tk.Label(card,text=state,bg=bg,fg=fg,font=('Tahoma',6)).pack(anchor='e',padx=7,pady=(0,5))

    def _dashboard_channels_card(self, parent):
        box=tk.Frame(parent,bg="white",highlightthickness=1,highlightbackground="#dbe4ee")
        box.pack(fill="x",padx=28,pady=(0,10))
        head=tk.Frame(box,bg="white"); head.pack(fill="x",padx=16,pady=(12,5))
        tk.Label(head,text="📡 وضعیت واقعی دستگاه‌ها و کانال‌های ارتباطی",bg="white",fg="#17324d",font=("Tahoma",12,"bold")).pack(side="right")
        status=tk.StringVar(value="⏳ در حال بررسی دستگاه‌ها و کانال‌ها...")
        detail=tk.StringVar(value="لطفاً چند لحظه صبر کنید.")
        tk.Label(head,textvariable=status,bg="white",fg="#526273",font=("Tahoma",10,"bold")).pack(side="left")
        tk.Label(box,textvariable=detail,bg="#f7fafc",fg="#526273",font=("Tahoma",9),justify="right",anchor="e",wraplength=1000,padx=14,pady=9).pack(fill="x",padx=16,pady=(0,8))
        actions=tk.Frame(box,bg="white"); actions.pack(fill="x",padx=16,pady=(0,10))
        self.button(actions,"🔄 بررسی مجدد کانال‌ها",lambda:self._dashboard_channels_check(status,detail)).pack(side="right")
        def worker():
            try:
                devices=self.detect_devices()
                groups=[("📱 دستگاه‌های پیامک",('android','gsm','serial')),('📧 ایمیل',('email',)),('🌐 پنل پیامکی',('panel',)),('🇮🇷 شبکه‌های اجتماعی داخلی',('internal',)),('🌍 شبکه‌های اجتماعی خارجی',('external',))]
                parts=[]; total=len(devices)
                for label,kinds in groups:
                    rows=[d for d in devices if d.get('kind') in kinds]
                    ready=sum(1 for d in rows if str(d.get('status','')).lower() in ('آماده','متصل','فعال','ready','connected'))
                    configured=len(rows)-ready
                    parts.append(f"{label}: {len(rows)} مورد | آماده/متصل: {ready} | نیازمند بررسی: {configured}")
                text=f"تعداد کل: {total} مورد\n" + "\n".join(parts)
                self.after(0,lambda:(status.set(f"🟢 بررسی انجام شد — {total} کانال/دستگاه"),detail.set(text)))
            except Exception as e:
                self.after(0,lambda:(status.set("🔴 خطا در بررسی کانال‌ها"),detail.set("جزئیات: "+str(e)[:180])))
        threading.Thread(target=worker,daemon=True).start()

    def _dashboard_channels_card(self, parent):
        """Show live configured channel counts and their last known statuses."""
        box=tk.Frame(parent,bg='white',highlightthickness=1,highlightbackground='#dbe4ee')
        box.pack(fill='x',padx=28,pady=(0,10))
        tk.Label(box,text='📡 وضعیت واقعی دستگاه‌ها و کانال‌های ارتباطی',bg='white',fg='#17324d',font=('Tahoma',12,'bold')).pack(anchor='e',padx=16,pady=(12,8))
        body=tk.Frame(box,bg='white'); body.pack(fill='x',padx=12,pady=(0,10))
        groups=[('📱 دستگاه‌های پیامک',('android','gsm','serial')),('📧 ایمیل',('email',)),('🌐 پنل پیامکی',('panel',)),('🇮🇷 شبکه‌های اجتماعی داخلی',('bale','eitaa','rubika')),('🌍 شبکه‌های اجتماعی خارجی',('telegram','whatsapp','instagram'))]
        rows=[dict(r) for r in self._device_list()]
        for title,kinds in groups:
            matched=[r for r in rows if r.get('kind') in kinds]
            total=len(matched)
            ready=sum(1 for r in matched if any(x in str(r.get('status','')).lower() for x in ('آماده','متصل','موفق','ready','connected','ok')))
            failed=total-ready
            txt=f'{title}   |   تعداد: {total}   |   آماده/موفق: {ready}   |   نیازمند بررسی: {failed}'
            fg='#16734b' if total and failed==0 else ('#b45309' if total else '#718096')
            tk.Label(body,text=txt,bg='white',fg=fg,font=('Tahoma',9,'bold'),anchor='e',justify='right').pack(fill='x',padx=8,pady=3)
        tk.Label(box,text='این آمار از کانال‌های ثبت‌شده و آخرین وضعیت واقعی ذخیره‌شده در برنامه خوانده می‌شود؛ برای به‌روزرسانی وضعیت، از بخش «دستگاه‌ها و کانال‌ها» تست اتصال بگیرید.',bg='#f7fafc',fg='#64748b',font=('Tahoma',8),anchor='e',justify='right',wraplength=1000,padx=12,pady=7).pack(fill='x',padx=12,pady=(0,10))

    def _dashboard_network_check(self, status_var, detail_var, dot_label):
        """Non-blocking dashboard network/VPN/Proxy status check."""
        def worker():
            internet_ok=False; internet_detail=''
            try:
                req=urllib.request.Request('https://www.google.com/generate_204', method='GET', headers={'User-Agent':'SMSManager/1.0'})
                with urllib.request.urlopen(req, timeout=7) as r:
                    internet_ok = int(getattr(r,'status',204)) < 500
                internet_detail='اتصال اینترنت برقرار است.'
            except Exception as e:
                internet_detail='اتصال اینترنت برقرار نشد: '+str(e)[:90]
            proxy_cfg=self._proxy_cfg()
            proxy_state='غیرفعال'
            proxy_detail='اتصال مستقیم سیستم استفاده می‌شود.'
            if proxy_cfg.get('enabled'):
                try:
                    sock=self._proxy_socket('www.google.com',443,timeout=8); sock.close()
                    proxy_state='فعال و قابل استفاده'
                    proxy_detail=f"Proxy {proxy_cfg.get('type','')} روی {proxy_cfg.get('host')}:{proxy_cfg.get('port')} پاسخ می‌دهد."
                except Exception as e:
                    proxy_state='فعال ولی ناموفق'
                    proxy_detail='Proxy تنظیم شده ولی تست آن ناموفق بود: '+str(e)[:90]
            vpn_state='نامشخص'
            vpn_detail='وضعیت VPN سیستم به‌صورت قطعی قابل تشخیص نیست.'
            if platform.system().lower().startswith('win'):
                try:
                    out=subprocess.check_output(['powershell','-NoProfile','-Command',
                        "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | Select-Object -ExpandProperty InterfaceDescription"],
                        text=True, stderr=subprocess.DEVNULL, timeout=4)
                    names=out.lower()
                    keys=('wireguard','wintun','openvpn','tap-windows','clash','nekoray','v2ray','sing-box','tailscale','zerotier','cisco anyconnect','fortinet','globalprotect','hamachi')
                    hits=[k for k in keys if k in names]
                    if hits:
                        vpn_state='احتمالاً متصل'
                        vpn_detail='رابط شبکه مرتبط با VPN/تونل شناسایی شد: '+', '.join(hits[:3])
                    else:
                        vpn_state='شناسایی نشد'
                        vpn_detail='رابط شناخته‌شده VPN پیدا نشد؛ ممکن است VPN از نوع دیگری باشد.'
                except Exception:
                    pass
            def update():
                try:
                    status_var.set('🟢 اینترنت متصل' if internet_ok else '🔴 اینترنت قطع')
                    dot_label.configure(fg=self.colors['success'] if internet_ok else self.colors['danger'])
                    detail_var.set(f"{internet_detail}  |  Proxy: {proxy_state}  |  VPN سیستم: {vpn_state}\n{proxy_detail}  {vpn_detail}")
                except tk.TclError:
                    pass
            self.after(0,update)
        threading.Thread(target=worker,daemon=True).start()

    def _dashboard_network_check(self, status_var, detail_var, dot_label):
        """Non-blocking network status check. VPN detection is informational only."""
        def worker():
            internet_ok=False; internet_detail=''
            try:
                req=urllib.request.Request('https://www.google.com/generate_204', method='GET', headers={'User-Agent':'SMSManager/1.0'})
                with urllib.request.urlopen(req, timeout=7) as r:
                    internet_ok=int(getattr(r,'status',204))<500
                internet_detail='اینترنت برقرار است.'
            except Exception as e:
                internet_detail='اینترنت در دسترس نیست: '+str(e)[:90]
            cfg=self._proxy_cfg(); proxy_state='خاموش'; proxy_detail='اتصال مستقیم سیستم فعال است.'
            if cfg.get('enabled'):
                try:
                    sock=self._proxy_socket('www.google.com',443,timeout=8); sock.close()
                    proxy_state='متصل'; proxy_detail=f"Proxy {cfg.get('type','')} {cfg.get('host')}:{cfg.get('port')} پاسخ می‌دهد."
                except Exception as e:
                    proxy_state='خطا'; proxy_detail='Proxy تنظیم شده ولی پاسخ نداد: '+str(e)[:90]
            vpn_state='نامشخص'
            if platform.system().lower().startswith('win'):
                try:
                    out=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | Select-Object -ExpandProperty InterfaceDescription"],text=True,stderr=subprocess.DEVNULL,timeout=4)
                    keys=('wireguard','wintun','openvpn','tap-windows','clash','nekoray','v2ray','sing-box','tailscale','zerotier','cisco anyconnect','fortinet','globalprotect','hamachi')
                    vpn_state='احتمالاً متصل' if any(k in out.lower() for k in keys) else 'شناسایی نشد'
                except Exception: pass
            def update():
                try:
                    status_var.set('🟢 اینترنت' if internet_ok else '🔴 اینترنت')
                    dot_label.configure(fg=self.colors['success'] if internet_ok else self.colors['danger'])
                    detail_var.set(f"{internet_detail}  |  Proxy: {proxy_state}  |  VPN: {vpn_state}")
                except tk.TclError: pass
            self.after(0,update)
        threading.Thread(target=worker,daemon=True).start()

    def _dashboard_network_card(self, parent, compact=False):
        box=tk.Frame(parent,bg='white',highlightthickness=1,highlightbackground='#dbe4ee')
        box.pack(fill='x',padx=28 if compact else 28,pady=(0,9))
        row=tk.Frame(box,bg='white'); row.pack(fill='x',padx=12,pady=7)
        tk.Label(row,text='🌐 اتصال',bg='white',fg='#17324d',font=('Tahoma',9,'bold')).pack(side='right')
        dot=tk.Label(row,text='●',bg='white',fg='#94a3b8',font=('Segoe UI',13)); dot.pack(side='right',padx=6)
        status=tk.StringVar(value='⏳ بررسی...')
        detail=tk.StringVar(value='')
        tk.Label(row,textvariable=status,bg='white',fg='#526273',font=('Tahoma',8,'bold')).pack(side='right')
        tk.Label(row,textvariable=detail,bg='white',fg='#64748b',font=('Tahoma',8)).pack(side='right',padx=14)
        self.button(row,'🔄',lambda:self._dashboard_network_check(status,detail,dot)).pack(side='left',padx=2,pady=1)
        self._dashboard_network_check(status,detail,dot)
        return box

    # ---------- contacts + groups ----------
    def _attach_tree_scrollbars(self, parent, tree, padx=0, pady=0, horizontal=True):
        """Attach vertical/horizontal scrollbars and mouse-wheel scrolling to a Treeview."""
        holder=tk.Frame(parent,bg=parent.cget("bg") if "bg" in parent.keys() else self.colors["bg"])
        holder.pack(fill="both",expand=True,padx=padx,pady=pady)
        tree.pack_forget()
        tree.configure(yscrollcommand=lambda *args: vsb.set(*args),
                       xscrollcommand=(lambda *args: hsb.set(*args)) if horizontal else "")
        tree.pack(side="left",fill="both",expand=True)
        vsb=ttk.Scrollbar(holder,orient="vertical",command=tree.yview)
        vsb.pack(side="right",fill="y")
        if horizontal:
            hsb=ttk.Scrollbar(holder,orient="horizontal",command=tree.xview)
            hsb.pack(side="bottom",fill="x")
        def wheel(event):
            tree.yview_scroll(int(-1*(event.delta/120)), "units")
            return "break"
        tree.bind("<MouseWheel>", wheel, add="+")
        tree.bind("<Button-4>", lambda e: (tree.yview_scroll(-3,"units"), "break")[1], add="+")
        tree.bind("<Button-5>", lambda e: (tree.yview_scroll(3,"units"), "break")[1], add="+")
        return holder

    def show_contacts_groups(self):
        self.clear(); self.header("مخاطبین و گروه‌ها", "مدیریت یکپارچه مخاطبین، گروه‌بندی و یادآوری‌ها")
        nb=ttk.Notebook(self.main); nb.pack(fill="both",expand=True,padx=28,pady=8)
        cf=tk.Frame(nb,bg="#f4f7fb"); gf=tk.Frame(nb,bg="#f4f7fb")
        nb.add(cf,text="مخاطبین"); nb.add(gf,text="گروه‌ها")
        # contacts pane
        bar=tk.Frame(cf,bg="#f4f7fb");bar.pack(fill="x",pady=4)
        self.search=tk.StringVar();tk.Entry(bar,textvariable=self.search,justify="right").pack(side="right",fill="x",expand=True,padx=5,ipady=6)
        self.button(bar,"جستجو",self.refresh_contacts,True).pack(side="right")
        filter_box=tk.Frame(cf,bg="#f4f7fb"); filter_box.pack(fill="x",pady=(2,4))
        tk.Label(filter_box,text="نمایش مخاطبین:",bg="#f4f7fb",fg="#526273",font=("Tahoma",9,"bold")).pack(side="right",padx=(0,6))
        self.group_filter_var=tk.StringVar(value="همه مخاطبین")
        self.group_filter=ttk.Combobox(filter_box,textvariable=self.group_filter_var,state="readonly",justify="right",width=30)
        self.group_filter.pack(side="right",ipady=4)
        self.group_filter.bind("<<ComboboxSelected>>",lambda e:self.refresh_contacts())
        self.contact_count_var=tk.StringVar(value="۰ مخاطب")
        tk.Label(filter_box,textvariable=self.contact_count_var,bg="#f4f7fb",fg="#718096",font=("Tahoma",9)).pack(side="right",padx=12)
        for t,c in [("＋ مخاطب",self.add_contact),("✎ ویرایش",self.edit_contact),("گروه‌بندی",self.assign_groups),("📣 روبیکا",self.show_internal_campaigns),("📥 ورود اطلاعات",self.import_contacts),("📤 CSV",self.export_contacts)]:
            self.button(bar,t,c).pack(side="left",padx=2)
        cols=("id","first","last","mobile","phone","birth","gender","email","groups","rem")
        self.tree=ttk.Treeview(cf,columns=cols,show="headings",selectmode="extended")
        heads={"id":"ID","first":"نام","last":"نام خانوادگی","mobile":"موبایل","phone":"تلفن","birth":"تولد شمسی","gender":"جنسیت","email":"ایمیل","groups":"گروه‌ها","rem":"یادآوری"}
        widths={"id":45,"first":105,"last":125,"mobile":125,"phone":110,"birth":100,"gender":70,"email":175,"groups":190,"rem":80}
        for c in cols:self.tree.heading(c,text=heads[c]);self.tree.column(c,width=widths[c],anchor="center")
        self._attach_tree_scrollbars(cf, self.tree, pady=10, horizontal=True)
        self.refresh_contacts()
        # groups pane
        top=tk.Frame(gf,bg="#f4f7fb");top.pack(fill="x",pady=5)
        for t,cmd in [("＋ گروه جدید",self.add_group),("✎ ویرایش گروه",self.edit_group),("👥 مدیریت اعضا",self.manage_group_members),("🗑 حذف گروه",self.delete_group)]:
            self.button(top,t,cmd,t.startswith("＋")).pack(side="right",padx=3)
        self.gtree=ttk.Treeview(gf,columns=("id","name","desc","count"),show="headings")
        for c,t,w in [("id","ID",60),("name","نام گروه",250),("desc","توضیحات",500),("count","اعضا",100)]:
            self.gtree.heading(c,text=t);self.gtree.column(c,width=w,anchor="center")
        self._attach_tree_scrollbars(gf, self.gtree, pady=12, horizontal=True)
        self.refresh_groups()

    # ---------- contacts ----------
    def show_contacts(self):
        self.show_contacts_groups()

    def refresh_group_filter(self):
        if not hasattr(self,"group_filter"): return
        groups=self.db.c.execute("SELECT id,name FROM groups ORDER BY name").fetchall()
        values=["همه مخاطبین","بدون گروه"]+[f"{g['id']} | {g['name']}" for g in groups]
        current=self.group_filter_var.get()
        self.group_filter["values"]=values
        self.group_filter_var.set(current if current in values else "همه مخاطبین")

    def refresh_contacts(self):
        if not hasattr(self,"tree"):return
        self.refresh_group_filter()
        for i in self.tree.get_children():self.tree.delete(i)
        q=self.search.get().strip()
        selected_group=self.group_filter_var.get()
        sql="SELECT DISTINCT c.* FROM contacts c"
        params=[]
        if selected_group == "بدون گروه":
            sql += " LEFT JOIN contact_groups cg0 ON cg0.contact_id=c.id WHERE cg0.contact_id IS NULL"
        elif selected_group not in ("همه مخاطبین", ""):
            try: gid=int(selected_group.split("|",1)[0].strip())
            except Exception: gid=0
            sql += " JOIN contact_groups cfg ON cfg.contact_id=c.id WHERE cfg.group_id=?"
            params.append(gid)
        if q:
            cond="(c.first_name LIKE ? OR c.last_name LIKE ? OR c.mobile LIKE ? OR c.phone LIKE ? OR c.email LIKE ? OR c.company LIKE ? OR c.notes LIKE ?)"
            sql += (" AND " if " WHERE " in sql else " WHERE ") + cond
            params.extend([f"%{q}%"]*7)
        sql += " ORDER BY c.id DESC"
        rows=self.db.c.execute(sql,tuple(params)).fetchall()
        self.contact_count_var.set(f"{len(rows):,} مخاطب")
        for r in rows:
            gs=self.db.c.execute("SELECT g.name FROM groups g JOIN contact_groups cg ON g.id=cg.group_id WHERE cg.contact_id=?",(r["id"],)).fetchall()
            nr=self.db.c.execute("SELECT COUNT(*) n FROM reminders WHERE contact_id=? AND is_done=0",(r["id"],)).fetchone()["n"]
            self.tree.insert("", "end",iid=str(r["id"]),values=(r["id"],r["first_name"],r["last_name"],r["mobile"] or "",r["phone"] or "",
                iso_to_jalali(r["birth_date"] or "") if r["birth_date"] else "",r["gender"] or "",r["email"] or "",", ".join(x["name"] for x in gs),nr))

    def selected(self):
        return [int(i) for i in self.tree.selection()] if hasattr(self,"tree") else []
    def contact_form(self,cid=None):
        w=tk.Toplevel(self);w.title("ویرایش مخاطب" if cid else "ثبت مخاطب جدید");w.geometry("980x720");w.minsize(900,650);w.configure(bg="#f4f7fb")
        old=self.db.c.execute("SELECT * FROM contacts WHERE id=?",(cid,)).fetchone() if cid else None
        tk.Label(w,text="ویرایش مخاطب" if cid else "ثبت مخاطب جدید",bg="#f4f7fb",fg="#17324d",font=("Tahoma",18,"bold")).pack(anchor="e",padx=28,pady=(20,2))
        tk.Label(w,text="اطلاعات تماس و یادآوری‌های این مخاطب را در همین صفحه مدیریت کنید",bg="#f4f7fb",fg="#718096",font=("Tahoma",9)).pack(anchor="e",padx=28,pady=(0,12))
        body=tk.Frame(w,bg="#f4f7fb");body.pack(fill="both",expand=True,padx=24,pady=4)
        left=tk.LabelFrame(body,text=" اطلاعات مخاطب ",bg="white",fg="#17324d",font=("Tahoma",10,"bold"),padx=16,pady=12)
        left.pack(side="right",fill="both",expand=True,padx=(0,8))
        right=tk.LabelFrame(body,text=" یادآوری‌های این مخاطب ",bg="white",fg="#17324d",font=("Tahoma",10,"bold"),padx=12,pady=12)
        right.pack(side="left",fill="both",expand=True,padx=(8,0))
        data={}
        fields=[("نام","first_name"),("نام خانوادگی","last_name"),("شماره موبایل *","mobile"),("شماره تلفن","phone"),("ایمیل","email"),("شرکت","company")]
        for i,(lab,key) in enumerate(fields):
            row=i//2; col=i%2
            cell=tk.Frame(left,bg="white");cell.grid(row=row,column=col,sticky="ew",padx=7,pady=7)
            tk.Label(cell,text=lab,bg="white",fg="#526273",font=("Tahoma",9)).pack(anchor="e")
            e=tk.Entry(cell,justify="right",font=("Tahoma",10),relief="solid",bd=1);e.pack(fill="x",ipady=6,pady=(3,0))
            if old:e.insert(0,old[key] or "")
            data[key]=e
        left.grid_columnconfigure(0,weight=1);left.grid_columnconfigure(1,weight=1)
        msgcell=tk.LabelFrame(left,text=" شناسه پیام‌رسان‌ها (اختیاری) ",bg="white",fg="#17324d",font=("Tahoma",9,"bold"),padx=8,pady=6)
        msgcell.grid(row=3,column=0,columnspan=2,sticky="ew",padx=7,pady=7)
        for j,(lab,key) in enumerate([("Chat ID روبیکا","rubika_chat_id"),("Chat ID ایتا","eitaa_chat_id"),("Chat ID بله","bale_chat_id")]):
            sub=tk.Frame(msgcell,bg="white"); sub.grid(row=0,column=j,sticky="ew",padx=5)
            tk.Label(sub,text=lab,bg="white",fg="#526273",font=("Tahoma",8)).pack(anchor="e")
            e=tk.Entry(sub,justify="right",font=("Tahoma",9),relief="solid",bd=1);e.pack(fill="x",ipady=5,pady=(2,0))
            if old and key in old.keys(): e.insert(0,old[key] or "")
            data[key]=e
            msgcell.grid_columnconfigure(j,weight=1)
        cell=tk.Frame(left,bg="white");cell.grid(row=4,column=0,columnspan=2,sticky="ew",padx=7,pady=7)
        tk.Label(cell,text="تاریخ تولد (شمسی)",bg="white",fg="#526273",font=("Tahoma",9)).pack(anchor="e")
        birthrow=tk.Frame(cell,bg="white");birthrow.pack(fill="x",pady=(3,0))
        birth=tk.Entry(birthrow,justify="right",font=("Tahoma",10),relief="solid",bd=1);birth.pack(side="right",fill="x",expand=True,ipady=6)
        tk.Button(birthrow,text="📅 تقویم",command=lambda:self.jalali_picker(birth),bg="#eef5fb",fg="#1769aa",relief="flat",font=("Tahoma",9),padx=10).pack(side="left",padx=(6,0),ipady=5)
        if old and old["birth_date"]: birth.insert(0,iso_to_jalali(old["birth_date"]))
        cell=tk.Frame(left,bg="white");cell.grid(row=5,column=0,columnspan=2,sticky="ew",padx=7,pady=7)
        tk.Label(cell,text="جنسیت",bg="white",fg="#526273",font=("Tahoma",9)).pack(anchor="e")
        g=tk.StringVar(value=old["gender"] if old else "نامشخص")
        ttk.Combobox(cell,textvariable=g,values=["مرد","زن","سایر","نامشخص"],state="readonly",justify="right",font=("Tahoma",10)).pack(fill="x",ipady=4,pady=(3,0))
        cell=tk.Frame(left,bg="white");cell.grid(row=6,column=0,columnspan=2,sticky="nsew",padx=7,pady=7)
        tk.Label(cell,text="یادداشت مخاطب",bg="white",fg="#526273",font=("Tahoma",9)).pack(anchor="e")
        notes=tk.Text(cell,height=6,font=("Tahoma",10),relief="solid",bd=1);notes.pack(fill="both",expand=True,pady=(3,0))
        if old:notes.insert("1.0",old["notes"] or "")
        left.grid_rowconfigure(6,weight=1)

        reminder_rows=[]
        if cid:
            rr=self.db.c.execute("SELECT * FROM reminders WHERE contact_id=? ORDER BY reminder_date,reminder_time",(cid,)).fetchall()
            for x in rr: reminder_rows.append(dict(x))
        listframe=tk.Frame(right,bg="white");listframe.pack(fill="both",expand=True)
        canvas=tk.Canvas(listframe,bg="white",highlightthickness=0);scroll=tk.Scrollbar(listframe,orient="vertical",command=canvas.yview)
        cards=tk.Frame(canvas,bg="white");canvas.create_window((0,0),window=cards,anchor="nw");canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left",fill="both",expand=True);scroll.pack(side="right",fill="y")
        def redraw():
            for x in cards.winfo_children():x.destroy()
            if not reminder_rows:
                tk.Label(cards,text="هنوز یادآوری ثبت نشده است\nبرای افزودن، روی دکمه + کلیک کنید.",bg="white",fg="#94a3b8",font=("Tahoma",10),justify="center").pack(pady=70)
            for i,x in enumerate(reminder_rows):
                card=tk.Frame(cards,bg="#f8fbff",highlightthickness=1,highlightbackground="#dbe7f2");card.pack(fill="x",pady=6,padx=3)
                top=tk.Frame(card,bg="#f8fbff");top.pack(fill="x",padx=10,pady=(9,2))
                tk.Label(top,text=x.get('title',''),bg="#f8fbff",fg="#17324d",font=("Tahoma",10,"bold")).pack(side="right")
                tk.Button(top,text="×",command=lambda idx=i:remove_at(idx),bg="#f8fbff",fg="#b91c1c",relief="flat",font=("Segoe UI",11,"bold")).pack(side="left")
                tk.Label(card,text=f"📅 {iso_to_jalali(x.get('reminder_date',''))}    ⏰ {x.get('reminder_time','') or 'بدون ساعت'}    •    {x.get('repeat_type','بدون تکرار')}",bg="#f8fbff",fg="#526273",font=("Tahoma",9)).pack(anchor="e",padx=10,pady=2)
                if x.get('notes'):tk.Label(card,text=x['notes'],bg="#f8fbff",fg="#64748b",font=("Tahoma",9),justify="right",wraplength=350).pack(anchor="e",padx=10,pady=(2,9))
            cards.update_idletasks();canvas.configure(scrollregion=canvas.bbox("all"))
        def remove_at(idx):
            x=reminder_rows.pop(idx)
            if x.get("id"):self.db.q("DELETE FROM reminders WHERE id=?",(x["id"],))
            redraw()
        def add_inline_reminder():
            dlg=tk.Toplevel(w);dlg.title("یادآوری جدید");dlg.geometry("500x540");dlg.configure(bg="#f4f7fb")
            tk.Label(dlg,text="افزودن یادآوری",bg="#f4f7fb",fg="#17324d",font=("Tahoma",16,"bold")).pack(anchor="e",padx=30,pady=(20,8))
            form=tk.Frame(dlg,bg="white");form.pack(fill="both",expand=True,padx=24,pady=8)
            def field(label):
                tk.Label(form,text=label,bg="white",fg="#526273",font=("Tahoma",9)).pack(anchor="e",padx=18,pady=(10,2))
                e=tk.Entry(form,justify="right",font=("Tahoma",10),relief="solid",bd=1);e.pack(fill="x",padx=18,ipady=6);return e
            title=field("عنوان یادآوری *")
            tk.Label(form,text="یادداشت",bg="white",fg="#526273",font=("Tahoma",9)).pack(anchor="e",padx=18,pady=(10,2));nt=tk.Text(form,height=5,font=("Tahoma",10),relief="solid",bd=1);nt.pack(fill="x",padx=18)
            tk.Label(form,text="تاریخ یادآوری (شمسی) *",bg="white",fg="#526273",font=("Tahoma",9)).pack(anchor="e",padx=18,pady=(10,2))
            dr=tk.Frame(form,bg="white");dr.pack(fill="x",padx=18);date=tk.Entry(dr,justify="right",font=("Tahoma",10),relief="solid",bd=1);date.pack(side="right",fill="x",expand=True,ipady=6);tk.Button(dr,text="📅 انتخاب",command=lambda:self.jalali_picker(date),bg="#eef5fb",fg="#1769aa",relief="flat").pack(side="left",padx=(5,0),ipady=5)
            tm=field("ساعت (اختیاری، مثال 14:30)")
            tk.Label(form,text="تکرار",bg="white",fg="#526273",font=("Tahoma",9)).pack(anchor="e",padx=18,pady=(10,2));rep=tk.StringVar(value="بدون تکرار");ttk.Combobox(form,textvariable=rep,values=["بدون تکرار","روزانه","هفتگی","ماهانه","سالانه"],state="readonly",justify="right").pack(fill="x",padx=18,ipady=4)
            def save_r():
                if not title.get().strip() or not date.get().strip():messagebox.showwarning("اطلاعات ناقص","عنوان و تاریخ الزامی است.",parent=dlg);return
                try:iso=jalali_to_iso(date.get())
                except Exception as ex:messagebox.showwarning("تاریخ نامعتبر",str(ex),parent=dlg);return
                reminder_rows.append({"id":None,"title":title.get().strip(),"notes":nt.get("1.0","end").strip(),"reminder_date":iso,"reminder_time":tm.get().strip(),"repeat_type":rep.get(),"is_done":0});redraw();dlg.destroy()
            self.button(form,"＋ افزودن یادآوری",save_r,True).pack(anchor="e",padx=18,pady=16)
        self.button(right,"＋ افزودن یادآوری",add_inline_reminder,True).pack(anchor="e",pady=(8,2))
        def save():
            vals={k:e.get().strip() for k,e in data.items()}
            if not vals["mobile"]:messagebox.showwarning("خطا","شماره موبایل الزامی است.",parent=w);return
            try:birth_iso=jalali_to_iso(birth.get()) if birth.get().strip() else ""
            except Exception as ex:messagebox.showwarning("تاریخ تولد",str(ex),parent=w);return
            try:
                # Do not assign to the outer cid variable here. In Python, assigning to cid
                # inside this nested function makes cid local and causes UnboundLocalError.
                contact_id = cid
                if contact_id:
                    self.db.q("UPDATE contacts SET first_name=?,last_name=?,mobile=?,phone=?,birth_date=?,gender=?,email=?,company=?,notes=?,rubika_chat_id=?,eitaa_chat_id=?,bale_chat_id=? WHERE id=?",
                               (vals["first_name"],vals["last_name"],vals["mobile"],vals["phone"],birth_iso,g.get(),vals["email"],vals["company"],notes.get("1.0","end").strip(),vals.get("rubika_chat_id",""),vals.get("eitaa_chat_id",""),vals.get("bale_chat_id",""),contact_id))
                else:
                    cur=self.db.q("INSERT INTO contacts(first_name,last_name,mobile,phone,birth_date,gender,email,company,notes,rubika_chat_id,eitaa_chat_id,bale_chat_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                                   (vals["first_name"],vals["last_name"],vals["mobile"],vals["phone"],birth_iso,g.get(),vals["email"],vals["company"],notes.get("1.0","end").strip(),vals.get("rubika_chat_id",""),vals.get("eitaa_chat_id",""),vals.get("bale_chat_id","")))
                    contact_id=cur.lastrowid
                for x in reminder_rows:
                    if not x.get("id"):
                        self.db.q("INSERT INTO reminders(contact_id,title,reminder_date,reminder_time,notes,repeat_type,is_done) VALUES(?,?,?,?,?,?,?)",
                                   (contact_id,x["title"],x["reminder_date"],x.get("reminder_time",""),x.get("notes",""),x.get("repeat_type","بدون تکرار"),0))
                self.refresh_contacts()
                w.destroy()
                messagebox.showinfo("ذخیره شد", "مخاطب با موفقیت ذخیره شد.")
            except sqlite3.IntegrityError:
                messagebox.showerror("خطا","این شماره موبایل قبلاً ثبت شده است.",parent=w)
            except Exception as ex:
                messagebox.showerror("خطای ذخیره‌سازی", f"ذخیره مخاطب انجام نشد:\n{ex}", parent=w)
        self.button(w,"✓ ذخیره مخاطب",save,True).pack(anchor="e",padx=28,pady=12)
        # Keyboard-first data entry: Enter follows the visual/data order exactly.
        # Name -> Last name -> Mobile -> Phone -> Email -> Company -> Birth date -> Gender.
        # We bind the sequence explicitly instead of relying on Tk's automatic traversal order.
        focusables=[
            data["first_name"], data["last_name"], data["mobile"], data["phone"],
            data["email"], data["company"], data["rubika_chat_id"], data["eitaa_chat_id"], data["bale_chat_id"], birth
        ]
        gender_box=None
        # The gender Combobox is the last input in the sequence. Find it from the left panel.
        for child in left.winfo_children():
            for sub in child.winfo_children():
                if isinstance(sub, ttk.Combobox):
                    gender_box=sub
                    break
            if gender_box is not None: break
        if gender_box is not None:
            focusables.append(gender_box)

        def next_focus(event):
            try:
                idx=focusables.index(event.widget)
                nxt=focusables[(idx+1) % len(focusables)]
                nxt.focus_set()
                if hasattr(nxt, "selection_range"):
                    nxt.selection_range(0, "end")
            except ValueError:
                pass
            return "break"

        def previous_focus(event):
            try:
                idx=focusables.index(event.widget)
                prev=focusables[(idx-1) % len(focusables)]
                prev.focus_set()
                if hasattr(prev, "selection_range"):
                    prev.selection_range(0, "end")
            except ValueError:
                pass
            return "break"

        for widget in focusables:
            widget.bind("<Return>", next_focus, add="+")
            widget.bind("<Shift-Return>", previous_focus, add="+")
        w.bind("<Control-Return>",lambda e:save())

        # Start new-contact entry at the first field; editing starts at the first field too.
        if focusables:
            w.after(100, lambda: focusables[0].focus_set())

    def jalali_picker(self, target, initial=None):
        now=datetime.now(); jy,jm,jd=gregorian_to_jalali(now.year,now.month,now.day)
        if target.get().strip():
            try: jy,jm,jd=map(int,target.get().strip().replace('/','-').split('-'))
            except Exception: pass
        w=tk.Toplevel(self);w.title("انتخاب تاریخ شمسی");w.geometry("470x470");w.transient(self);w.configure(bg="#f4f7fb")
        state={"y":jy,"m":jm};head=tk.Frame(w,bg="#f4f7fb");head.pack(fill="x",padx=15,pady=12)
        controls=tk.Frame(w,bg="#f4f7fb");controls.pack(fill="x",padx=20,pady=4)
        years=list(range(1300, jy+31)); yv=tk.StringVar(value=str(jy)); mv=tk.StringVar(value=JALALI_MONTHS[jm-1])
        ycb=ttk.Combobox(controls,textvariable=yv,values=[str(x) for x in years],state="readonly",justify="center",width=10);ycb.pack(side="right",padx=4)
        mcb=ttk.Combobox(controls,textvariable=mv,values=JALALI_MONTHS,state="readonly",justify="right",width=14);mcb.pack(side="right",padx=4)
        grid=tk.Frame(w,bg="#f4f7fb");grid.pack(padx=15,pady=8)
        def render():
            state['y']=int(yv.get());state['m']=JALALI_MONTHS.index(mv.get())+1
            for x in grid.winfo_children():x.destroy()
            tk.Label(head,text=f"{JALALI_MONTHS[state['m']-1]} {state['y']}",bg="#f4f7fb",fg="#17324d",font=("Tahoma",13,"bold")).pack()
            for i,name in enumerate(["ش","ی","د","س","چ","پ","ج"]):tk.Label(grid,text=name,width=5,bg="#f4f7fb",fg="#526273",font=("Tahoma",9,"bold")).grid(row=0,column=i,pady=5)
            gy,gm,gd=jalali_to_gregorian(state['y'],state['m'],1);first=(datetime(gy,gm,gd).weekday()+2)%7;days=jalali_month_days(state['y'],state['m'])
            for day in range(1,days+1):
                idx=first+day-1;rr=1+idx//7;cc=idx%7
                tk.Button(grid,text=str(day),width=5,command=lambda d=day:self.pick_day(target,w,state['y'],state['m'],d)).grid(row=rr,column=cc,padx=2,pady=2)
        ycb.bind("<<ComboboxSelected>>",lambda e:render());mcb.bind("<<ComboboxSelected>>",lambda e:render());render()
    def pick_day(self,target,w,y,m,d):
        target.delete(0,"end");target.insert(0,f"{y:04d}-{m:02d}-{d:02d}");w.destroy()

    def add_contact(self):self.contact_form()
    def edit_contact(self):
        ids=self.selected()
        if len(ids)!=1:messagebox.showwarning("ویرایش","یک مخاطب انتخاب کنید.");return
        self.contact_form(ids[0])
    # groups
    def show_groups(self):
        self.clear();self.header("گروه‌های مخاطبین","گروه‌های نامحدود برای هدف‌گذاری کمپین‌ها")
        self.button(self.main,"＋ گروه جدید",self.add_group,True).pack(anchor="e",padx=28)
        self.gtree=ttk.Treeview(self.main,columns=("id","name","desc","count"),show="headings")
        for c,t,w in [("id","ID",60),("name","نام گروه",250),("desc","توضیحات",500),("count","اعضا",100)]:
            self.gtree.heading(c,text=t);self.gtree.column(c,width=w,anchor="center")
        self.gtree.pack(fill="both",expand=True,padx=28,pady=12)
        self.refresh_groups()
    def refresh_groups(self):
        if not hasattr(self,"gtree"):return
        for i in self.gtree.get_children():self.gtree.delete(i)
        rows=self.db.c.execute("""SELECT g.id,g.name,g.description,COUNT(cg.contact_id) n FROM groups g
                                  LEFT JOIN contact_groups cg ON g.id=cg.group_id GROUP BY g.id ORDER BY g.name""").fetchall()
        for r in rows:self.gtree.insert("", "end",values=(r["id"],r["name"],r["description"],r["n"]))
        self.refresh_group_filter()
    def add_group(self):
        n=simpledialog.askstring("گروه","نام گروه:",parent=self)
        if not n:return
        d=simpledialog.askstring("توضیحات","توضیحات:",parent=self) or ""
        try:self.db.q("INSERT INTO groups(name,description) VALUES(?,?)",(n.strip(),d));self.refresh_groups()
        except sqlite3.IntegrityError:messagebox.showerror("خطا","گروه تکراری است.")
    def group_selected_id(self):
        if not hasattr(self,"gtree"): return None
        sel=self.gtree.selection()
        if len(sel)!=1:
            messagebox.showwarning("گروه","یک گروه را انتخاب کنید.");return None
        vals=self.gtree.item(sel[0],"values");return int(vals[0])
    def edit_group(self):
        gid=self.group_selected_id()
        if gid is None:return
        r=self.db.c.execute("SELECT * FROM groups WHERE id=?",(gid,)).fetchone()
        if not r:return
        w=tk.Toplevel(self);w.title("ویرایش گروه");w.geometry("480x300");w.configure(bg="#f4f7fb")
        tk.Label(w,text="ویرایش گروه",bg="#f4f7fb",fg="#17324d",font=("Tahoma",16,"bold")).pack(anchor="e",padx=25,pady=18)
        n=tk.Entry(w,justify="right",font=("Tahoma",10));n.pack(fill="x",padx=25,pady=5);n.insert(0,r["name"])
        d=tk.Entry(w,justify="right",font=("Tahoma",10));d.pack(fill="x",padx=25,pady=5);d.insert(0,r["description"] or "")
        def save():
            if not n.get().strip():return
            try:self.db.q("UPDATE groups SET name=?,description=? WHERE id=?",(n.get().strip(),d.get().strip(),gid));w.destroy();self.refresh_groups();self.refresh_contacts()
            except sqlite3.IntegrityError:messagebox.showerror("خطا","این نام گروه قبلاً استفاده شده است.",parent=w)
        self.button(w,"✓ ذخیره تغییرات",save,True).pack(anchor="e",padx=25,pady=15)
    def delete_group(self):
        gid=self.group_selected_id()
        if gid is None:return
        r=self.db.c.execute("SELECT name FROM groups WHERE id=?",(gid,)).fetchone()
        if not r:return
        if not messagebox.askyesno("حذف گروه",f"گروه «{r['name']}» حذف شود؟ مخاطبین حذف نمی‌شوند."):return
        self.db.q("DELETE FROM contact_groups WHERE group_id=?",(gid,));self.db.q("DELETE FROM groups WHERE id=?",(gid,));self.refresh_groups();self.refresh_contacts()
    def manage_group_members(self):
        gid=self.group_selected_id()
        if gid is None:return
        gr=self.db.c.execute("SELECT name FROM groups WHERE id=?",(gid,)).fetchone()
        w=tk.Toplevel(self);w.title(f"اعضای گروه: {gr['name']}");w.geometry("760x560");w.configure(bg="#f4f7fb")
        tk.Label(w,text=f"اعضای گروه «{gr['name']}»",bg="#f4f7fb",fg="#17324d",font=("Tahoma",16,"bold")).pack(anchor="e",padx=25,pady=15)
        bar=tk.Frame(w,bg="#f4f7fb");bar.pack(fill="x",padx=25)
        search=tk.StringVar();tk.Entry(bar,textvariable=search,justify="right").pack(side="right",fill="x",expand=True,padx=4,ipady=6)
        tr=ttk.Treeview(w,columns=("id","name","mobile"),show="headings",selectmode="extended")
        for c,t,ww in [("id","ID",60),("name","نام و نام خانوادگی",280),("mobile","موبایل",180)]:tr.heading(c,text=t);tr.column(c,width=ww,anchor="center")
        tr.pack(fill="both",expand=True,padx=25,pady=12)
        def refresh():
            for i in tr.get_children():tr.delete(i)
            q=search.get().strip(); rows=self.db.c.execute("""SELECT c.id,c.first_name,c.last_name,c.mobile FROM contacts c JOIN contact_groups cg ON cg.contact_id=c.id WHERE cg.group_id=? AND (c.first_name LIKE ? OR c.last_name LIKE ? OR c.mobile LIKE ?) ORDER BY c.first_name,c.last_name""",(gid,f"%{q}%",f"%{q}%",f"%{q}%")).fetchall()
            for r in rows:tr.insert("","end",iid=str(r['id']),values=(r['id'],f"{r['first_name']} {r['last_name']}",r['mobile']))
        search.trace_add("write",lambda *a:refresh());refresh()
        def remove_members():
            ids=[int(x) for x in tr.selection()]
            for cid in ids:self.db.q("DELETE FROM contact_groups WHERE contact_id=? AND group_id=?",(cid,gid))
            refresh();self.refresh_groups();self.refresh_contacts()
        def add_members():
            allr=self.db.c.execute("SELECT id,first_name,last_name,mobile FROM contacts WHERE id NOT IN (SELECT contact_id FROM contact_groups WHERE group_id=?) ORDER BY first_name,last_name",(gid,)).fetchall()
            aw=tk.Toplevel(w);aw.title("افزودن مخاطب به گروه");aw.geometry("620x500");aw.configure(bg="#f4f7fb")
            lb=tk.Listbox(aw,selectmode="multiple",font=("Tahoma",10));lb.pack(fill="both",expand=True,padx=25,pady=20)
            for r in allr:lb.insert("end",f"{r['first_name']} {r['last_name']} — {r['mobile']}")
            def save_add():
                for i in lb.curselection():self.db.q("INSERT OR IGNORE INTO contact_groups(contact_id,group_id) VALUES(?,?)",(allr[i]['id'],gid))
                aw.destroy();refresh();self.refresh_groups();self.refresh_contacts()
            self.button(aw,"＋ افزودن انتخاب‌شده‌ها",save_add,True).pack(anchor="e",padx=25,pady=12)
        self.button(bar,"＋ افزودن مخاطب",add_members,True).pack(side="right",padx=3)
        self.button(bar,"حذف از گروه",remove_members).pack(side="right",padx=3)
        self.button(bar,"بستن",w.destroy).pack(side="left")
    def assign_groups(self):
        ids=self.selected()
        if not ids:messagebox.showwarning("انتخاب","مخاطب انتخاب کنید.");return
        gs=self.db.c.execute("SELECT id,name FROM groups ORDER BY name").fetchall()
        if not gs:messagebox.showinfo("گروه","ابتدا گروه بسازید.");return
        w=tk.Toplevel(self);w.title("تخصیص گروه");w.geometry("430x400")
        lb=tk.Listbox(w,selectmode="multiple",font=("Tahoma",10));lb.pack(fill="both",expand=True,padx=30,pady=20)
        for g in gs:lb.insert("end",g["name"])
        def save():
            selected_groups=[gs[p]["id"] for p in lb.curselection()]
            if not selected_groups:
                messagebox.showwarning("گروه","حداقل یک گروه را انتخاب کنید.",parent=w); return
            w.destroy()
            total=len(ids)
            def worker(progress):
                for i,cid in enumerate(ids,1):
                    self.db.q("DELETE FROM contact_groups WHERE contact_id=?",(cid,))
                    for gid in selected_groups:
                        self.db.q("INSERT OR IGNORE INTO contact_groups VALUES(?,?)",(cid,gid))
                    progress(i*100/total, f"در حال تخصیص مخاطب {i:,} از {total:,} به گروه...")
                return total
            def done(result,error):
                if error:
                    messagebox.showerror("خطا",f"تخصیص گروه انجام نشد:\n{error}")
                    return
                self.refresh_contacts()
                messagebox.showinfo("انجام شد",f"{result:,} مخاطب با موفقیت گروه‌بندی شد.")
            self.run_with_progress("تخصیص مخاطبین به گروه", "در حال آماده‌سازی...", total, worker, done)
        self.button(w,"اعمال",save,True).pack(pady=12)
    # reminders
    def reminder_selected(self):
        ids=self.selected()
        if len(ids)!=1:messagebox.showwarning("یادآوری","یک مخاطب انتخاب کنید.");return
        self.reminder_form(ids[0])
    def reminder_form(self,cid):
        r=self.db.c.execute("SELECT first_name,last_name FROM contacts WHERE id=?",(cid,)).fetchone()
        w=tk.Toplevel(self);w.title("یادآوری جدید");w.geometry("480x470")
        tk.Label(w,text=f"مخاطب: {r['first_name']} {r['last_name']}",font=("Tahoma",11,"bold")).pack(pady=15)
        d={}
        for lab,key in [("عنوان","title"),("تاریخ (YYYY-MM-DD یا تاریخ دلخواه)","date"),("ساعت","time"),("یادداشت","notes")]:
            tk.Label(w,text=lab,font=("Tahoma",9)).pack(anchor="e",padx=35,pady=(7,2))
            e=tk.Entry(w,justify="right");e.pack(fill="x",padx=35);d[key]=e
        rep=tk.StringVar(value="بدون تکرار");tk.Label(w,text="تکرار",font=("Tahoma",9)).pack(anchor="e",padx=35,pady=(7,2))
        ttk.Combobox(w,textvariable=rep,values=["بدون تکرار","روزانه","هفتگی","ماهانه","سالانه"],state="readonly").pack(fill="x",padx=35)
        def save():
            if not d["title"].get().strip() or not d["date"].get().strip():messagebox.showwarning("خطا","عنوان و تاریخ الزامی است.");return
            self.db.q("""INSERT INTO reminders(contact_id,title,reminder_date,reminder_time,notes,repeat_type) VALUES(?,?,?,?,?,?)""",
                      (cid,d["title"].get().strip(),d["date"].get().strip(),d["time"].get().strip(),d["notes"].get().strip(),rep.get()))
            w.destroy()
        self.button(w,"ثبت یادآوری",save,True).pack(pady=20)
    def show_reminders(self):
        self.clear();self.header("یادآوری‌ها","هر مخاطب می‌تواند هر تعداد یادآوری داشته باشد")
        self.button(self.main,"＋ یادآوری",self.choose_reminder,True).pack(anchor="e",padx=28)
        cols=("id","contact","title","date","time","repeat","notes","status")
        tr=ttk.Treeview(self.main,columns=cols,show="headings")
        for c,t,w in [("id","ID",50),("contact","مخاطب",180),("title","عنوان",190),("date","تاریخ",120),("time","ساعت",80),("repeat","تکرار",100),("notes","یادداشت",350),("status","وضعیت",80)]:
            tr.heading(c,text=t);tr.column(c,width=w,anchor="center")
        self._attach_tree_scrollbars(self.main, tr, padx=28, pady=12, horizontal=True)
        rows=self.db.c.execute("""SELECT r.*,c.first_name,c.last_name FROM reminders r JOIN contacts c ON c.id=r.contact_id
                                  ORDER BY r.reminder_date,r.reminder_time""").fetchall()
        for r in rows:tr.insert("", "end",values=(r["id"],f"{r['first_name']} {r['last_name']}",r["title"],iso_to_jalali(r["reminder_date"]),r["reminder_time"],r["repeat_type"],r["notes"],"انجام شد" if r["is_done"] else "فعال"))
    def choose_reminder(self):
        rows=self.db.c.execute("SELECT id,first_name,last_name,mobile FROM contacts ORDER BY first_name,last_name").fetchall()
        if not rows:return
        s=simpledialog.askinteger("مخاطب","شماره ردیف:\n"+"\n".join(f"{i+1}. {r['first_name']} {r['last_name']} - {r['mobile']}" for i,r in enumerate(rows)),parent=self)
        if s and 1<=s<=len(rows):self.reminder_form(rows[s-1]["id"])
    # campaigns
    def _internal_channel_meta(self, kind):
        return {
            'RUBIKA': ('روبیکا','rubika_token','rubika_api_base','rubika_chat_id','https://botapi.rubika.ir/v3'),
            'EITAA': ('ایتا','eitaa_token','eitaa_api_base','eitaa_chat_id','https://eitaayar.ir/api'),
            'BALE': ('بله','bale_bot_token','bale_api_base','bale_chat_id','https://tapi.bale.ai'),
        }[kind]

    def _send_internal_message(self, kind, chat_id, text):
        name, token_key, base_key, _, default_base = self._internal_channel_meta(kind)
        token = self.db.get(token_key,'').strip()
        base = (self.db.get(base_key,'').strip() or default_base).rstrip('/')
        if not token: return False, 'Token / API Key تنظیم نشده است.'
        if not chat_id: return False, 'Chat ID مقصد خالی است.'
        if kind == 'RUBIKA':
            url = f'{base}/{token}/sendMessage'
            payload = json.dumps({'chat_id':chat_id,'text':text}, ensure_ascii=False).encode('utf-8')
            headers = {'Content-Type':'application/json','User-Agent':'SMS-Manager/1.0'}
        elif kind == 'EITAA':
            url = f'{base}/{token}/sendMessage'
            payload = urllib.parse.urlencode({'chat_id':chat_id,'text':text}).encode('utf-8')
            headers = {'Content-Type':'application/x-www-form-urlencoded','User-Agent':'SMS-Manager/1.0'}
        else:
            url = f'{base}/bot{token}/sendMessage'
            payload = json.dumps({'chat_id':chat_id,'text':text}, ensure_ascii=False).encode('utf-8')
            headers = {'Content-Type':'application/json','User-Agent':'SMS-Manager/1.0'}
        req = urllib.request.Request(url, data=payload, headers=headers, method='POST')
        try:
            with self._urlopen(req, timeout=25) as r:
                raw = r.read().decode('utf-8','replace')
            try: data = json.loads(raw)
            except Exception: data = None
            if isinstance(data,dict):
                ok = (data.get('ok') is True) or str(data.get('status','')).upper() in ('OK','SUCCESS','TRUE') or (data.get('error') in (None,'') and data.get('message_id') is not None)
                detail = data.get('description') or data.get('error') or data.get('message') or data.get('status') or raw[:300]
                return ok, str(detail)
            return False, 'پاسخ سرویس قابل تشخیص نبود: ' + raw[:400]
        except urllib.error.HTTPError as e:
            try: detail = e.read().decode('utf-8','replace')[:500]
            except Exception: detail = str(e)
            return False, f'HTTP {e.code}: {detail}'
        except urllib.error.URLError as e:
            return False, f'خطای دسترسی شبکه: {getattr(e,"reason",e)}'
        except Exception as e:
            return False, f'{type(e).__name__}: {e}'

    def _rubika_get_bot_identity(self):
        """Return bot identifiers from getMe so the bot's own destination is never used as a contact."""
        token=self.db.get('rubika_token','').strip()
        base=(self.db.get('rubika_api_base','').strip() or 'https://botapi.rubika.ir/v3').rstrip('/')
        if not token: return set()
        try:
            req=urllib.request.Request(f'{base}/{token}/getMe',data=b'{}',headers={'Content-Type':'application/json','User-Agent':'SMS-Manager/1.0'},method='POST')
            with self._urlopen(req,timeout=15) as r: raw=r.read().decode('utf-8','replace')
            data=json.loads(raw)
            ids=set()
            def walk(o):
                if isinstance(o,dict):
                    for k in ('id','bot_id','botId','chat_id','chatId','user_id','userId'):
                        v=o.get(k)
                        if isinstance(v,(str,int)) and str(v).strip(): ids.add(str(v).strip())
                    for v in o.values(): walk(v)
                elif isinstance(o,list):
                    for v in o: walk(v)
            walk(data)
            return ids
        except Exception:
            return set()

    def _rubika_user_session_settings(self, parent=None):
        """Rubika Web account bootstrap with live diagnostics.

        v72 intentionally focuses on one thing: make OTP delivery observable.
        It performs DNS -> Web -> Discovery -> direct sendCode attempts and
        shows every stage in the window. It never replaces the user's database.
        """
        w=tk.Toplevel(self); w.title('اتصال حساب روبیکا - Web'); w.geometry('820x760'); w.minsize(760,700); w.configure(bg='white'); w.transient(self)
        # v74: do not use grab_set(); the Rubika dialog must never lock the main application window.
        w.protocol('WM_DELETE_WINDOW', w.destroy)
        tk.Label(w,text='اتصال حساب کاربری روبیکا از مسیر Web',bg='#0f3d63',fg='white',font=('Tahoma',13,'bold')).pack(fill='x',ipady=12)
        tk.Label(w,text='v78 — تشخیص مرحله‌ای با fallback داخلی؛ حتی بدون کتابخانه requests هم تست Web انجام می‌شود. کشور ایران (+98) ثابت است و وضعیت هر مرحله پایین پنجره نمایش داده می‌شود.',bg='white',fg='#334155',font=('Tahoma',9),justify='right',wraplength=740).pack(anchor='e',padx=22,pady=(14,8))
        frm=tk.Frame(w,bg='white'); frm.pack(fill='x',padx=22,pady=4)
        tk.Label(frm,text='کشور شماره:',bg='white',font=('Tahoma',9,'bold')).pack(anchor='e')
        country=tk.StringVar(value='ایران (+98)')
        ttk.Combobox(frm,textvariable=country,values=['ایران (+98)'],state='readonly',font=('Tahoma',9)).pack(fill='x',ipady=4,pady=3)
        tk.Label(frm,text='شماره موبایل:',bg='white',font=('Tahoma',9,'bold')).pack(anchor='e',pady=(5,0))
        phone=tk.StringVar(value=self.db.get('rubika_user_phone',''))
        tk.Entry(frm,textvariable=phone,font=('Segoe UI',10),justify='right').pack(fill='x',ipady=5,pady=3)
        tk.Label(frm,text='نوع دریافت کد:',bg='white',font=('Tahoma',9)).pack(anchor='e',pady=(5,0))
        send_type=tk.StringVar(value='SMS')
        ttk.Combobox(frm,textvariable=send_type,values=['SMS','Internal'],state='readonly',font=('Tahoma',9)).pack(fill='x',ipady=4,pady=3)
        tk.Label(frm,text='کد تأیید:',bg='white',font=('Tahoma',9,'bold')).pack(anchor='e',pady=(5,0))
        code=tk.StringVar(); code_ent=tk.Entry(frm,textvariable=code,font=('Segoe UI',10),justify='center'); code_ent.pack(fill='x',ipady=5,pady=3)
        tk.Label(frm,text='GUID گروه واقعی روبیکا (بعداً قابل تنظیم):',bg='white',font=('Tahoma',9,'bold')).pack(anchor='e',pady=(5,0))
        guid=tk.StringVar(value=self.db.get('rubika_user_group_guid',''))
        tk.Entry(frm,textvariable=guid,font=('Segoe UI',10)).pack(fill='x',ipady=5,pady=3)

        status=tk.StringVar(value='⚪ آماده — ابتدا «تشخیص شبکه» را بزنید.')
        tk.Label(w,textvariable=status,bg='#eef6ff',fg='#0f3d63',font=('Tahoma',9,'bold'),justify='right',wraplength=740).pack(fill='x',padx=22,pady=(8,5),ipady=9)
        timer_var=tk.StringVar(value='زمان عملیات: 0 ثانیه')
        tk.Label(w,textvariable=timer_var,bg='white',fg='#64748b',font=('Tahoma',8)).pack(anchor='e',padx=24)
        log=tk.Text(w,height=7,bg='#0b1220',fg='#dbeafe',insertbackground='white',font=('Consolas',9),state='disabled',wrap='word')
        log.pack(fill='x',expand=False,padx=22,pady=6)
        tk.Label(w,text='انتخاب ایران فقط شماره/زبان/هدر Web را تنظیم می‌کند؛ IP اینترنت را ایران نمی‌کند.',bg='#fff7ed',fg='#9a3412',font=('Tahoma',8),justify='right').pack(fill='x',padx=22,pady=(0,7),ipady=7)

        foot=tk.Frame(w,bg='white'); foot.pack(fill='x',padx=22,pady=7)
        btn_send=self.button(foot,'📩 دریافت کد Web',lambda:None,True); btn_send.pack(side='right',padx=4)
        btn_diag=self.button(foot,'🔎 تشخیص شبکه',lambda:None); btn_diag.pack(side='right',padx=4)
        btn_login=self.button(foot,'🔐 ورود و ذخیره Session',lambda:None,True); btn_login.pack(side='right',padx=4); btn_login.configure(state='disabled')
        self.button(foot,'📋 کپی گزارش',lambda: copy_report()).pack(side='left',padx=4)
        self.button(foot,'💾 ذخیره گزارش',lambda: save_report()).pack(side='left',padx=4)
        self.button(foot,'🌐 باز کردن Web Rubika',lambda: webbrowser.open('https://web.rubika.ir/')).pack(side='left',padx=4)
        self.button(foot,'بستن',w.destroy).pack(side='left',padx=4)

        state={'hash':'','raw':'','tmp_session':self.db.get('rubika_user_tmp_session','').strip()}
        op_started=[None]
        timer_job=[None]

        def ui(fn):
            try: self.after(0,fn)
            except Exception: pass
        def set_status(txt):
            ui(lambda: status.set(txt))
        def log_line(txt):
            def add():
                from datetime import datetime
                log.configure(state='normal'); log.insert('end',f'[{datetime.now().strftime("%H:%M:%S")}] {txt}\n'); log.see('end'); log.configure(state='disabled')
            ui(add)
        def get_report():
            try:
                return log.get('1.0','end-1c').strip()
            except Exception:
                return ''
        def copy_report():
            report=get_report()
            if not report:
                report='گزارش هنوز خالی است.'
            try:
                w.clipboard_clear(); w.clipboard_append(report); w.update()
                status.set('📋 گزارش در کلیپ‌بورد کپی شد؛ حالا اینجا Paste کن.')
            except Exception as e:
                status.set('❌ کپی گزارش انجام نشد: '+str(e))
        def save_report():
            try:
                from tkinter import filedialog
                path=filedialog.asksaveasfilename(parent=w,title='ذخیره گزارش روبیکا',defaultextension='.txt',filetypes=[('Text file','*.txt'),('All files','*.*')],initialfile='rubika_network_report.txt')
                if not path:
                    return
                with open(path,'w',encoding='utf-8') as f:
                    f.write(get_report() or 'گزارش خالی است.')
                status.set('💾 گزارش ذخیره شد: '+path)
            except Exception as e:
                status.set('❌ ذخیره گزارش انجام نشد: '+str(e))

        def timer_tick():
            if op_started[0] is not None:
                sec=int(max(0,time.time()-op_started[0])); timer_var.set(f'زمان عملیات: {sec} ثانیه')
                timer_job[0]=w.after(500,timer_tick)
        def start_timer():
            op_started[0]=time.time(); timer_tick()
        def stop_timer():
            op_started[0]=None
            if timer_job[0]:
                try: w.after_cancel(timer_job[0])
                except Exception: pass
                timer_job[0]=None
        def finish_buttons():
            ui(lambda: btn_send.configure(state='normal'))
            ui(lambda: btn_diag.configure(state='normal'))
        def show_error(title,err):
            stop_timer(); finish_buttons(); set_status('🔴 '+str(err)); ui(lambda: messagebox.showerror(title,str(err),parent=w))

        def normalize_phone(raw):
            x=''.join(ch for ch in str(raw or '') if ch.isdigit())
            if x.startswith('0098'): x=x[4:]
            elif x.startswith('98'): x=x[2:]
            elif x.startswith('0'): x=x[1:]
            if len(x)!=10 or not x.startswith('9'): raise ValueError('شماره باید به شکل 09xxxxxxxxx باشد.')
            return '98'+x, '0'+x
        def recursive_find(obj,names):
            names={str(n).lower() for n in names}
            if isinstance(obj,dict):
                for k,v in obj.items():
                    if str(k).lower() in names and v not in (None,''): return v
                for v in obj.values():
                    r=recursive_find(v,names)
                    if r not in (None,''): return r
            elif isinstance(obj,list):
                for v in obj:
                    r=recursive_find(v,names)
                    if r not in (None,''): return r
            return ''
        def extract_hosts(obj):
            out=[]
            def walk(v):
                if isinstance(v,dict):
                    for x in v.values(): walk(x)
                elif isinstance(v,list):
                    for x in v: walk(x)
                elif isinstance(v,str):
                    x=v.strip()
                    if 'iranlms.ir' in x and x not in out: out.append(x)
            walk(obj)
            hosts=[]
            for x in out:
                if x.startswith('http'): hosts.append(x.rstrip('/')+'/')
                else: hosts.append('https://'+x.rstrip('/')+'/')
            return hosts

        def _web_http_request(method, url, headers=None, json_data=None, timeout=8):
            """HTTP helper: prefer requests, but fall back to urllib so diagnostics/OTP do not fail just because requests is absent."""
            headers = headers or {}
            try:
                import requests
                if method.upper() == 'GET':
                    r = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
                else:
                    r = requests.post(url, headers=headers, json=json_data, timeout=timeout, allow_redirects=True)
                return r.status_code, r.headers, r.content, r.text, (r.json() if 'application/json' in r.headers.get('content-type','').lower() else {})
            except ModuleNotFoundError:
                import urllib.request, urllib.error, json as _json
                data = None if method.upper() == 'GET' else _json.dumps(json_data or {}).encode('utf-8')
                req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
                try:
                    with urllib.request.urlopen(req, timeout=timeout) as resp:
                        body = resp.read()
                        text = body.decode('utf-8', errors='replace')
                        try: obj = _json.loads(text)
                        except Exception: obj = {}
                        return resp.status, dict(resp.headers), body, text, obj
                except urllib.error.HTTPError as e:
                    body=e.read()
                    text=body.decode('utf-8', errors='replace')
                    try: obj=_json.loads(text)
                    except Exception: obj={}
                    return e.code, dict(e.headers), body, text, obj

        def network_diagnostic():
            btn_diag.configure(state='disabled'); btn_send.configure(state='disabled')
            start_timer(); log.configure(state='normal'); log.delete('1.0','end'); log.configure(state='disabled')
            set_status('🔎 مرحله 1/4: شروع تست شبکه...'); log_line('شروع تست؛ مرحله‌ها حداکثر چند ثانیه زمان می‌برند.')
            def run():
                import socket, time as tm, subprocess, json
                try:
                    # Stage 1: raw internet connectivity, no DNS dependency.
                    log_line('مرحله 1/4: تست اتصال خام اینترنت → 1.1.1.1:443 (حداکثر 3 ثانیه)')
                    set_status('⏳ مرحله 1/4: تست اتصال اینترنت...')
                    t=tm.time(); ok=False; err=''
                    try:
                        with socket.create_connection(('1.1.1.1',443),timeout=3): ok=True
                    except Exception as e: err=f'{type(e).__name__}: {e}'
                    if ok: log_line(f'  ✅ اتصال خام اینترنت برقرار است ({tm.time()-t:.1f}s)')
                    else: log_line(f'  ⚠️ اتصال خام برقرار نشد: {err}')

                    # Stage 2: DNS through Windows nslookup with a hard process timeout.
                    log_line('مرحله 2/4: DNS با nslookup (حداکثر 5 ثانیه)')
                    set_status('⏳ مرحله 2/4: بررسی DNS روبیکا...')
                    for host in ('getdcmess.iranlms.ir','web.rubika.ir'):
                        try:
                            cp=subprocess.run(['nslookup',host,'1.1.1.1'],capture_output=True,text=True,timeout=5,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                            text=(cp.stdout+'\n'+cp.stderr).strip().replace('\r','')
                            ips=[]
                            import re as _re
                            for m in _re.findall(r'(?:Address|Addresses|آدرس)[^:]*:\s*([0-9.]+)',text):
                                if m not in ips: ips.append(m)
                            if cp.returncode==0 and ips: log_line(f'  ✅ DNS {host}: '+', '.join(ips[:5]))
                            else: log_line(f'  ⚠️ DNS {host}: nslookup پاسخ قابل اتکا نداد. '+text[-350:])
                        except subprocess.TimeoutExpired: log_line(f'  ⏱️ DNS {host}: Timeout بعد از 5 ثانیه')
                        except Exception as e: log_line(f'  ❌ DNS {host}: {type(e).__name__}: {e}')

                    # Stage 3: Web HTTPS. Requests gets its own hard timeout.
                    log_line('مرحله 3/4: HTTPS به Web Rubika (حداکثر 8 ثانیه)')
                    set_status('⏳ مرحله 3/4: اتصال به Web Rubika...')
                    try:
                        hs={'User-Agent':'Mozilla/5.0','Accept':'text/html,*/*','Accept-Language':'fa-IR,fa;q=0.9'}
                        code_http, hdrs, body, txt, obj = _web_http_request('GET','https://web.rubika.ir/',hs,timeout=8)
                        log_line(f'  ✅ HTTP {code_http} | {len(body)} bytes | https://web.rubika.ir/')
                    except Exception as e: log_line(f'  ❌ HTTPS Web: {type(e).__name__}: {e}')

                    # Stage 4: Discovery endpoint. Never let an exception hide the result.
                    log_line('مرحله 4/4: Discovery روبیکا')
                    set_status('⏳ مرحله 4/4: بررسی Discovery روبیکا...')
                    try:
                        hs={'User-Agent':'Mozilla/5.0','Accept':'*/*'}
                        code_http, hdrs, body, txt, obj = _web_http_request('GET','https://getdcmess.iranlms.ir/',hs,timeout=8)
                        sample=txt[:500].replace('\n',' ')
                        log_line(f'  ✅ Discovery HTTP {code_http} | {len(body)} bytes | {sample}')
                    except Exception as e: log_line(f'  ❌ Discovery: {type(e).__name__}: {e}')
                    log_line('🏁 تشخیص شبکه پایان یافت.')
                    set_status('🟢 تشخیص شبکه تمام شد؛ گزارش کامل بالا قابل مشاهده است.')
                except Exception as e:
                    log_line('❌ خطای غیرمنتظره: '+type(e).__name__+': '+str(e)); set_status('🔴 تشخیص با خطا متوقف شد.')
                finally:
                    stop_timer(); finish_buttons()
            threading.Thread(target=run,daemon=True,name='rubika-network-diagnostic-v76').start()
            # UI watchdog: even if a system call misbehaves, never leave the window saying stage 1 forever.
            def watchdog():
                if op_started[0] is not None:
                    try: log_line('⏱️ ناظر UI: عملیات هنوز در حال اجراست؛ اگر یک مرحله پاسخ ندهد، گزارش timeout ثبت می‌شود.')
                    except Exception: pass
                    try: w.after(7000, watchdog)
                    except Exception: pass
            w.after(7000,watchdog)

        def _api6_helpers():
            """Local standard-library-only crypto helpers for Rubika API-v6."""
            import base64, json as _json, secrets, string
            from rubika_crypto_local import (
                aes_cbc_encrypt, aes_cbc_decrypt, rsa_generate,
                rsa_private_pem, rsa_public_pem, rsa_oaep_decrypt,
                rsa_sign_sha256, transform_auth, passphrase,
            )
            def secret32():
                return ''.join(secrets.choice(string.ascii_lowercase) for _ in range(32))
            def cipher_encrypt(secret, obj):
                raw=_json.dumps(obj).encode('utf-8')
                return base64.b64encode(aes_cbc_encrypt(raw,passphrase(secret))).decode('ascii')
            def cipher_decrypt(secret, value):
                raw=base64.urlsafe_b64decode(value.encode('ascii'))
                return _json.loads(aes_cbc_decrypt(raw,passphrase(secret)).decode('utf-8'))
            def rsa_pair():
                n,e,d,p,q=rsa_generate(1024)
                priv_pem=rsa_private_pem(n,e,d,p,q)
                pub_pem=rsa_public_pem(n,e)
                public_payload=transform_auth(base64.b64encode(pub_pem.encode('ascii')).decode('ascii'))
                return public_payload, priv_pem, (n,e,d,p,q)
            def decrypt_auth(priv, enc_auth):
                n,e,d,p,q=priv
                cipher=base64.b64decode(enc_auth.encode('ascii'))
                return rsa_oaep_decrypt(n,d,cipher).decode('utf-8').strip()
            def sign(priv, data_enc):
                n,e,d,p,q=priv
                return base64.b64encode(rsa_sign_sha256(n,d,data_enc.encode('utf-8'))).decode('ascii')
            return secret32,cipher_encrypt,cipher_decrypt,transform_auth,rsa_pair,decrypt_auth,sign

        def _api6_call(url, method_name, input_data, tmp_session=None, auth=None, private_key=None, timeout=10, client_profile='pwa'):
            import json as _json
            secret32,cipher_encrypt,cipher_decrypt,transform_auth,rsa_pair,decrypt_auth,sign = _api6_helpers()
            client_data=({'app_name':'Main','app_version':'2.4.6','platform':'PWA','package':'m.rubika.ir','lang_code':'fa'} if client_profile=='pwa' else {'app_name':'Main','app_version':'3.2.1','platform':'Web','package':'web.rubika.ir','lang_code':'fa'})
            inner={'method':method_name,'input':input_data,'client':client_data}
            secret=tmp_session or auth
            data_enc=cipher_encrypt(secret,inner)
            payload={'api_version':'6','data_enc':data_enc}
            if tmp_session:
                payload['tmp_session']=tmp_session
            else:
                payload['auth']=transform_auth(auth)
                payload['sign']=sign(private_key,data_enc)
            if client_profile == 'pwa':
                origin='https://m.rubika.ir'; referer='https://m.rubika.ir/'; ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36'
            else:
                origin='https://web.rubika.ir'; referer='https://web.rubika.ir/'; ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36'
            headers={
                'Accept':'application/json, text/plain, */*','Content-Type':'application/json',
                'Origin':origin,'Referer':referer,
                'Accept-Language':'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
                'User-Agent':ua
            }
            code_http,hdrs,body,txt,obj=_web_http_request('POST',url,headers=headers,json_data=payload,timeout=timeout)
            decoded=obj
            if isinstance(obj,dict) and isinstance(obj.get('data_enc'),str):
                decoded=cipher_decrypt(secret,obj['data_enc'])
                if isinstance(decoded,dict):
                    for k in ('status','status_det','message'):
                        if k not in decoded and k in obj: decoded[k]=obj[k]
            return code_http,body,txt,decoded

        def send_worker():
            try: phone98, phone_local=normalize_phone(phone.get())
            except Exception as e: return show_error('شماره موبایل',e)
            btn_send.configure(state='disabled'); btn_diag.configure(state='disabled'); start_timer(); log.configure(state='normal'); log.delete('1.0','end'); log.configure(state='disabled')
            set_status('⏳ شروع درخواست کد API6...'); log_line(f'شماره: +{phone98} | کشور: ایران | نوع: {send_type.get()}')
            def run():
                import time as tm
                try:
                    log_line('مرحله 1/4: Discovery با api_version=4 ...'); set_status('⏳ مرحله 1/4: دریافت سرورهای روبیکا...')
                    headers={'Accept':'application/json, text/plain, */*','Content-Type':'application/json','Origin':'https://web.rubika.ir','Referer':'https://web.rubika.ir/','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36'}
                    t=tm.time(); rd_code, rd_headers, rd_body, rd_text, discovery=_web_http_request('POST','https://getdcmess.iranlms.ir/',headers=headers,json_data={'api_version':'4'},timeout=8)
                    hosts=extract_hosts(discovery)
                    log_line(f'  Discovery HTTP {rd_code} | {len(rd_body)} bytes | {tm.time()-t:.1f}s')
                    if rd_code!=200 or not hosts: raise RuntimeError(f'Discovery ناموفق بود: HTTP {rd_code} / hosts={len(hosts)}')
                    candidates=[h.rstrip('/')+'/' for h in hosts if 'messengerg2' in h]
                    seen=set(); candidates=[x for x in candidates if not (x in seen or seen.add(x))]
                    log_line(f'  ✅ {len(candidates)} سرور API پیدا شد.')
                    for h in candidates[:10]: log_line('  • '+h)
                    tmp_session= _api6_helpers()[0]()
                    state['tmp_session']=tmp_session
                    log_line('مرحله 2/4: ساخت tmp_session و رمزنگاری API6 ...')
                    log_line('  ✅ tmp_session ساخته شد (32 کاراکتر؛ مقدار آن در گزارش نمایش داده نمی‌شود).')
                    input_data={'phone_number':phone98,'pass_key':None,'send_type':send_type.get()}
                    log_line('مرحله 3/4: sendCode API6 به اولین سرورها ...'); set_status('⏳ مرحله 3/4: ارسال درخواست کد رمزنگاری‌شده...')
                    last=''
                    for i,url in enumerate(candidates[:12],1):
                        log_line(f'  تلاش {i}/{min(12,len(candidates))}: {url}')
                        try:
                            t=tm.time(); rc,body,txt,obj=_api6_call(url,'sendCode',input_data,tmp_session=tmp_session,timeout=10,client_profile='pwa')
                            log_line(f'    PWA client → HTTP {rc} | {len(body)} bytes | {tm.time()-t:.1f}s')
                            st0=str(obj.get('status','?')) if isinstance(obj,dict) else '?'
                            if st0.upper() not in ('OK','SUCCESS'):
                                log_line('    PWA رد شد؛ همان سرور با client=Web امتحان می‌شود ...')
                                t2=tm.time(); rc,body,txt,obj=_api6_call(url,'sendCode',input_data,tmp_session=tmp_session,timeout=10,client_profile='web')
                                log_line(f'    Web client → HTTP {rc} | {len(body)} bytes | {tm.time()-t2:.1f}s')
                            st=str(obj.get('status','?')); det=str(obj.get('status_det',obj.get('error_code','?')))
                            log_line(f'    status={st} | status_det={det}')
                            log_line('    پاسخ رمزگشایی‌شده: '+_json_safe(obj)[:1200])
                            h=recursive_find(obj,['phone_code_hash','phoneCodeHash','code_hash'])
                            if h or st.upper() in ('OK','SUCCESS'):
                                state['hash']=str(h or '').strip(); state['raw']=txt[:4000]
                                self.db.set('rubika_user_phone',phone_local); self.db.set('rubika_user_group_guid',guid.get().strip()); self.db.set('rubika_user_tmp_session',tmp_session)
                                self.after(0,lambda:(btn_send.configure(state='normal'),btn_diag.configure(state='normal'),btn_login.configure(state='normal'),code_ent.focus_set(),status.set('🟢 کد درخواست شد؛ کد تأیید روبیکا را وارد کن.')))
                                log_line('✅ sendCode API6 پذیرفته شد.')
                                log_line('مرحله 4/4: منتظر ورود کد تأیید هستیم.')
                                return
                            last=_json_safe(obj)
                        except Exception as e:
                            last=f'{type(e).__name__}: {e}'; log_line('    ❌ '+last)
                    raise RuntimeError('هیچ سرور API6 درخواست sendCode را نپذیرفت. آخرین پاسخ: '+str(last)[:1500])
                except Exception as e:
                    ui(lambda: (btn_send.configure(state='normal'),btn_diag.configure(state='normal')))
                    show_error('دریافت کد API6',str(e)); log_line('❌ پایان با خطا: '+str(e))
                finally: stop_timer()
            def _json_safe(obj):
                import json as _j
                try:
                    return _j.dumps(obj,ensure_ascii=False,default=str)
                except Exception: return str(obj)
            threading.Thread(target=run,daemon=True,name='rubika-send-code-v80-api6').start()

        btn_diag.configure(command=network_diagnostic); btn_send.configure(command=send_worker)
        def login_worker():
            ph=phone.get().strip(); cd=code.get().strip(); tmp_session=state.get('tmp_session') or self.db.get('rubika_user_tmp_session','').strip()
            if not ph or not cd or not state['hash'] or not tmp_session:
                return show_error('ورود','ابتدا «دریافت کد» را با موفقیت انجام دهید و سپس کد تأیید را وارد کنید.')
            btn_login.configure(state='disabled'); btn_send.configure(state='disabled'); btn_diag.configure(state='disabled'); start_timer()
            self.db.set('rubika_user_phone',ph); self.db.set('rubika_user_group_guid',guid.get().strip())
            def run_login():
                try:
                    import json as _j
                    helpers=_api6_helpers(); rsa_pair=helpers[4]; decrypt_auth=helpers[5]
                    public_payload, private_pem, private_obj=rsa_pair()
                    candidates=[]
                    # Reuse discovery hosts; if not available, fetch again.
                    headers={'Accept':'application/json, text/plain, */*','Content-Type':'application/json','Origin':'https://web.rubika.ir','Referer':'https://web.rubika.ir/','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36'}
                    rc,hh,bb,tt,disc=_web_http_request('POST','https://getdcmess.iranlms.ir/',headers=headers,json_data={'api_version':'4'},timeout=8)
                    candidates=[h.rstrip('/')+'/' for h in extract_hosts(disc) if 'messengerg2' in h]
                    input_data={'phone_code':cd,'phone_number':normalize_phone(ph)[0],'phone_code_hash':state['hash'],'public_key':public_payload}
                    log_line('مرحله ورود 1/2: کلید RSA ساخته شد و signIn API6 شروع شد.')
                    last=''
                    for i,url in enumerate(candidates[:12],1):
                        log_line(f'  signIn تلاش {i}/{min(12,len(candidates))}: {url}')
                        try:
                            rc,body,txt,obj=_api6_call(url,'signIn',input_data,tmp_session=tmp_session,timeout=10)
                            st=str(obj.get('status','?')); det=str(obj.get('status_det',obj.get('error_code','?')))
                            log_line(f'    HTTP {rc} | status={st} | status_det={det}')
                            log_line('    پاسخ signIn: '+_j.dumps({k:v for k,v in obj.items() if k not in ('auth','data_enc')},ensure_ascii=False,default=str)[:1000])
                            auth_val=recursive_find(obj,['auth','session','session_auth'])
                            if auth_val:
                                try: auth=decrypt_auth(private_obj,str(auth_val)) if len(str(auth_val).strip())!=32 else str(auth_val).strip()
                                except Exception: auth=str(auth_val).strip()
                                if len(auth)==32:
                                    self.db.set('rubika_user_auth',auth)
                                    self.db.set('rubika_user_private_key',private_pem)
                                    self.db.set('rubika_user_session','API6:'+auth)
                                    self.db.set('rubika_user_tmp_session','')
                                    status.set('🟢 ورود Web موفق شد؛ Session واقعی API6 ذخیره شد.')
                                    log_line('✅ signIn موفق شد و auth واقعی 32 کاراکتری ذخیره شد.')
                                    log_line('🔐 private key ذخیره شد؛ مقدار آن در گزارش نمایش داده نمی‌شود.')
                                    messagebox.showinfo('ورود موفق','ورود حساب روبیکا با API6 انجام شد و Session واقعی ذخیره شد.',parent=w)
                                    btn_login.configure(state='normal'); btn_send.configure(state='normal'); btn_diag.configure(state='normal'); stop_timer(); return
                            last=_j.dumps(obj,ensure_ascii=False,default=str)
                        except Exception as e:
                            last=f'{type(e).__name__}: {e}'; log_line('    ❌ '+last)
                    raise RuntimeError('signIn موفق نشد. آخرین پاسخ: '+last[:1500])
                except Exception as e:
                    stop_timer(); ui(lambda:(btn_login.configure(state='normal'),btn_send.configure(state='normal'),btn_diag.configure(state='normal')))
                    log_line('❌ پایان ورود: '+str(e)); set_status('🔴 ورود API6 ناموفق: '+str(e))
                    ui(lambda: messagebox.showerror('ورود API6',str(e),parent=w))
            threading.Thread(target=run_login,daemon=True,name='rubika-signin-v80-api6').start()
        btn_login.configure(command=login_worker)
        if self.db.get('rubika_user_session','').strip(): status.set('🟢 Session قبلی در تنظیمات ثبت شده است.')

    def _rubika_user_sync_group_members(self, crm_group_id):
        session=self.db.get('rubika_user_session','').strip()
        group_guid=self.db.get('rubika_user_group_guid','').strip()
        if not session:
            self._rubika_user_session_settings(); return
        if not group_guid:
            messagebox.showwarning('گروه روبیکا','GUID گروه واقعی روبیکا تنظیم نشده است. ابتدا «اتصال حساب روبیکا» را باز کنید.',parent=self); return
        rows=self.db.c.execute("SELECT c.id,c.first_name,c.last_name,c.mobile,c.rubika_chat_id FROM contacts c JOIN contact_groups cg ON cg.contact_id=c.id WHERE cg.group_id=? ORDER BY c.id",(crm_group_id,)).fetchall()
        if not rows: messagebox.showinfo('مخاطبان','این گروه CRM مخاطبی ندارد.',parent=self); return
        def norm(v): return ' '.join(str(v or '').strip().lower().replace('ي','ی').replace('ك','ک').split())
        def worker(progress):
            try:
                from rubpy import Client
            except Exception as e:
                raise RuntimeError('کتابخانه rubpy نصب نیست. فایل install.bat را اجرا کنید و دوباره امتحان کنید.\n\n'+str(e))
            import asyncio, inspect
            members=[]; start=None; loops=0
            async def fetch_members():
                client=Client(session)
                try:
                    nonlocal start, loops
                    while loops<100:
                        loops+=1; progress(min(85,10+loops*5),f'دریافت اعضای گروه روبیکا... صفحه {loops}')
                        res=client.get_members(group_guid,start_id=start)
                        if inspect.isawaitable(res): res=await res
                        if not res: break
                        chunk=getattr(res,'in_chat_members',None) or (res.get('in_chat_members') if isinstance(res,dict) else []) or []
                        if isinstance(chunk,dict): chunk=[chunk]
                        members.extend(chunk)
                        has=getattr(res,'has_continue',None) if not isinstance(res,dict) else res.get('has_continue',False)
                        nxt=getattr(res,'next_start_id',None) if not isinstance(res,dict) else res.get('next_start_id')
                        if not has or not nxt or str(nxt)==str(start): break
                        start=nxt
                finally:
                    try:
                        close=getattr(client,'disconnect',None)
                        if close:
                            r=close()
                            if inspect.isawaitable(r): await r
                    except Exception: pass
                return members
            return asyncio.run(fetch_members())
        def done(members,err):
            if err:
                messagebox.showerror('دریافت اعضای روبیکا',str(err),parent=self); return
            def getv(m,*keys):
                if isinstance(m,dict):
                    for k in keys:
                        if m.get(k) not in (None,''): return m.get(k)
                else:
                    for k in keys:
                        try:
                            v=getattr(m,k,None)
                            if v not in (None,''): return v
                        except: pass
                return ''
            parsed=[]
            for m in members:
                guid=str(getv(m,'member_guid','user_guid','user_id','guid','chat_id')).strip()
                fn=str(getv(m,'first_name','firstName')).strip(); ln=str(getv(m,'last_name','lastName')).strip(); un=str(getv(m,'username','user_name')).strip()
                if guid: parsed.append({'guid':guid,'first_name':fn,'last_name':ln,'username':un})
            matched=[]; unmatched=[]; used=set()
            by_full={}
            for r in rows:
                key=norm((r['first_name'] or '')+' '+(r['last_name'] or ''))
                if key: by_full.setdefault(key,[]).append(r)
            for m in parsed:
                key=norm(m['first_name']+' '+m['last_name'])
                cand=[r for r in by_full.get(key,[]) if r['id'] not in used]
                if len(cand)==1:
                    self.db.q('UPDATE contacts SET rubika_chat_id=? WHERE id=?',(m['guid'],cand[0]['id'])); used.add(cand[0]['id']); matched.append((cand[0],m))
                else: unmatched.append(m)
            # show all real members and matching status, with manual assign buttons
            w=tk.Toplevel(self); w.title('اعضای واقعی گروه روبیکا'); w.geometry('980x650'); w.configure(bg='#f8fafc'); w.transient(self); w.grab_set()
            tk.Label(w,text=f'اعضای واقعی روبیکا: {len(parsed):,} | تطبیق خودکار: {len(matched):,} | بدون تطبیق: {len(unmatched):,}',bg='#0f3d63',fg='white',font=('Tahoma',12,'bold')).pack(fill='x',ipady=12)
            tk.Label(w,text='تطبیق خودکار فقط وقتی انجام شده که نام و نام خانوادگی CRM دقیقاً با عضو روبیکا یکی بوده است. موارد باقی‌مانده را می‌توانید دستی به مخاطب انتخاب‌شده اختصاص دهید.',bg='#f8fafc',fg='#475569',font=('Tahoma',9),justify='right',wraplength=900).pack(anchor='e',padx=18,pady=10)
            body=tk.Frame(w,bg='#f8fafc'); body.pack(fill='both',expand=True,padx=14); canvas=tk.Canvas(body,bg='#f8fafc',highlightthickness=0); sb=ttk.Scrollbar(body,orient='vertical',command=canvas.yview); inner=tk.Frame(canvas,bg='#f8fafc'); cw=canvas.create_window((0,0),window=inner,anchor='nw'); canvas.configure(yscrollcommand=sb.set); canvas.pack(side='left',fill='both',expand=True); sb.pack(side='right',fill='y'); inner.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all'))); canvas.bind('<Configure>',lambda e:canvas.itemconfigure(cw,width=e.width))
            crm_opts=[(r['id'],((r['first_name'] or '')+' '+(r['last_name'] or '')).strip()) for r in rows]
            sel=tk.StringVar(value='')
            ttk.Combobox(w,textvariable=sel,values=[f'{i}:{n}' for i,n in crm_opts],state='readonly',font=('Tahoma',9)).pack(fill='x',padx=18,pady=6)
            def assign(m):
                raw=sel.get();
                if ':' not in raw: messagebox.showwarning('اختصاص','ابتدا یک مخاطب CRM را انتخاب کنید.',parent=w); return
                cid=int(raw.split(':',1)[0]); self.db.q('UPDATE contacts SET rubika_chat_id=? WHERE id=?',(m['guid'],cid)); messagebox.showinfo('ذخیره شد','Chat ID به مخاطب انتخاب‌شده اختصاص یافت.',parent=w); w.destroy()
            for m in parsed:
                full=(m['first_name']+' '+m['last_name']).strip() or 'بدون نام'
                card=tk.Frame(inner,bg='white',height=46,highlightbackground='#dbe3ea',highlightthickness=1); card.pack(fill='x',pady=2); card.pack_propagate(False)
                tk.Label(card,text=full,bg='white',fg='#0f3d63',font=('Tahoma',9,'bold')).pack(side='right',padx=10); tk.Label(card,text=m['guid'],bg='white',fg='#64748b',font=('Consolas',8)).pack(side='right',padx=10)
                if any(mm[1]['guid']==m['guid'] for mm in matched): tk.Label(card,text='🟢 تطبیق شد',bg='white',fg='#16805b',font=('Tahoma',8,'bold')).pack(side='left',padx=10)
                else: tk.Button(card,text='اختصاص به مخاطب انتخاب‌شده',command=lambda m=m:assign(m),bg='#eff6ff',fg='#0f3d63',relief='flat',font=('Tahoma',8)).pack(side='left',padx=8)
            self.button(w,'بستن',w.destroy).pack(anchor='w',padx=18,pady=10)
        self.run_with_progress('دریافت اعضای روبیکا','در حال خواندن اعضای گروه واقعی روبیکا...',100,worker,done)

    def _send_rubika_user_message(self, chat_id, text):
        session=self.db.get('rubika_user_session','').strip()
        if not session: return False,'Session حساب روبیکا تنظیم نشده است.'
        try:
            import asyncio, inspect
            from rubpy import Client
            async def do_send():
                client=Client(session, lang_code='fa', timeout=15, max_retries=1)
                try:
                    res=client.send_message(str(chat_id), text)
                    if inspect.isawaitable(res): res=await res
                    return res
                finally:
                    try:
                        close=getattr(client,'disconnect',None)
                        if close:
                            r=close()
                            if inspect.isawaitable(r): await r
                    except Exception: pass
            asyncio.run(do_send())
            return True,'پیام با موفقیت از حساب روبیکا ارسال شد.'
        except Exception as e:
            return False,str(e)

    def _rubika_link_manager(self, group_id):
        """One-time, deterministic user-to-bot linking using a code sent to the bot.
        This avoids unsafe name/phone guessing and lets getUpdates map an exact contact to an exact chat_id.
        """
        rows=self.db.c.execute("SELECT c.id,c.first_name,c.last_name,c.mobile,c.rubika_chat_id,c.rubika_link_code FROM contacts c JOIN contact_groups cg ON cg.contact_id=c.id WHERE cg.group_id=? ORDER BY c.id",(group_id,)).fetchall()
        if not rows:
            messagebox.showinfo('اتصال روبیکا','این گروه مخاطبی ندارد.',parent=self); return
        w=tk.Toplevel(self); w.title('اتصال یک‌باره مخاطبان به روبیکا'); w.geometry('860x620'); w.minsize(760,500); w.configure(bg='#f8fafc'); w.transient(self); w.grab_set()
        tk.Label(w,text='اتصال یک‌باره مخاطبان به روبیکا',bg='#0f3d63',fg='white',font=('Tahoma',13,'bold')).pack(fill='x',anchor='e',padx=18,pady=12)
        tk.Label(w,text='هر مخاطب فقط یک‌بار کد مخصوص خودش را برای همین Bot ارسال می‌کند. بعد از آن برنامه Chat ID واقعی همان مخاطب را خودکار ذخیره می‌کند.',bg='#f8fafc',fg='#334155',font=('Tahoma',9),justify='right',wraplength=780).pack(anchor='e',padx=18,pady=(12,8))
        bodyw=tk.Frame(w,bg='#f8fafc'); bodyw.pack(fill='both',expand=True,padx=14,pady=6)
        canvas=tk.Canvas(bodyw,bg='#f8fafc',highlightthickness=0); sb=ttk.Scrollbar(bodyw,orient='vertical',command=canvas.yview); body=tk.Frame(canvas,bg='#f8fafc'); cw=canvas.create_window((0,0),window=body,anchor='nw'); canvas.configure(yscrollcommand=sb.set); canvas.pack(side='left',fill='both',expand=True); sb.pack(side='right',fill='y'); body.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all'))); canvas.bind('<Configure>',lambda e:canvas.itemconfigure(cw,width=e.width))
        for r in rows:
            code=(r['rubika_link_code'] or '').strip()
            if not code:
                code='SMR-'+uuid.uuid4().hex[:6].upper()
                self.db.q('UPDATE contacts SET rubika_link_code=? WHERE id=?',(code,r['id']))
            full=((r['first_name'] or '')+' '+(r['last_name'] or '')).strip() or 'بدون نام'
            card=tk.Frame(body,bg='white',highlightbackground='#dbe3ea',highlightthickness=1,height=56); card.pack(fill='x',pady=3); card.pack_propagate(False)
            tk.Label(card,text=full,bg='white',fg='#0f3d63',font=('Tahoma',9,'bold')).pack(side='right',padx=12)
            tk.Label(card,text=f'کد اتصال: {code}',bg='white',fg='#b45309',font=('Consolas',10,'bold')).pack(side='right',padx=12)
            st='🟢 متصل' if (r['rubika_chat_id'] or '').strip() else '🟠 منتظر اتصال'
            tk.Label(card,text=st,bg='white',fg=('#16805b' if st.startswith('🟢') else '#b45309'),font=('Tahoma',8,'bold')).pack(side='right',padx=8)
            def copy_code(c=code):
                try:
                    self.clipboard_clear(); self.clipboard_append(c); self.update()
                    messagebox.showinfo('کپی کد',f'کد {c} کپی شد.',parent=w)
                except Exception: pass
            tk.Button(card,text='کپی کد',command=copy_code,bg='#eff6ff',fg='#0f3d63',relief='flat',font=('Tahoma',8)).pack(side='left',padx=8)
        foot=tk.Frame(w,bg='white'); foot.pack(fill='x',padx=14,pady=8)
        tk.Label(foot,text='مخاطب باید کد را دقیقاً به Bot ارسال کند؛ بعد «دریافت/تطبیق Chat ID ها» را بزنید.',bg='white',fg='#475569',font=('Tahoma',9)).pack(side='right',padx=8)
        self.button(foot,'👥 دریافت اعضای واقعی روبیکا',lambda:(w.destroy(),self._rubika_user_sync_group_members(group_id)),True).pack(side='left',padx=4)
        self.button(foot,'بستن',w.destroy).pack(side='left',padx=4)

    def _rubika_auto_assign_group_chat_ids(self, group_id):
        """Discover real user<->bot chat IDs from updates and assign them safely.
        A chat ID can only be discovered after that user has interacted with the bot.
        The bot's own ID is explicitly excluded.
        """
        token=self.db.get('rubika_token','').strip()
        if not token:
            messagebox.showwarning('تنظیمات روبیکا','ابتدا Token روبیکا را در تنظیمات ذخیره کنید.',parent=self); return
        base=(self.db.get('rubika_api_base','').strip() or 'https://botapi.rubika.ir/v3').rstrip('/')
        rows=self.db.c.execute("SELECT c.id,c.first_name,c.last_name,c.mobile,c.rubika_chat_id,c.rubika_link_code FROM contacts c JOIN contact_groups cg ON cg.contact_id=c.id WHERE cg.group_id=? ORDER BY c.id",(group_id,)).fetchall()
        if not rows:
            messagebox.showinfo('مخاطبان','این گروه مخاطبی ندارد.',parent=self); return
        def norm(v):
            x=str(v or '').strip().lower().replace('ي','ی').replace('ك','ک')
            return ' '.join(x.split())
        def norm_phone(v):
            d=re.sub(r'\D','',str(v or ''))
            if d.startswith('0098'): d='98'+d[4:]
            if d.startswith('98') and len(d)==12: d='0'+d[2:]
            if len(d)==10 and d.startswith('9'): d='0'+d
            return d
        def walk_values(obj, keys):
            out=[]
            if isinstance(obj,dict):
                for k,v in obj.items():
                    if k in keys and isinstance(v,(str,int)) and str(v).strip(): out.append(str(v).strip())
                    out += walk_values(v,keys)
            elif isinstance(obj,list):
                for v in obj: out += walk_values(v,keys)
            return out
        def get_update_chat_id(u):
            # Prefer the update's chat_id. Never take a generic ID from the bot/getMe response.
            if isinstance(u,dict):
                for root in (u, u.get('update'), u.get('new_message'), u.get('message')):
                    if isinstance(root,dict):
                        for k in ('chat_id','chatId'):
                            v=root.get(k)
                            if isinstance(v,(str,int)) and str(v).strip(): return str(v).strip()
            return ''
        def get_sender_id(u):
            vals=walk_values(u,{'sender_id','senderId'})
            return vals[0] if vals else ''
        def get_name(u):
            if not isinstance(u,dict): return ''
            roots=[u]
            for k in ('update','new_message','message','sender','user','author','from','chat'):
                v=u.get(k)
                if isinstance(v,dict): roots.append(v)
            for obj in roots:
                fn=str(obj.get('first_name') or obj.get('firstName') or '').strip()
                ln=str(obj.get('last_name') or obj.get('lastName') or '').strip()
                if fn or ln: return (fn+' '+ln).strip()
                for k in ('name','username','user_name','title'):
                    v=str(obj.get(k) or '').strip()
                    if v: return v
            return ''
        def get_phone(u):
            vals=walk_values(u,{'phone_number','phoneNumber','phone','mobile','mobile_number'})
            return norm_phone(vals[0]) if vals else ''
        def extract_updates(data):
            found=[]
            def walk(o):
                if isinstance(o,dict):
                    if isinstance(o.get('updates'),list): found.extend(o['updates'])
                    for v in o.values():
                        if isinstance(v,(dict,list)): walk(v)
                elif isinstance(o,list):
                    for v in o: walk(v)
            walk(data)
            # de-duplicate by serialized content
            out=[]; seen=set()
            for u in found:
                key=json.dumps(u,ensure_ascii=False,sort_keys=True,default=str)
                if key not in seen: seen.add(key); out.append(u)
            return out
        def worker():
            payload={'limit':100}
            req=urllib.request.Request(f'{base}/{token}/getUpdates',data=json.dumps(payload).encode('utf-8'),headers={'Content-Type':'application/json','User-Agent':'SMS-Manager/1.0'},method='POST')
            with self._urlopen(req,timeout=25) as r: raw=r.read().decode('utf-8','replace')
            data=json.loads(raw)
            updates=extract_updates(data)
            bot_ids=self._rubika_get_bot_identity()
            # Exact one-time connection mapping: SMR-XXXXXX sent by a contact to the bot.
            code_to_row={str(r['rubika_link_code'] or '').strip().upper():r for r in rows if str(r['rubika_link_code'] or '').strip()}
            code_matches=[]
            for u in updates:
                chat=get_update_chat_id(u)
                if not chat or chat in bot_ids: continue
                raw_texts=[]
                def collect_text(o):
                    if isinstance(o,dict):
                        for k,v in o.items():
                            if k in ('text','message','body','raw_text','rawText') and isinstance(v,str): raw_texts.append(v)
                            elif isinstance(v,(dict,list)): collect_text(v)
                    elif isinstance(o,list):
                        for v in o: collect_text(v)
                collect_text(u)
                for txt in raw_texts:
                    m=re.search(r'\bSMR-[A-Z0-9]{6}\b',txt.upper())
                    if m and m.group(0) in code_to_row:
                        code_matches.append((m.group(0),chat,code_to_row[m.group(0)])); break
            for code,chat,row in code_matches:
                self.db.q('UPDATE contacts SET rubika_chat_id=? WHERE id=?',(chat,row['id']))
            code_matched_ids={r['id'] for _,_,r in code_matches}
            candidates={chat:{'name':(row['first_name'] or '')+' '+(row['last_name'] or ''),'phone':norm_phone(row['mobile']),'sender_id':''} for _,chat,row in code_matches}
            for u in updates:
                chat=get_update_chat_id(u)
                if not chat or chat in bot_ids: continue
                candidates.setdefault(chat,{'name':get_name(u),'phone':get_phone(u),'sender_id':get_sender_id(u)})
            by_full={}; by_first={}; by_phone={}
            for r in rows:
                full=norm((r['first_name'] or '')+' '+(r['last_name'] or ''))
                first=norm(r['first_name']); ph=norm_phone(r['mobile'])
                if full: by_full.setdefault(full,[]).append(r)
                if first: by_first.setdefault(first,[]).append(r)
                if ph: by_phone.setdefault(ph,[]).append(r)
            matches=[(row['id'],chat,((row['first_name'] or '')+' '+(row['last_name'] or '')).strip(),'',norm_phone(row['mobile'])) for _,chat,row in code_matches]; unmatched=[]; used={m[0] for m in matches}
            code_chat_ids={m[1] for m in matches}
            for chat,info in candidates.items():
                if chat in code_chat_ids: continue
                choices=[]
                if info['phone'] and len(by_phone.get(info['phone'],[]))==1: choices=by_phone[info['phone']]
                if not choices and info['name']:
                    n=norm(info['name'])
                    if len(by_full.get(n,[]))==1: choices=by_full[n]
                    elif len(by_first.get(n,[]))==1: choices=by_first[n]
                if len(choices)==1 and choices[0]['id'] not in used:
                    r=choices[0]; used.add(r['id']); matches.append((r['id'],chat,(r['first_name'] or '')+' '+(r['last_name'] or ''),info['name'],info['phone']))
                else: unmatched.append((chat,info['name'],info['phone']))
            return matches,unmatched,len(candidates),len(updates),len(bot_ids)
        def finish(result,win):
            try: matches,unmatched,total,updates_count,bot_count=result
            except Exception as e:
                messagebox.showerror('دریافت Chat ID','خطا: '+str(e),parent=win); return
            for cid,chatid,cn,_,_ in matches:
                self.db.q('UPDATE contacts SET rubika_chat_id=? WHERE id=?',(chatid,cid))
            text=[f'Updateهای دریافت‌شده: {updates_count:,}',f'چت‌های کاربری قابل استفاده: {total:,}',f'تطبیق و ذخیره شد: {len(matches):,}',f'بدون تطبیق قطعی: {len(unmatched):,}','','نکته: Chat ID فقط برای کاربرانی قابل کشف است که قبلاً با Bot تعامل کرده‌اند.']
            if bot_count: text.append('شناسه‌های مربوط به خود Bot از ارسال حذف شدند.')
            if matches:
                text.append('\nذخیره‌شده‌ها:'); text.extend([f'✓ {cn} ← {chatid}' for _,chatid,cn,_,_ in matches[:30]])
            if unmatched:
                text.append('\nبدون تطبیق:'); text.extend([f'• {nm or "نام ناشناخته"} | {ph or "بدون موبایل"} ← {chatid}' for chatid,nm,ph in unmatched[:30]])
            messagebox.showinfo('نتیجه دریافت خودکار','\n'.join(text),parent=win)
        def runner():
            try: result=worker(); self.after(0,lambda:finish(result,self))
            except Exception as e: self.after(0,lambda:messagebox.showerror('دریافت Chat ID',str(e),parent=self))
        threading.Thread(target=runner,daemon=True).start()

    def show_internal_campaigns(self):
        self.clear(); self.header('کمپین شبکه‌های داخلی','ارسال واقعی به Chat ID هر مخاطب؛ «ارسال تست» فقط برای مقصد آزمایشی است')
        f=tk.Frame(self.main,bg='white'); f.pack(fill='both',expand=True,padx=28,pady=8)
        top=tk.Frame(f,bg='white'); top.pack(fill='x',padx=30,pady=(14,4))
        tk.Label(top,text='کانال ارسال',bg='white',font=('Tahoma',9)).pack(anchor='e')
        kind_var=tk.StringVar(value='RUBIKA'); kind_cb=ttk.Combobox(top,textvariable=kind_var,values=['RUBIKA','EITAA','BALE'],state='readonly',justify='right'); kind_cb.pack(fill='x',ipady=4,pady=(2,0))
        tk.Label(top,text='منبع مخاطبان: گروه‌های داخلی',bg='white',fg='#64748b',font=('Tahoma',9)).pack(anchor='e',pady=(7,2))
        groups=self.db.c.execute('SELECT id,name FROM groups ORDER BY name').fetchall(); group_var=tk.StringVar(); group_cb=ttk.Combobox(top,textvariable=group_var,values=[x['name'] for x in groups],state='readonly',justify='right'); group_cb.pack(fill='x',ipady=4)
        tk.Label(f,text='متن پیام — از {نام}، {نام خانوادگی} و {موبایل} استفاده کنید',bg='white',font=('Tahoma',9)).pack(anchor='e',padx=30,pady=(10,2))
        msg=tk.Text(f,height=6,font=('Tahoma',10)); msg.pack(fill='x',padx=30); msg.insert('1.0','سلام {نام} {نام خانوادگی}،\nاین پیام از طرف مجموعه ما ارسال شده است.')
        status=tk.StringVar(value='یک گروه را انتخاب کنید.'); tk.Label(f,textvariable=status,bg='white',fg='#64748b',font=('Tahoma',9)).pack(anchor='e',padx=30,pady=7)
        actions=tk.Frame(f,bg='white'); actions.pack(fill='x',padx=30,pady=(2,12))
        current={'results':[],'invalid':[],'total':0,'group_id':None,'channel':None,'selected_rows':set()}
        def render_text(t,x): return t.replace('{نام}',str(x.get('first_name','') or '')).replace('{نام خانوادگی}',str(x.get('last_name','') or '')).replace('{موبایل}',str(x.get('mobile','') or ''))
        def refresh_audience():
            gn=group_var.get(); gid=next((x['id'] for x in groups if x['name']==gn),None)
            if not gid: return
            ch=kind_var.get().upper(); r,inv,total=self._build_local_audience(gid,ch)
            current.update(results=r,invalid=inv,total=total,group_id=gid,channel=ch)
            # Keep only selections that still exist.
            current['selected_rows']={str(x['row']) for x in r} if not current.get('selected_rows') else {str(x['row']) for x in r if str(x['row']) in current['selected_rows']}
            status.set(f'کل اعضا: {total:,} | دارای Chat ID: {len(r):,} | بدون Chat ID: {len(inv):,} | انتخاب‌شده: {len(current["selected_rows"]):,}')
        def open_selector():
            gn=group_var.get(); gid=next((x['id'] for x in groups if x['name']==gn),None)
            if not gid: messagebox.showwarning('گروه','ابتدا یک گروه انتخاب کنید.',parent=self); return
            refresh_audience(); r=list(current['results']); inv=list(current['invalid']); total=current['total']; selected=set(current['selected_rows'])
            w=tk.Toplevel(self); w.title('انتخاب نفرات و پیش‌نمایش پیام'); w.geometry('900x600'); w.minsize(760,500); w.configure(bg='#f8fafc'); w.transient(self); w.grab_set()
            head=tk.Frame(w,bg='#0f3d63'); head.pack(fill='x'); tk.Label(head,text=f'انتخاب نفرات برای ارسال — {self._internal_channel_meta(kind_var.get())[0]}',bg='#0f3d63',fg='white',font=('Tahoma',13,'bold')).pack(anchor='e',padx=18,pady=(10,2)); tk.Label(head,text='فقط افراد تیک‌خورده پیام دریافت می‌کنند.',bg='#0f3d63',fg='#dbeafe',font=('Tahoma',9)).pack(anchor='e',padx=18,pady=(0,10))
            bar=tk.Frame(w,bg='white'); bar.pack(fill='x',padx=12,pady=8)
            count=tk.StringVar(); tk.Label(bar,textvariable=count,bg='white',fg='#0f3d63',font=('Tahoma',9,'bold')).pack(side='right',padx=8)
            def upd(): count.set(f'انتخاب‌شده: {len(selected):,} از {len(r):,} نفر'); status.set(f'کل اعضا: {total:,} | دارای Chat ID: {len(r):,} | بدون Chat ID: {len(inv):,} | انتخاب‌شده: {len(selected):,}')
            self.button(bar,'👥 دریافت اعضای واقعی روبیکا',lambda:(w.destroy(),self._rubika_user_sync_group_members(gid)) if kind_var.get().upper()=='RUBIKA' else messagebox.showinfo('راهنما','این گزینه فعلاً برای روبیکا فعال است.',parent=w)).pack(side='left',padx=3)
            self.button(bar,'🔗 اتصال یک‌باره',lambda:(w.destroy(),self._rubika_link_manager(gid)) if kind_var.get().upper()=='RUBIKA' else messagebox.showinfo('راهنما','اتصال یک‌باره فعلاً برای روبیکا فعال است.',parent=w)).pack(side='left',padx=3)
            bodyw=tk.Frame(w,bg='#f8fafc'); bodyw.pack(fill='both',expand=True,padx=12,pady=(0,6)); canvas=tk.Canvas(bodyw,bg='#f8fafc',highlightthickness=0); sb=ttk.Scrollbar(bodyw,orient='vertical',command=canvas.yview); body=tk.Frame(canvas,bg='#f8fafc'); cw=canvas.create_window((0,0),window=body,anchor='nw'); canvas.configure(yscrollcommand=sb.set); canvas.pack(side='left',fill='both',expand=True); sb.pack(side='right',fill='y'); body.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all'))); canvas.bind('<Configure>',lambda e:canvas.itemconfigure(cw,width=e.width))
            vars={}
            def message_preview(x):
                pv=tk.Toplevel(w); pv.title('پیش‌نمایش پیام'); pv.geometry('560x330'); pv.configure(bg='white'); pv.transient(w); pv.grab_set(); full=(str(x.get('first_name',''))+' '+str(x.get('last_name',''))).strip(); tk.Label(pv,text='متن دقیق پیام برای '+(full or 'مخاطب'),bg='white',fg='#0f3d63',font=('Tahoma',12,'bold')).pack(anchor='e',padx=18,pady=12); box=tk.Text(pv,font=('Tahoma',10),wrap='word',bg='#f8fafc',relief='solid',bd=1); box.pack(fill='both',expand=True,padx=18,pady=5); box.insert('1.0',render_text(msg.get('1.0','end').strip(),x)); box.configure(state='disabled'); tk.Button(pv,text='بستن',command=pv.destroy,bg='#0f3d63',fg='white',relief='flat',padx=20,pady=6).pack(anchor='e',padx=18,pady=12)
            for i,x in enumerate(r,1):
                rid=str(x['row']); v=tk.IntVar(value=1 if rid in selected else 0); vars[rid]=v; card=tk.Frame(body,bg='white',height=52,highlightbackground='#dbe3ea',highlightthickness=1); card.pack(fill='x',pady=3); card.pack_propagate(False); full=(str(x.get('first_name',''))+' '+str(x.get('last_name',''))).strip() or 'بدون نام'
                def toggle(rid=rid,v=v):
                    if v.get(): selected.add(rid)
                    else: selected.discard(rid)
                    current['selected_rows']=selected; upd()
                tk.Checkbutton(card,variable=v,command=toggle,bg='white',activebackground='white').pack(side='right',padx=(10,3)); tk.Label(card,text=f'{i}. {full}',bg='white',fg='#0f3d63',font=('Tahoma',9,'bold')).pack(side='right',padx=6); tk.Label(card,text=f"موبایل: {x.get('mobile') or '—'} | Chat ID: {x.get('target') or '—'}",bg='white',fg='#64748b',font=('Tahoma',8)).pack(side='right',padx=10); tk.Button(card,text='👁 پیش‌نمایش پیام',command=lambda x=x:message_preview(x),bg='#eff6ff',fg='#0f3d63',relief='flat',font=('Tahoma',8)).pack(side='left',padx=8)
            def allset(val):
                for rid,v in vars.items(): v.set(1 if val else 0)
                if val: selected.update(vars.keys())
                else: selected.clear()
                current['selected_rows']=selected; upd()
            foot=tk.Frame(w,bg='white'); foot.pack(fill='x',padx=12,pady=7); self.button(foot,'☑ انتخاب همه',lambda:allset(True)).pack(side='right',padx=3); self.button(foot,'☐ لغو انتخاب همه',lambda:allset(False)).pack(side='right',padx=3); self.button(foot,'🚀 ارسال افراد تیک‌خورده',lambda:(w.destroy(),send_campaign()),True).pack(side='left',padx=3); self.button(foot,'بستن',w.destroy).pack(side='left',padx=3); upd()
        def update_page(): refresh_audience()
        def send_campaign():
            refresh_audience(); r=[x for x in current['results'] if str(x['row']) in current['selected_rows']]
            if not r: messagebox.showwarning('ارسال','هیچ مخاطبی برای ارسال انتخاب نشده است. ابتدا افراد موردنظر را تیک بزنید.',parent=self); return
            template=msg.get('1.0','end').strip(); kind=kind_var.get().upper(); gid=current['group_id']; total=current['total']; invalid=current['invalid']; name,_,_,_,_=self._internal_channel_meta(kind)
            if not template: messagebox.showwarning('متن پیام','متن پیام را وارد کنید.',parent=self); return
            if not messagebox.askyesno('تأیید ارسال',f'{len(r):,} پیام واقعی از طریق {name} ارسال می‌شود.\n\nفقط افراد انتخاب‌شده دریافت می‌کنند.\n\nادامه؟',parent=self): return
            def worker(progress):
                meta=self._internal_channel_meta(kind); token=self.db.get(meta[1],'').strip()
                if not token: raise RuntimeError(f'Token / API Key {name} تنظیم نشده است.')
                cur=self.db.q("INSERT INTO campaigns(name,channel,group_id,message,scheduled_at,status,source_type,source_id,audience_count,valid_count,invalid_count) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(f'کمپین {name} — {datetime.now().strftime("%Y-%m-%d %H:%M")}',kind,gid,template,'','Sending','local_group',gid,total,len(r),len(invalid))); cid=cur.lastrowid
                payload=[(cid,str(x['row']),x.get('mobile',''),x.get('email',''),x.get('first_name',''),x.get('last_name',''),x['target'],'Ready','',x.get('source_json','{}')) for x in r]; self.db.q("INSERT INTO campaign_targets(campaign_id,source_row_key,mobile,email,first_name,last_name,target,status,error,source_json) VALUES(?,?,?,?,?,?,?,?,?,?)",payload,many=True)
                okc=failc=0
                for i,x in enumerate(r,1):
                    text=render_text(template,x);
                    if kind=='RUBIKA' and self.db.get('rubika_user_session','').strip(): ok,detail=self._send_rubika_user_message(x['target'],text)
                    else: ok,detail=self._send_internal_message(kind,x['target'],text); st='Sent' if ok else 'Failed'; self.db.q('UPDATE campaign_targets SET status=?,error=? WHERE campaign_id=? AND source_row_key=?',(st,'' if ok else detail,cid,str(x['row']))); self.db.q('INSERT INTO send_log(campaign_id,contact_id,channel,target,message,status,error) VALUES(?,?,?,?,?,?,?)',(cid,x['row'],kind,x['target'],text,st,'' if ok else detail)); okc+=int(ok); failc+=int(not ok); progress(i*100/max(1,len(r)),f'ارسال {i:,} از {len(r):,} | موفق: {okc:,} | ناموفق: {failc:,}')
                self.db.q('UPDATE campaigns SET status=? WHERE id=?',('Sent' if not failc else ('Partial' if okc else 'Failed'),cid)); return cid,okc,failc
            def done(res,err):
                if err: messagebox.showerror('ارسال کمپین',str(err),parent=self); return
                cid,okc,failc=res; messagebox.showinfo('نتیجه ارسال',f'کمپین #{cid} تمام شد.\n\n✓ موفق: {okc:,}\n✗ ناموفق: {failc:,}',parent=self); refresh_audience()
            self.run_with_progress('ارسال کمپین','در حال ارسال پیام‌ها...',100,worker,done)
        def send_fixed_current():
            kind=kind_var.get().upper(); name,_,_,chat_key,_=self._internal_channel_meta(kind); target=self.db.get(chat_key,'').strip(); text=msg.get('1.0','end').strip()
            if not target: messagebox.showwarning('مقصد فعلی',f'Chat ID مقصد فعلی {name} خالی است. این گزینه برای تست یک مقصد مشخص است؛ برای کمپین از «انتخاب نفرات» استفاده کنید.',parent=self); return
            if not text: messagebox.showwarning('متن پیام','متن پیام خالی است.',parent=self); return
            if not messagebox.askyesno('ارسال آزمایشی',f'این پیام فقط به «مقصد فعلی» ذخیره‌شده ارسال می‌شود، نه به اعضای گروه.\n\nChat ID: {target}\n\nادامه؟',parent=self): return
            def worker(progress): progress(30,'در حال اتصال...'); ok,detail=self._send_internal_message(kind,target,text); progress(100,'تمام شد.'); return ok,detail
            def done(res,err):
                if err: messagebox.showerror('ارسال',str(err),parent=self); return
                ok,detail=res; (messagebox.showinfo if ok else messagebox.showerror)('نتیجه ارسال',detail,parent=self)
            self.run_with_progress('ارسال آزمایشی','در حال ارسال به مقصد فعلی...',100,worker,done)
        group_cb.bind('<<ComboboxSelected>>',update_page); kind_cb.bind('<<ComboboxSelected>>',update_page)
        self.button(actions,'👤 اتصال حساب روبیکا',lambda: self._rubika_user_session_settings()).pack(side='right',padx=3)
        self.button(actions,'👥 دریافت اعضای واقعی روبیکا',lambda: self._rubika_user_sync_group_members(current['group_id']) if kind_var.get().upper()=='RUBIKA' and current.get('group_id') else messagebox.showwarning('گروه','ابتدا گروه CRM را انتخاب کنید.',parent=self)).pack(side='right',padx=3)
        self.button(actions,'🔗 اتصال یک‌باره مخاطبان',lambda: self._rubika_link_manager(current['group_id']) if kind_var.get().upper()=='RUBIKA' and current.get('group_id') else messagebox.showwarning('گروه','ابتدا گروه را انتخاب کنید.',parent=self)).pack(side='right',padx=3)
        self.button(actions,'👥 انتخاب نفرات',open_selector).pack(side='right',padx=3)
        self.button(actions,'🚀 ارسال کمپین',send_campaign,True).pack(side='right',padx=3)
        self.button(actions,'🧪 ارسال تست به مقصد فعلی',send_fixed_current).pack(side='right',padx=3)
        self.button(actions,'پاک کردن متن',lambda:msg.delete('1.0','end')).pack(side='left',padx=3)

    def show_sms(self): self.campaign_page("SMS")
    def show_email(self): self.campaign_page("EMAIL")

    def _normalize_campaign_mobile(self, raw):
        digits=re.sub(r'\D','',str(raw or ''))
        if digits.startswith('0098'): digits='98'+digits[4:]
        if digits.startswith('98') and len(digits)==12: return '0'+digits[2:]
        if len(digits)==10 and digits.startswith('9'): return '0'+digits
        if len(digits)==11 and digits.startswith('09'): return digits
        return digits

    def _safe_select_query(self, query):
        clean=(query or '').strip().rstrip(';').strip()
        low=clean.lower()
        if ';' in clean or not (low.startswith('select ') or low.startswith('select\n') or low.startswith('with ')):
            raise RuntimeError('برای دریافت مخاطبان فقط Query خواندنی (SELECT/CTE) مجاز است.')
        blocked=['insert ','update ','delete ','drop ','alter ','truncate ','merge ','exec ','execute ','create ','grant ','revoke ']
        if any(x in low for x in blocked): raise RuntimeError('Query شامل دستور تغییر‌دهنده یا مدیریتی است و اجرا نشد.')
        return clean

    def _column_value(self, row, preferred, fallbacks=()):
        keys=list(row.keys()) if hasattr(row,'keys') else []
        for name in [preferred]+list(fallbacks):
            if not name: continue
            for k in keys:
                if str(k).strip().lower()==str(name).strip().lower():
                    try: return row[k]
                    except Exception: pass
        return ''

    def _build_company_audience(self, source, channel, progress=None):
        query=self._safe_select_query(source.get('query_text',''))
        conn,kind=self._data_source_connect(source)
        try:
            cur=conn.cursor(); cur.execute(query)
            cols=[x[0] for x in cur.description] if cur.description else []
            rows=cur.fetchmany(50000)
            if len(rows)>=50000: raise RuntimeError('تعداد رکوردها بیش از سقف ۵۰٬۰۰۰ رکورد این مرحله است. Query را محدودتر کنید.')
            results=[]; invalid=[]; seen=set(); total=len(rows)
            for i,row in enumerate(rows,1):
                first=str(self._column_value(row,source.get('first_name_column'),('first_name','firstname','name','نام')) or '')
                last=str(self._column_value(row,source.get('last_name_column'),('last_name','lastname','نام خانوادگی')) or '')
                mobile=self._normalize_campaign_mobile(self._column_value(row,source.get('mobile_column'),('mobile','mobile_number','phone','cellphone','موبایل')))
                email=str(self._column_value(row,source.get('email_column'),('email','email_address','ایمیل')) or '').strip()
                target=mobile if channel.upper()=='SMS' else email
                if not target:
                    invalid.append({'row':i,'reason':'مقصد خالی','first_name':first,'last_name':last}); continue
                key=target.lower() if channel.upper()=='EMAIL' else target
                if key in seen: continue
                seen.add(key)
                results.append({'row':i,'mobile':mobile,'email':email,'first_name':first,'last_name':last,'target':target,'source_json':json.dumps({str(c):str(row[j]) for j,c in enumerate(cols)},ensure_ascii=False,default=str)})
                if progress and (i==1 or i%100==0 or i==total): progress(20+(i*70/max(1,total)),f'در حال آماده‌سازی مخاطبان... {i:,} از {total:,}')
            return results,invalid,total
        finally: conn.close()

    def _build_local_audience(self, group_id, channel):
        social_fields={'RUBIKA':'rubika_chat_id','EITAA':'eitaa_chat_id','BALE':'bale_chat_id'}
        target_field=social_fields.get(str(channel).upper())
        rows=self.db.c.execute("SELECT c.id,c.first_name,c.last_name,c.mobile,c.email,c.rubika_chat_id,c.eitaa_chat_id,c.bale_chat_id FROM contacts c JOIN contact_groups cg ON cg.contact_id=c.id WHERE cg.group_id=? ORDER BY c.id",(group_id,)).fetchall()
        results=[]; invalid=[]; seen=set()
        for i,r in enumerate(rows,1):
            mobile=self._normalize_campaign_mobile(r['mobile']); email=(r['email'] or '').strip()
            target=str(r[target_field] or '').strip() if target_field else (mobile if channel.upper()=='SMS' else email)
            if not target:
                reason={'RUBIKA':'Chat ID روبیکا ثبت نشده','EITAA':'Chat ID ایتا ثبت نشده','BALE':'Chat ID بله ثبت نشده'}.get(channel.upper(),'مقصد خالی')
                invalid.append({'row':r['id'],'reason':reason,'first_name':r['first_name'] or '','last_name':r['last_name'] or '','mobile':mobile,'email':email,'target':'','source_json':json.dumps({'contact_id':r['id'],'channel':channel},ensure_ascii=False)}); continue
            key=target.lower() if channel.upper() in ('EMAIL','RUBIKA','EITAA','BALE') else target
            if key in seen: continue
            seen.add(key)
            results.append({'row':r['id'],'mobile':mobile,'email':email,'first_name':r['first_name'] or '','last_name':r['last_name'] or '','target':target,'source_json':json.dumps({'contact_id':r['id'],'channel':channel},ensure_ascii=False)})
        return results,invalid,len(rows)

    def _audience_preview(self, source_type, source_id, group_id, channel, callback):
        def worker(progress):
            if source_type=='company':
                source=self.db.c.execute('SELECT * FROM data_sources WHERE id=?',(source_id,)).fetchone()
                if not source: raise RuntimeError('منبع داده شرکت پیدا نشد.')
                results,invalid,total=self._build_company_audience(dict(source),channel,progress)
            else:
                progress(40,'در حال خواندن گروه مخاطبین...'); results,invalid,total=self._build_local_audience(group_id,channel); progress(100,'آماده‌سازی مخاطبان تمام شد.')
            return results,invalid,total
        def done(res,err): callback(res,err)
        self.run_with_progress('آماده‌سازی مخاطبان','در حال خواندن و بررسی مخاطبان...',100,worker,done)

    def _show_audience_preview(self, source_type, source_id, group_id, channel):
        def callback(res,err):
            if err: messagebox.showerror('خطا در مخاطبان',str(err),parent=self); return
            results,invalid,total=res
            win=tk.Toplevel(self); win.title('پیش‌نمایش مخاطبان کمپین'); win.geometry('1050x620'); win.configure(bg='white')
            tk.Label(win,text=f'مخاطبان آماده: {len(results):,}   |   ناقص/بدون مقصد: {len(invalid):,}   |   کل: {total:,}',bg='white',fg=self.colors['primary_dark'],font=('Tahoma',11,'bold')).pack(anchor='e',padx=20,pady=15)
            frame=tk.Frame(win,bg='white'); frame.pack(fill='both',expand=True,padx=15,pady=5)
            cols=('name','mobile','email','target','status'); tree=ttk.Treeview(frame,columns=cols,show='headings')
            for c,t,w in [('name','نام',220),('mobile','موبایل',160),('email','ایمیل',260),('target','مقصد ارسال',230),('status','وضعیت',130)]: tree.heading(c,text=t); tree.column(c,width=w,anchor='center')
            tree.tag_configure('ok',foreground='#15803d'); tree.tag_configure('bad',foreground='#dc2626')
            ys=ttk.Scrollbar(frame,orient='vertical',command=tree.yview); tree.configure(yscrollcommand=ys.set); tree.pack(side='left',fill='both',expand=True); ys.pack(side='right',fill='y')
            for x in results[:1000]: tree.insert('', 'end',values=(f"{x['first_name']} {x['last_name']}".strip(),x['mobile'],x['email'],x['target'],'آماده'),tags=('ok',))
            for x in invalid[:100]: tree.insert('', 'end',values=(f"{x.get('first_name','')} {x.get('last_name','')}".strip(),'','',x.get('reason',''),'ناقص'),tags=('bad',))
            tk.Label(win,text='نمایش حداکثر ۱۰۰۰ مخاطب معتبر و ۱۰۰ رکورد ناقص. هنگام ذخیره کمپین، همه رکوردهای معتبر ثبت می‌شوند.',bg='white',fg='#475569',font=('Tahoma',9)).pack(anchor='e',padx=20,pady=10)
        self._audience_preview(source_type,source_id,group_id,channel,callback)

    def campaign_page(self,channel,preselect_group_id=None,prefill_message=""):
        self.clear(); self.header('کمپین '+channel,'ساخت کمپین، انتخاب منبع مخاطبان و آماده‌سازی صف ارسال')
        f=tk.Frame(self.main,bg='white'); f.pack(fill='both',expand=True,padx=28,pady=8)
        d={}
        for lab,key in [('نام کمپین','name'),('زمان ارسال (اختیاری)','scheduled')]:
            tk.Label(f,text=lab,bg='white',font=('Tahoma',9)).pack(anchor='e',padx=30,pady=(15,3)); e=tk.Entry(f,justify='right'); e.pack(fill='x',padx=30); d[key]=e
        tk.Label(f,text='منبع مخاطبان',bg='white',font=('Tahoma',9)).pack(anchor='e',padx=30,pady=(15,3))
        dbrows=self.db.c.execute("SELECT id,name,status FROM data_sources WHERE enabled=1 ORDER BY name").fetchall()
        source_labels=['گروه‌های داخلی']+[f"🗄 بانک شرکت: {r['name']} — {r['status']}" for r in dbrows]
        source_var=tk.StringVar(value=source_labels[0]); source_cb=ttk.Combobox(f,textvariable=source_var,values=source_labels,state='readonly',justify='right'); source_cb.pack(fill='x',padx=30)
        group_label=tk.Label(f,text='گروه مخاطبین داخلی',bg='white',font=('Tahoma',9)); group_label.pack(anchor='e',padx=30,pady=(12,3))
        groups=self.db.c.execute('SELECT id,name FROM groups ORDER BY name').fetchall(); group_var=tk.StringVar(); group_cb=ttk.Combobox(f,textvariable=group_var,values=[x['name'] for x in groups],state='readonly',justify='right'); group_cb.pack(fill='x',padx=30)
        if preselect_group_id is not None:
            pre=next((x['name'] for x in groups if x['id']==preselect_group_id),''); group_var.set(pre) if pre else None
        info=tk.StringVar(value='برای بانک شرکت، Query و ستون‌های مقصد را از بخش «پایگاه داده شرکت» تنظیم کنید.')
        tk.Label(f,textvariable=info,bg='white',fg='#64748b',font=('Tahoma',8),wraplength=900,justify='right').pack(anchor='e',padx=30,pady=8)
        tk.Label(f,text='متن پیام',bg='white',font=('Tahoma',9)).pack(anchor='e',padx=30,pady=(10,3)); msg=tk.Text(f,height=8,font=('Tahoma',10)); msg.pack(fill='both',expand=True,padx=30)
        if prefill_message: msg.insert('1.0',prefill_message)
        def current_source():
            label=source_var.get()
            if label=='گروه‌های داخلی':
                gn=group_var.get(); gid=next((x['id'] for x in groups if x['name']==gn),None)
                if not gid: raise RuntimeError('ابتدا یک گروه داخلی انتخاب کنید.')
                return 'local',None,gid
            idx=source_labels.index(label)-1
            if idx<0 or idx>=len(dbrows): raise RuntimeError('منبع داده انتخاب‌شده معتبر نیست.')
            return 'company',dbrows[idx]['id'],None
        def update_source(*_):
            is_local=source_var.get()=='گروه‌های داخلی'; group_cb.config(state='readonly' if is_local else 'disabled'); group_label.config(fg='#111827' if is_local else '#94a3b8')
            info.set('اطلاعات از Query منبع شرکت خوانده می‌شود. فقط SELECT/CTE خواندنی مجاز است.' if not is_local else 'برای ارسال به مخاطبین داخلی، گروه موردنظر را انتخاب کنید.')
        source_cb.bind('<<ComboboxSelected>>',update_source); update_source()
        preview_btn=self.button(f,'👁 بررسی مخاطبان',None,False); preview_btn.pack(anchor='e',padx=30,pady=8)
        def preview():
            try: st,sid,gid=current_source()
            except Exception as e: messagebox.showwarning('انتخاب منبع',str(e),parent=self); return
            self._show_audience_preview(st,sid,gid,channel)
        preview_btn.config(command=preview)
        def save():
            try: source_type,source_id,group_id=current_source()
            except Exception as e: messagebox.showwarning('انتخاب منبع',str(e),parent=self); return
            name=d['name'].get().strip() or 'کمپین بدون نام'; text=msg.get('1.0','end').strip()
            if not text: messagebox.showwarning('متن پیام','متن پیام را وارد کنید.',parent=self); return
            def worker(progress):
                progress(5,'در حال آماده‌سازی مخاطبان کمپین...')
                if source_type=='company':
                    source=self.db.c.execute('SELECT * FROM data_sources WHERE id=?',(source_id,)).fetchone()
                    if not source: raise RuntimeError('منبع داده شرکت پیدا نشد.')
                    if source['status']!='آماده': raise RuntimeError('ابتدا اتصال این منبع داده را با موفقیت تست کنید.')
                    results,invalid,total=self._build_company_audience(dict(source),channel,progress)
                else:
                    results,invalid,total=self._build_local_audience(group_id,channel); progress(70,'مخاطبان گروه آماده شدند.')
                if not results: raise RuntimeError('هیچ مخاطب معتبری برای این کمپین پیدا نشد.')
                cur=self.db.q('''INSERT INTO campaigns(name,channel,group_id,message,scheduled_at,status,source_type,source_id,audience_count,valid_count,invalid_count) VALUES(?,?,?,?,?,?,?,?,?,?,?)''',(name,channel,group_id,text,d['scheduled'].get().strip(),'Audience Ready',source_type,source_id,total,len(results),len(invalid)))
                cid=cur.lastrowid; payload=[(cid,str(x['row']),x.get('mobile',''),x.get('email',''),x.get('first_name',''),x.get('last_name',''),x['target'],'Ready','',x.get('source_json','{}')) for x in results]
                self.db.q('''INSERT INTO campaign_targets(campaign_id,source_row_key,mobile,email,first_name,last_name,target,status,error,source_json) VALUES(?,?,?,?,?,?,?,?,?,?)''',payload,many=True)
                progress(100,f'{len(results):,} مخاطب معتبر آماده شد.'); return cid,total,len(results),len(invalid)
            def done(res,err):
                if err: messagebox.showerror('ساخت کمپین',str(err),parent=self); return
                cid,total,valid,invalid=res; messagebox.showinfo('کمپین آماده شد',f'کمپین با شماره {cid} ساخته شد.\n\nکل رکوردها: {total:,}\nمخاطب معتبر: {valid:,}\nناقص/بدون مقصد: {invalid:,}\n\nمخاطبان برای مرحله صف ارسال آماده هستند.',parent=self)
            self.run_with_progress('ساخت کمپین','در حال خواندن منبع و ساخت مخاطبان کمپین...',100,worker,done)
        self.button(f,'💾 ساخت و ذخیره کمپین',save,True).pack(anchor='e',padx=30,pady=12)
        note='ارسال واقعی SMS پس از اتصال کانال SMS/پنل/Android/Wavecom انجام می‌شود.' if channel=='SMS' else 'ارسال واقعی پس از اتصال SMTP انجام می‌شود.'
        tk.Label(f,text=note,bg='white',fg='#b45309',font=('Tahoma',9)).pack(anchor='e',padx=30,pady=(0,15))

    # lottery
    def show_lottery(self):
        self.clear();self.header("قرعه‌کشی","تعریف مسابقه، پاسخ صحیح، بازه زمانی و انتخاب تصادفی برندگان")
        self.button(self.main,"＋ قرعه‌کشی جدید",self.new_lottery,True).pack(anchor="e",padx=28)
        tr=ttk.Treeview(self.main,columns=("id","name","start","end","answer","winners","status"),show="headings")
        for c,t,w in [("id","ID",50),("name","نام",230),("start","شروع",150),("end","پایان",150),("answer","پاسخ صحیح",130),("winners","برنده",80),("status","وضعیت",100)]:
            tr.heading(c,text=t);tr.column(c,width=w,anchor="center")
        tr.pack(fill="both",expand=True,padx=28,pady=12)
        for r in self.db.c.execute("SELECT * FROM lotteries ORDER BY id DESC").fetchall():
            tr.insert("", "end",values=(r["id"],r["name"],r["start_at"],r["end_at"],r["correct_answer"],r["winner_count"],r["status"]))
    def new_lottery(self):
        w=tk.Toplevel(self);w.title("قرعه‌کشی جدید");w.geometry("500x600")
        d={}
        for lab,key in [("نام","name"),("سؤال","question"),("پاسخ صحیح","answer"),("شروع","start"),("پایان","end"),("تعداد برندگان","winners")]:
            tk.Label(w,text=lab,font=("Tahoma",9)).pack(anchor="e",padx=35,pady=(10,2))
            e=tk.Entry(w,justify="right");e.pack(fill="x",padx=35);d[key]=e
        d["winners"].insert(0,"1")
        def save():
            try:n=int(d["winners"].get())
            except:n=1
            self.db.q("""INSERT INTO lotteries(name,question,correct_answer,start_at,end_at,winner_count,status)
                         VALUES(?,?,?,?,?,?,?)""",(d["name"].get(),d["question"].get(),d["answer"].get(),d["start"].get(),d["end"].get(),n,"Draft"))
            w.destroy();self.show_lottery()
        self.button(w,"ذخیره",save,True).pack(pady=22)
    # import/export + guided import wizard
    def import_contacts(self):
        w=tk.Toplevel(self); w.title("ویزارد ورود اطلاعات مخاطبین — نسخه ۱۲"); w.geometry("1080x760"); w.minsize(960,680); w.configure(bg="#f4f7fb"); w.transient(self)
        state={"source":None,"headers":[],"rows":[],"mapping":{},"table":"","file_name":"هنوز فایلی انتخاب نشده است","count_text":"—","sheet":""}
        fields=[
            ("first_name","نام",True),("last_name","نام خانوادگی",True),
            ("mobile","موبایل",True),("phone","تلفن",False),
            ("birth_date","تاریخ تولد",False),("gender","جنسیت",False),
            ("email","ایمیل",False),("company","شرکت",False),("notes","یادداشت",False)
        ]
        aliases={
            "first_name":["نام","نام کوچک","firstname","first_name","name"],
            "last_name":["نام خانوادگی","نام‌خانوادگی","نام خانوادگي","lastname","last_name","family","surname"],
            "mobile":["موبایل","شماره موبایل","شماره همراه","شماره موبایل همراه","همراه","mobile","cell","cellphone","phone_number","شماره همراه اول"],
            "phone":["تلفن","شماره تلفن","phone","telephone","tel"],
            "birth_date":["تاریخ تولد","تولد","birth_date","birthdate","birthday","dob"],
            "gender":["جنسیت","gender","sex"],"email":["ایمیل","email","e-mail","mail"],
            "company":["شرکت","company","organization","org"],"notes":["یادداشت","توضیحات","notes","description","note"]}
        page=tk.Frame(w,bg="#f4f7fb");page.pack(fill="both",expand=True,padx=24,pady=18)
        file_label_var=tk.StringVar(value="هنوز فایلی انتخاب نشده است")
        count_label_var=tk.StringVar(value="—")
        status=tk.StringVar(value="مرحله ۱ از ۳ — انتخاب منبع اطلاعات")
        tk.Label(w,textvariable=status,bg="#17324d",fg="white",font=("Tahoma",10,"bold"),anchor="e",padx=18,pady=10).pack(fill="x",side="bottom")
        def clear_page():
            for x in page.winfo_children(): x.destroy()
        def title(t,sub=""):
            tk.Label(page,text=t,bg="#f4f7fb",fg="#17324d",font=("Tahoma",18,"bold")).pack(anchor="e",pady=(0,4))
            if sub: tk.Label(page,text=sub,bg="#f4f7fb",fg="#718096",font=("Tahoma",9)).pack(anchor="e",pady=(0,14))
        def normalize(v):
            if v is None:return ""
            try:
                if hasattr(v,"isoformat") and not isinstance(v,str): return v.isoformat(sep=" ")
            except Exception: pass
            return str(v).strip()
        def norm_header(v):
            return " ".join(normalize(v).replace("‌"," ").replace("ي","ی").replace("ك","ک").lower().split())
        def smart_match(key, headers):
            aa={norm_header(x) for x in aliases[key]}
            for h in headers:
                if norm_header(h) in aa:return h
            # softer matching for Persian/English headers
            for h in headers:
                nh=norm_header(h)
                if any(a and (a in nh or nh in a) for a in aa if len(a)>=3): return h
            return "— بدون انتخاب —"
        def load_source():
            p=filedialog.askopenfilename(parent=w,filetypes=[("Excel / CSV / SQLite","*.xlsx *.xls *.csv *.db *.sqlite *.sqlite3"),("Excel","*.xlsx *.xls"),("CSV","*.csv"),("SQLite Database","*.db *.sqlite *.sqlite3")])
            if not p:return
            try:
                low=p.lower(); headers=[]; rows=[]; selected_sheet=""
                if low.endswith('.csv'):
                    with open(p,'r',encoding='utf-8-sig',newline='') as f: rr=list(csv.reader(f))
                    if not rr: raise ValueError('فایل خالی است.')
                    headers=[normalize(x) for x in rr[0]]; rows=[list(r) for r in rr[1:]]
                elif low.endswith(('.xlsx','.xls')):
                    try: import openpyxl
                    except ImportError: raise RuntimeError('برای ورود مستقیم Excel باید openpyxl نصب باشد. در صورت نبود آن، فایل را با Excel به CSV UTF-8 ذخیره کنید.')
                    if low.endswith('.xls'): raise RuntimeError('فایل XLS قدیمی پشتیبانی نمی‌شود؛ آن را به XLSX یا CSV تبدیل کنید.')
                    wb=openpyxl.load_workbook(p,read_only=True,data_only=True)
                    sheets=list(wb.sheetnames)
                    if not sheets: wb.close(); raise ValueError('هیچ Sheetای در فایل Excel پیدا نشد.')
                    selected_sheet=sheets[0]
                    if len(sheets)>1:
                        dlg=tk.Toplevel(w); dlg.title('انتخاب Sheet'); dlg.geometry('450x190'); dlg.transient(w); dlg.grab_set(); dlg.configure(bg='#f4f7fb')
                        tk.Label(dlg,text='Sheet موردنظر را انتخاب کنید:',bg='#f4f7fb',fg='#17324d',font=('Tahoma',10,'bold')).pack(anchor='e',padx=20,pady=(20,8))
                        sv=tk.StringVar(value=sheets[0]); ttk.Combobox(dlg,textvariable=sv,values=sheets,state='readonly',justify='right',width=38).pack(padx=20,pady=4)
                        result={'ok':False}
                        self.button(dlg,'انتخاب',lambda:(result.update(ok=True),dlg.destroy()),True).pack(side='left',padx=20,pady=14)
                        self.button(dlg,'انصراف',dlg.destroy).pack(side='right',padx=20,pady=14)
                        w.wait_window(dlg)
                        if not result['ok']: wb.close(); return
                        selected_sheet=sv.get() or sheets[0]
                    ws=wb[selected_sheet]; rr=list(ws.iter_rows(values_only=True)); wb.close()
                    if not rr: raise ValueError('Sheet انتخاب‌شده خالی است.')
                    headers=[normalize(x) for x in rr[0]]; rows=[list(r) for r in rr[1:]]
                else:
                    conn=sqlite3.connect(p); conn.row_factory=sqlite3.Row
                    tables=[r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()]
                    if not tables: conn.close(); raise ValueError('هیچ جدول قابل استفاده‌ای در بانک اطلاعاتی پیدا نشد.')
                    dlg=tk.Toplevel(w); dlg.title('انتخاب جدول'); dlg.geometry('450x190'); dlg.transient(w); dlg.grab_set(); dlg.configure(bg='#f4f7fb')
                    tk.Label(dlg,text='جدول موردنظر را انتخاب کنید:',bg='#f4f7fb',fg='#17324d',font=('Tahoma',10,'bold')).pack(anchor='e',padx=20,pady=(20,8))
                    tv=tk.StringVar(value=tables[0]); ttk.Combobox(dlg,textvariable=tv,values=tables,state='readonly',justify='right',width=38).pack(padx=20,pady=4)
                    result={'ok':False}
                    self.button(dlg,'انتخاب',lambda:(result.update(ok=True),dlg.destroy()),True).pack(side='left',padx=20,pady=14)
                    self.button(dlg,'انصراف',dlg.destroy).pack(side='right',padx=20,pady=14)
                    w.wait_window(dlg)
                    if not result['ok']: conn.close(); return
                    selected_table=tv.get() or tables[0]; safe=selected_table.replace('"','""')
                    cur=conn.execute('SELECT * FROM "'+safe+'"'); rr=cur.fetchall(); headers=[d[0] for d in cur.description] if cur.description else []; rows=[list(r) for r in rr]; conn.close()
                headers=[h if h else f"ستون {i+1}" for i,h in enumerate(headers)]
                if not headers: raise ValueError('ستون‌های منبع پیدا نشد.')
                state.update(source=p,headers=headers,rows=rows,mapping={},table=(selected_table if low.endswith(('.db','.sqlite','.sqlite3')) else ''),file_name=Path(p).name,count_text=f"{len(rows):,} رکورد | {len(headers)} ستون",sheet=selected_sheet)
                file_label_var.set(state['file_name']); count_label_var.set(state['count_text'] + (f" | Sheet: {selected_sheet}" if selected_sheet else ""))
                # Rebuild page so Next button is definitely enabled after a successful load.
                source_page()
            except Exception as ex:
                messagebox.showerror('خطا در خواندن منبع',str(ex),parent=w)
        def mapping_page():
            clear_page(); status.set('مرحله ۲ از ۳ — تطبیق ستون‌ها با اطلاعات مخاطب'); title('تطبیق ستون‌ها','سه فیلد نام، نام خانوادگی و موبایل الزامی هستند. سایر فیلدها اختیاری‌اند.')
            if not state['headers']:
                messagebox.showerror('منبع نامعتبر','ابتدا یک فایل یا بانک اطلاعاتی انتخاب کنید.',parent=w); source_page(); return
            wrap=tk.Frame(page,bg='white',bd=1,relief='solid');wrap.pack(fill='both',expand=True)
            # IMPORTANT: do not mix pack and grid in the same parent.
            # The old v12 used grid directly inside `wrap` after packing `top`,
            # which caused Tkinter to abort the callback and leave a blank page.
            top=tk.Frame(wrap,bg='#eef4fa');top.pack(fill='x')
            for j,t in enumerate(['فیلد سامانه','ستون منبع','وضعیت']):
                tk.Label(top,text=t,bg='#eef4fa',fg='#17324d',font=('Tahoma',9,'bold'),width=[25,45,12][j],anchor='e').grid(row=0,column=j,padx=8,pady=9)
            body=tk.Frame(wrap,bg='white');body.pack(fill='both',expand=True)
            body.grid_columnconfigure(1,weight=1)
            mapping={}
            for i,(key,label,required) in enumerate(fields):
                tk.Label(body,text=label + (' *' if required else ''),bg='white',fg='#334155',font=('Tahoma',9),width=25,anchor='e').grid(row=i,column=0,padx=8,pady=7,sticky='e')
                sv=tk.StringVar(value=smart_match(key,state['headers']))
                cb=ttk.Combobox(body,textvariable=sv,values=['— بدون انتخاب —']+state['headers'],state='readonly',width=42,justify='right')
                cb.grid(row=i,column=1,padx=8,pady=7,sticky='ew')
                tk.Label(body,text='اجباری' if required else 'اختیاری',bg='white',fg='#b42318' if required else '#64748b',font=('Tahoma',9,'bold'),width=12).grid(row=i,column=2,padx=8,pady=7,sticky='e')
                mapping[key]=sv
            state['mapping']=mapping
            def go_preview():
                missing=[label for key,label,req in fields if req and mapping[key].get()=='— بدون انتخاب —']
                if missing:
                    messagebox.showerror('تکمیل Mapping','این فیلدهای اجباری باید انتخاب شوند:\n\n'+'، '.join(missing),parent=w); return
                preview_page()
            b=tk.Frame(page,bg='#f4f7fb');b.pack(fill='x',pady=(10,0));self.button(b,'← انتخاب منبع',source_page).pack(side='right');self.button(b,'پیش‌نمایش →',go_preview,True).pack(side='left')
        def normalize_mobile(raw):
            import re
            digits=re.sub(r'\D','',normalize(raw))
            if digits.startswith('0098'): digits='98'+digits[4:]
            if digits.startswith('98') and len(digits)==12: return '0'+digits[2:]
            if len(digits)==10 and digits.startswith('9'): return '0'+digits
            if len(digits)==11 and digits.startswith('09'): return digits
            return digits
        def row_values(row,idx):
            def val(k):
                i=idx.get(k); return normalize(row[i]) if i is not None and i<len(row) else ''
            return {k:val(k) for k,_,_ in fields}
        def normalize_birth(birth):
            if not birth:return ''
            import re
            m=re.match(r'^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$',birth.strip())
            if m:
                yy,mm,dd=map(int,m.groups())
                if 1200<=yy<=1600: return jalali_to_iso(f'{yy:04d}-{mm:02d}-{dd:02d}')
                return f'{yy:04d}-{mm:02d}-{dd:02d}'
            from datetime import datetime as _dt
            for fmt in ('%Y-%m-%d %H:%M:%S','%Y-%m-%d %H:%M','%m/%d/%Y','%d/%m/%Y'):
                try:return _dt.strptime(birth.strip(),fmt).strftime('%Y-%m-%d')
                except Exception:pass
            return birth
        def preview_page():
            clear_page(); status.set('مرحله ۳ از ۳ — پیش‌نمایش و ورود اطلاعات'); title('پیش‌نمایش و اعتبارسنجی','ردیف‌های ناقص قبل از ورود مشخص می‌شوند. نام، نام خانوادگی و موبایل باید مقدار معتبر داشته باشند.')
            selected={k:v.get() for k,v in state['mapping'].items()}; idx={k:(state['headers'].index(v) if v in state['headers'] else None) for k,v in selected.items()}
            if any(idx[k] is None for k,_,req in fields if req): messagebox.showerror('Mapping ناقص','فیلدهای اجباری را انتخاب کنید.',parent=w); mapping_page(); return
            stats={'valid':0,'bad':0}; sample=[]
            for row in state['rows']:
                d=row_values(row,idx); d['mobile']=normalize_mobile(d['mobile'])
                valid=bool(d['first_name'] and d['last_name'] and d['mobile'])
                if valid:stats['valid']+=1
                else:stats['bad']+=1
                if len(sample)<30: sample.append((d,valid))
            frame=tk.Frame(page,bg='white');frame.pack(fill='both',expand=True)
            cols=[(k,l) for k,l,_ in fields]
            tr=ttk.Treeview(frame,columns=[x[0] for x in cols],show='headings')
            for k,l in cols: tr.heading(k,text=l); tr.column(k,width=max(105,980//len(cols)),anchor='center')
            for d,valid in sample:
                tr.insert('', 'end', values=[d[k] for k,_ in cols],tags=('bad' if not valid else 'ok',))
            tr.tag_configure('bad',background='#fff1f2'); tr.tag_configure('ok',background='white'); tr.pack(fill='both',expand=True,padx=10,pady=10)
            info=tk.Frame(frame,bg='white');info.pack(fill='x',padx=12,pady=(0,8))
            tk.Label(info,text=f"کل: {len(state['rows']):,}   |   معتبر: {stats['valid']:,}   |   ناقص/نامعتبر: {stats['bad']:,}   |   نمونه نمایش‌داده‌شده: {len(sample)}",bg='white',fg='#526273',font=('Tahoma',9,'bold')).pack(anchor='e')
            prog=tk.Frame(frame,bg='white');prog.pack(fill='x',padx=12,pady=(0,10))
            progress=ttk.Progressbar(prog,mode='determinate',maximum=max(1,len(state['rows'])),value=0);progress.pack(fill='x',side='left',expand=True,padx=(0,10))
            progress_text=tk.StringVar(value='آماده ورود اطلاعات')
            tk.Label(prog,textvariable=progress_text,bg='white',fg='#526273',font=('Tahoma',9)).pack(side='right')
            def do_import():
                if not state['rows']: messagebox.showwarning('فایل خالی','هیچ رکوردی برای ورود وجود ندارد.',parent=w); return
                if not messagebox.askyesno('تأیید ورود',f"تعداد {len(state['rows']):,} رکورد بررسی و وارد می‌شود. ادامه می‌دهید؟",parent=w): return
                # Freeze controls while the worker runs.
                for child in frame.winfo_children():
                    if isinstance(child,tk.Button): child.config(state='disabled')
                threading.Thread(target=worker,daemon=True).start()
            def worker():
                ok=dup=bad=0; total=len(state['rows']); idx_local=idx; imported_ids=[]
                for n,row in enumerate(state['rows'],1):
                    d=row_values(row,idx_local); mobile=normalize_mobile(d['mobile'])
                    if not d['first_name'] or not d['last_name'] or not mobile:
                        bad+=1
                    else:
                        try:
                            cur=self.db.q("INSERT INTO contacts(first_name,last_name,mobile,phone,birth_date,gender,email,company,notes) VALUES(?,?,?,?,?,?,?,?,?)",(d['first_name'],d['last_name'],mobile,d['phone'],normalize_birth(d['birth_date']),d['gender'],d['email'],d['company'],d['notes']))
                            imported_ids.append(cur.lastrowid)
                            ok+=1
                        except sqlite3.IntegrityError: dup+=1
                        except Exception: bad+=1
                    if n==1 or n%10==0 or n==total:
                        w.after(0,lambda n=n,ok=ok,dup=dup,bad=bad,total=total: (progress.configure(value=n),progress_text.set(f"در حال واردسازی... {n:,} از {total:,} | موفق {ok:,} | تکراری {dup:,} | خطا {bad:,}")))
                w.after(0,finish_import,ok,dup,bad,total,imported_ids)
            def finish_import(ok,dup,bad,total,imported_ids):
                progress.configure(value=total); progress_text.set(f"تکمیل شد: {total:,} از {total:,}")
                self.refresh_contacts()
                if imported_ids:
                    open_group_assignment(imported_ids, ok, dup, bad, total)
                else:
                    messagebox.showinfo('ورود اطلاعات تمام شد',f'کل رکوردها: {total:,}\nثبت جدید: {ok:,}\nتکراری: {dup:,}\nناقص/نامعتبر: {bad:,}',parent=w)
                    w.destroy()
            def open_group_assignment(imported_ids, ok, dup, bad, total):
                dlg=tk.Toplevel(w); dlg.title('گروه‌بندی مخاطبین واردشده'); dlg.geometry('900x680'); dlg.minsize(760,560); dlg.configure(bg='#f4f7fb'); dlg.transient(w); dlg.grab_set()
                tk.Label(dlg,text='گروه‌بندی مخاطبین واردشده',bg='#f4f7fb',fg='#17324d',font=('Tahoma',18,'bold')).pack(anchor='e',padx=24,pady=(18,4))
                tk.Label(dlg,text=f'{len(imported_ids):,} مخاطب جدید با موفقیت وارد شد. می‌توانید همین حالا آن‌ها را در یک گروه قرار دهید.',bg='#f4f7fb',fg='#64748b',font=('Tahoma',9),wraplength=820,justify='right').pack(anchor='e',padx=24,pady=(0,12))

                top=tk.Frame(dlg,bg='white',bd=1,relief='solid'); top.pack(fill='x',padx=20,pady=(0,10))
                tk.Label(top,text='گروه مقصد:',bg='white',fg='#334155',font=('Tahoma',9,'bold')).pack(side='right',padx=(8,18),pady=12)
                group_rows=self.db.c.execute('SELECT id,name FROM groups ORDER BY name').fetchall()
                group_var=tk.StringVar(value='— بدون گروه —')
                group_names=['— بدون گروه —']+[r['name'] for r in group_rows]
                group_cb=ttk.Combobox(top,textvariable=group_var,values=group_names,state='readonly',justify='right',width=34)
                group_cb.pack(side='right',padx=8,pady=8)
                def create_group_here():
                    name=simpledialog.askstring('گروه جدید','نام گروه جدید را وارد کنید:',parent=dlg)
                    if not name or not name.strip(): return
                    name=name.strip()
                    try:
                        self.db.q('INSERT INTO groups(name,description) VALUES(?,?)',(name,''))
                        group_rows2=self.db.c.execute('SELECT id,name FROM groups ORDER BY name').fetchall()
                        names2=['— بدون گروه —']+[r['name'] for r in group_rows2]
                        group_cb['values']=names2; group_var.set(name)
                    except sqlite3.IntegrityError:
                        messagebox.showwarning('گروه تکراری','این نام گروه قبلاً وجود دارد.',parent=dlg)
                self.button(top,'＋ ساخت گروه جدید',create_group_here,True).pack(side='right',padx=8,pady=7)

                tools=tk.Frame(dlg,bg='#f4f7fb'); tools.pack(fill='x',padx=20,pady=(0,8))
                search_var=tk.StringVar(); only_ungrouped=tk.BooleanVar(value=False); selected_count=tk.StringVar(value='انتخاب‌شده: 0')
                tk.Label(tools,text='جستجو:',bg='#f4f7fb',fg='#526273',font=('Tahoma',9)).pack(side='right',padx=(6,2))
                search=tk.Entry(tools,textvariable=search_var,justify='right',font=('Tahoma',9),width=28); search.pack(side='right',padx=5)
                tk.Checkbutton(tools,text='فقط مخاطبین فاقد گروه',variable=only_ungrouped,bg='#f4f7fb',activebackground='#f4f7fb',font=('Tahoma',9),command=lambda:refresh_list()).pack(side='right',padx=12)
                tk.Label(tools,textvariable=selected_count,bg='#f4f7fb',fg='#1769aa',font=('Tahoma',9,'bold')).pack(side='left',padx=8)

                list_card=tk.Frame(dlg,bg='white',bd=1,relief='solid'); list_card.pack(fill='both',expand=True,padx=20,pady=(0,10))
                header=tk.Frame(list_card,bg='#eef4fa'); header.pack(fill='x')
                tk.Label(header,text='انتخاب',bg='#eef4fa',fg='#17324d',font=('Tahoma',9,'bold'),width=10).pack(side='right',padx=5,pady=8)
                tk.Label(header,text='نام و نام خانوادگی',bg='#eef4fa',fg='#17324d',font=('Tahoma',9,'bold'),width=30,anchor='e').pack(side='right',padx=5,pady=8)
                tk.Label(header,text='موبایل',bg='#eef4fa',fg='#17324d',font=('Tahoma',9,'bold'),width=18,anchor='e').pack(side='right',padx=5,pady=8)
                tk.Label(header,text='گروه فعلی',bg='#eef4fa',fg='#17324d',font=('Tahoma',9,'bold'),width=25,anchor='e').pack(side='right',padx=5,pady=8)
                canvas=tk.Canvas(list_card,bg='white',highlightthickness=0)
                scrollbar=ttk.Scrollbar(list_card,orient='vertical',command=canvas.yview)
                inner=tk.Frame(canvas,bg='white')
                win_id=canvas.create_window((0,0),window=inner,anchor='nw')
                canvas.configure(yscrollcommand=scrollbar.set)
                canvas.pack(side='left',fill='both',expand=True); scrollbar.pack(side='right',fill='y')
                inner.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
                canvas.bind('<Configure>',lambda e:canvas.itemconfigure(win_id,width=e.width))

                contacts=self.db.c.execute('SELECT id,first_name,last_name,mobile FROM contacts WHERE id IN (%s) ORDER BY first_name,last_name,id' % ','.join('?'*len(imported_ids)),tuple(imported_ids)).fetchall()
                checks={}
                def get_group_names(cid):
                    rr=self.db.c.execute('SELECT g.name FROM groups g JOIN contact_groups cg ON g.id=cg.group_id WHERE cg.contact_id=? ORDER BY g.name',(cid,)).fetchall()
                    return '، '.join(r['name'] for r in rr) or 'بدون گروه'
                def refresh_count(): selected_count.set(f'انتخاب‌شده: {sum(1 for v in checks.values() if v.get())}')
                def toggle_all(value):
                    for v in checks.values(): v.set(value)
                    refresh_count()
                def refresh_list(*_):
                    for child in inner.winfo_children(): child.destroy()
                    q=search_var.get().strip().lower()
                    for r in contacts:
                        groups_text=get_group_names(r['id'])
                        if only_ungrouped.get() and groups_text!='بدون گروه': continue
                        full=f"{r['first_name']} {r['last_name']} {r['mobile']}".lower()
                        if q and q not in full: continue
                        if r['id'] not in checks: checks[r['id']]=tk.BooleanVar(value=True)
                        var=checks[r['id']]
                        row=tk.Frame(inner,bg='white'); row.pack(fill='x',pady=1)
                        cb=tk.Checkbutton(row,variable=var,bg='white',activebackground='white',command=refresh_count); cb.pack(side='right',padx=16,pady=5)
                        tk.Label(row,text=f"{r['first_name']} {r['last_name']}",bg='white',fg='#334155',font=('Tahoma',9),width=30,anchor='e').pack(side='right',padx=5,pady=5)
                        tk.Label(row,text=r['mobile'],bg='white',fg='#526273',font=('Segoe UI',9),width=18,anchor='e').pack(side='right',padx=5,pady=5)
                        tk.Label(row,text=groups_text,bg='white',fg='#64748b',font=('Tahoma',9),width=25,anchor='e').pack(side='right',padx=5,pady=5)
                    refresh_count(); canvas.yview_moveto(0)
                def select_all(): toggle_all(True)
                def deselect_all(): toggle_all(False)
                action=tk.Frame(dlg,bg='#f4f7fb'); action.pack(fill='x',padx=20,pady=(0,10))
                self.button(action,'☑ انتخاب همه',select_all).pack(side='right',padx=3)
                self.button(action,'☐ لغو انتخاب همه',deselect_all).pack(side='right',padx=3)
                search_var.trace_add('write',lambda *_:refresh_list())
                refresh_list()

                def assign_and_close():
                    selected_ids=[cid for cid,v in checks.items() if v.get()]
                    gn=group_var.get().strip()
                    if gn=='— بدون گروه —':
                        if messagebox.askyesno('بدون گروه‌بندی','گروه مقصد انتخاب نشده است. بدون گروه‌بندی ادامه می‌دهید؟',parent=dlg):
                            dlg.destroy(); w.destroy(); messagebox.showinfo('ورود اطلاعات تمام شد',f'کل رکوردها: {total:,}\nثبت جدید: {ok:,}\nتکراری: {dup:,}\nناقص/نامعتبر: {bad:,}\nگروه‌بندی: انجام نشد',parent=self)
                        return
                    if not selected_ids:
                        messagebox.showwarning('انتخاب مخاطب','حداقل یک مخاطب را انتخاب کنید.',parent=dlg); return
                    gr=self.db.c.execute('SELECT id FROM groups WHERE name=?',(gn,)).fetchone()
                    if not gr: return
                    dlg.destroy()
                    gid=gr['id']; count=len(selected_ids)
                    def worker(progress):
                        for i,cid in enumerate(selected_ids,1):
                            self.db.q('INSERT OR IGNORE INTO contact_groups(contact_id,group_id) VALUES(?,?)',(cid,gid))
                            progress(i*100/count, f'در حال تخصیص مخاطب {i:,} از {count:,} به گروه «{gn}»...')
                        return count
                    def done(result,error):
                        if error:
                            messagebox.showerror('خطا',f'گروه‌بندی انجام نشد:\n{error}',parent=self); return
                        w.destroy(); self.refresh_contacts(); self.refresh_groups()
                        messagebox.showinfo('ورود اطلاعات تمام شد',f'کل رکوردها: {total:,}\nثبت جدید: {ok:,}\nتکراری: {dup:,}\nناقص/نامعتبر: {bad:,}\nگروه «{gn}»: {result:,} مخاطب',parent=self)
                    self.run_with_progress('گروه‌بندی مخاطبین واردشده', 'در حال آماده‌سازی...', count, worker, done)
                self.button(dlg,'✓ ثبت گروه‌بندی و پایان',assign_and_close,True).pack(side='left',padx=20,pady=10)
                self.button(dlg,'بعداً گروه‌بندی می‌کنم',lambda:(dlg.destroy(),w.destroy()),False).pack(side='left',padx=5,pady=10)
                dlg.protocol('WM_DELETE_WINDOW',lambda:(dlg.destroy(),w.destroy()))
            b=tk.Frame(page,bg='#f4f7fb');b.pack(fill='x',pady=(10,0));self.button(b,'← تطبیق ستون‌ها',mapping_page).pack(side='right');self.button(b,'✓ شروع واردسازی',do_import,True).pack(side='left')
        def source_page():
            clear_page(); status.set('مرحله ۱ از ۳ — انتخاب منبع اطلاعات'); title('انتخاب فایل یا بانک اطلاعاتی','فایل Excel/CSV یا یک بانک SQLite را انتخاب کنید. پس از بارگذاری، دکمه «بعدی» فعال می‌شود.')
            card=tk.Frame(page,bg='white',bd=1,relief='solid');card.pack(fill='x',pady=15)
            tk.Label(card,text='منبع انتخاب‌شده',bg='white',fg='#526273',font=('Tahoma',9)).pack(anchor='e',padx=25,pady=(18,4))
            tk.Label(card,textvariable=file_label_var,bg='white',fg='#17324d',font=('Tahoma',11,'bold')).pack(anchor='e',padx=25,pady=4)
            tk.Label(card,textvariable=count_label_var,bg='white',fg='#718096',font=('Tahoma',9)).pack(anchor='e',padx=25,pady=(2,18))
            self.button(card,'📂 انتخاب فایل / بانک اطلاعاتی',load_source,True).pack(anchor='e',padx=25,pady=(5,22))
            tk.Label(page,text='فرمت‌های پشتیبانی‌شده: CSV، XLSX و SQLite (.db / .sqlite / .sqlite3). برای XLS قدیمی آن را به XLSX یا CSV تبدیل کنید.',bg='#f4f7fb',fg='#64748b',font=('Tahoma',9),wraplength=900,justify='right').pack(anchor='e',pady=8)
            b=tk.Frame(page,bg='#f4f7fb');b.pack(fill='x',side='bottom',pady=10)
            next_btn=self.button(b,'بعدی →',mapping_page,True); next_btn.config(state='normal' if state['headers'] else 'disabled'); next_btn.pack(side='left')
        source_page()

    def export_contacts(self):
        p=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV","*.csv")])
        if not p:return
        rows=self.db.c.execute("SELECT first_name,last_name,mobile,phone,birth_date,gender,email,company,notes FROM contacts").fetchall()
        total=len(rows)
        def worker(progress):
            with open(p,"w",encoding="utf-8-sig",newline="") as f:
                w=csv.writer(f);w.writerow(["نام","نام خانوادگی","موبایل","تلفن","تاریخ تولد","جنسیت","ایمیل","شرکت","یادداشت"])
                for i,r in enumerate(rows,1):
                    w.writerow(list(r))
                    if i==1 or i%25==0 or i==total: progress(i*100/max(1,total),f"در حال ساخت خروجی... {i:,} از {total:,}")
            return total
        def done(result,error):
            if error: messagebox.showerror("خطا",f"ساخت خروجی انجام نشد:\n{error}"); return
            messagebox.showinfo("خروجی",f"خروجی {result:,} مخاطب با موفقیت ساخته شد.")
        self.run_with_progress("خروجی مخاطبین", "در حال آماده‌سازی فایل CSV...", total, worker, done)
    # reports/settings
    def show_reports(self):
        self.clear();self.header("گزارش‌ها","گزارش ارسال‌ها و آمار سامانه")
        tr=ttk.Treeview(self.main,columns=("date","channel","target","status","error"),show="headings")
        for c,t,w in [("date","تاریخ",170),("channel","کانال",90),("target","مقصد",180),("status","وضعیت",120),("error","خطا",450)]:
            tr.heading(c,text=t);tr.column(c,width=w,anchor="center")
        tr.pack(fill="both",expand=True,padx=28,pady=15)
        for r in self.db.c.execute("SELECT sent_at,channel,target,status,error FROM send_log ORDER BY id DESC").fetchall():
            tr.insert("", "end",values=tuple(r))
    # ---------------- Automatic company DB refresh ----------------
    def _start_data_source_scheduler(self):
        self.after(15000, self._data_source_scheduler_tick)

    def _data_source_scheduler_tick(self):
        try:
            rows=self.db.c.execute("SELECT * FROM data_sources WHERE enabled=1 AND refresh_enabled=1").fetchall()
            now=datetime.now()
            for row in rows:
                d=dict(row)
                due=True
                try:
                    due = not d.get('next_refresh') or datetime.strptime(d['next_refresh'],'%Y-%m-%d %H:%M:%S') <= now
                except Exception:
                    due=True
                if due:
                    threading.Thread(target=self._background_refresh_source,args=(d,),daemon=True).start()
        except Exception:
            pass
        self.after(30000, self._data_source_scheduler_tick)

    def _background_refresh_source(self,d):
        try:
            self._data_source_test(d)
            now=datetime.now()
            mins=max(1,int(d.get('refresh_interval_minutes') or 1440))
            nxt=now+timedelta(minutes=mins)
            self.db.q("UPDATE data_sources SET status=?,last_checked=?,last_refresh=?,next_refresh=? WHERE id=?",
                      ('آماده',now.strftime('%Y-%m-%d %H:%M:%S'),now.strftime('%Y-%m-%d %H:%M:%S'),nxt.strftime('%Y-%m-%d %H:%M:%S'),d['id']))
        except Exception as e:
            now=datetime.now()
            mins=max(1,int(d.get('refresh_interval_minutes') or 1440))
            nxt=now+timedelta(minutes=mins)
            self.db.q("UPDATE data_sources SET status=?,last_checked=?,last_refresh=?,next_refresh=? WHERE id=?",
                      ('غیرفعال / خطا',now.strftime('%Y-%m-%d %H:%M:%S'),now.strftime('%Y-%m-%d %H:%M:%S'),nxt.strftime('%Y-%m-%d %H:%M:%S'),d['id']))

    def _schedule_values(self, d):
        enabled=bool(int(d.get('refresh_enabled') or 0))
        mins=max(1,int(d.get('refresh_interval_minutes') or 1440))
        return enabled,mins

    # ---------------- External Data Sources ----------------
    def _data_source_connect(self, d):
        typ=(d.get('db_type') or 'sqlserver').lower()
        if typ=='sqlite':
            path=d.get('database_name') or d.get('host')
            if not path: raise RuntimeError('مسیر فایل SQLite وارد نشده است.')
            conn=sqlite3.connect(path, timeout=10)
            conn.row_factory=sqlite3.Row
            return conn, 'sqlite'
        try:
            import pyodbc
        except ImportError:
            raise RuntimeError('کتابخانه pyodbc نصب نیست. برای SQL Server/ODBC ابتدا pyodbc را نصب کنید.')
        cs=d.get('connection_string','').strip()
        if not cs:
            driver=d.get('driver','').strip()
            host=d.get('host','').strip()
            port=d.get('port','').strip()
            db=d.get('database_name','').strip()
            user=d.get('username','')
            pwd=d.get('password','')
            if typ=='sqlserver':
                driver=driver or 'ODBC Driver 18 for SQL Server'
                server=host + (','+port if port else '')
                cs=f'DRIVER={{{driver}}};SERVER={server};DATABASE={db};UID={user};PWD={pwd};TrustServerCertificate=yes;'
            else:
                if not driver: raise RuntimeError('ODBC Driver را وارد کنید.')
                cs=f'DRIVER={{{driver}}};SERVER={host};'+(f'PORT={port};' if port else '')+f'DATABASE={db};UID={user};PWD={pwd};'
        conn=pyodbc.connect(cs, timeout=10)
        return conn, 'pyodbc'

    def _data_source_test(self, d):
        conn,kind=self._data_source_connect(d)
        try:
            cur=conn.cursor(); cur.execute('SELECT 1'); cur.fetchone()
            return True, 'اتصال به پایگاه داده با موفقیت برقرار شد.'
        finally:
            conn.close()

    def _data_source_preview(self, d, limit=50):
        query=(d.get('query_text') or '').strip()
        if not query: raise RuntimeError('Query خواندن اطلاعات وارد نشده است.')
        clean=query.strip().rstrip(';').strip()
        if ';' in clean or not (clean.lower().startswith('select ') or clean.lower().startswith('select\n')):
            raise RuntimeError('برای امنیت، Preview فقط Query از نوع SELECT را اجرا می‌کند.')
        query=clean
        conn,kind=self._data_source_connect(d)
        try:
            cur=conn.cursor(); cur.execute(query)
            cols=[x[0] for x in cur.description] if cur.description else []
            rows=cur.fetchmany(limit)
            return cols,rows
        finally:
            conn.close()

    def _show_data_preview(self, d):
        def worker(progress):
            progress(20,'در حال اتصال و اجرای Query...')
            cols,rows=self._data_source_preview(d,50)
            progress(100,f'{len(rows):,} رکورد نمونه خوانده شد.')
            return cols,rows
        def done(res,err):
            if err: messagebox.showerror('خطا در خواندن داده',str(err),parent=self); return
            cols,rows=res
            win=tk.Toplevel(self); win.title('پیش‌نمایش داده‌های شرکت'); win.geometry('1050x520'); win.configure(bg='white')
            tk.Label(win,text='پیش‌نمایش اطلاعات خوانده‌شده از پایگاه داده',bg='white',font=('Tahoma',11,'bold')).pack(anchor='e',padx=20,pady=12)
            frame=tk.Frame(win,bg='white'); frame.pack(fill='both',expand=True,padx=15,pady=5)
            tree=ttk.Treeview(frame,columns=list(range(len(cols))),show='headings')
            for i,c in enumerate(cols): tree.heading(i,text=str(c)); tree.column(i,width=150,anchor='center')
            ys=ttk.Scrollbar(frame,orient='vertical',command=tree.yview); xs=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview); tree.configure(yscrollcommand=ys.set,xscrollcommand=xs.set)
            tree.pack(side='left',fill='both',expand=True); ys.pack(side='right',fill='y'); xs.pack(side='bottom',fill='x')
            for r in rows: tree.insert('', 'end', values=[r[i] for i in range(len(cols))])
            tk.Label(win,text=f'{len(rows):,} رکورد نمونه — برای ارسال واقعی بعداً همین Query به موتور کمپین متصل می‌شود.',bg='white',fg='#475569',font=('Tahoma',9)).pack(anchor='e',padx=20,pady=8)
        self.run_with_progress('خواندن پایگاه داده','در حال دریافت نمونه اطلاعات...',100,worker,done)

    def _data_source_settings(self, d, after_save=None):
        win=tk.Toplevel(self); win.title('تنظیم اتصال پایگاه داده شرکت'); win.geometry('760x760'); win.configure(bg='white')
        outer=tk.Frame(win,bg='white'); outer.pack(fill='both',expand=True,padx=20,pady=15)
        tk.Label(outer,text='تنظیم اتصال پایگاه داده',bg='white',fg=self.colors['primary_dark'],font=('Tahoma',13,'bold')).pack(anchor='e',pady=(0,12))
        vars_={}
        fields=[('نام اتصال','name'),('نوع بانک','db_type'),('Server / Host','host'),('Port','port'),('Database / فایل SQLite','database_name'),('Username','username'),('Password','password'),('ODBC Driver','driver'),('Connection String (اختیاری)','connection_string'),('Query خواندن اطلاعات','query_text'),('ستون موبایل','mobile_column'),('ستون ایمیل','email_column'),('ستون نام','first_name_column'),('ستون نام خانوادگی','last_name_column')]
        for label,key in fields:
            tk.Label(outer,text=label,bg='white',font=('Tahoma',9)).pack(anchor='e',pady=(7,2))
            if key=='db_type':
                v=tk.StringVar(value=d.get(key) or 'sqlserver'); cb=ttk.Combobox(outer,textvariable=v,state='readonly',values=['sqlserver','odbc','sqlite']); cb.pack(fill='x'); vars_[key]=v
            elif key in ('query_text','connection_string'):
                v=tk.Text(outer,height=4 if key=='query_text' else 2,font=('Consolas',9)); v.pack(fill='x'); v.insert('1.0',d.get(key,'') or ''); vars_[key]=v
            else:
                v=tk.StringVar(value=d.get(key,'') or ''); e=tk.Entry(outer,textvariable=v,justify='right',show='*' if key=='password' else ''); e.pack(fill='x'); vars_[key]=v
        tk.Label(outer,text='به‌روزرسانی خودکار اتصال',bg='white',font=('Tahoma',9,'bold')).pack(anchor='e',pady=(14,4))
        auto_var=tk.BooleanVar(value=bool(int(d.get('refresh_enabled') or 0)))
        tk.Checkbutton(outer,text='برنامه به‌صورت خودکار اتصال را بررسی و تازه‌سازی کند',variable=auto_var,bg='white',activebackground='white',anchor='e').pack(anchor='e')
        tk.Label(outer,text='فاصله تازه‌سازی (دقیقه) — 60=ساعتی، 1440=روزانه، 10080=هفتگی',bg='white',fg='#64748b',font=('Tahoma',8)).pack(anchor='e',pady=(5,2))
        refresh_var=tk.StringVar(value=str(d.get('refresh_interval_minutes') or 1440))
        tk.Entry(outer,textvariable=refresh_var,justify='right').pack(fill='x')
        status=tk.StringVar(value=d.get('status','نیازمند تنظیمات'))
        tk.Label(outer,textvariable=status,bg='white',fg='#475569',font=('Tahoma',9,'bold')).pack(anchor='e',pady=10)
        buttons=tk.Frame(outer,bg='white'); buttons.pack(fill='x',pady=10)
        def collect():
            out={}
            for k,v in vars_.items(): out[k]=v.get('1.0','end').strip() if isinstance(v,tk.Text) else v.get().strip()
            try: interval=max(1,int(refresh_var.get().strip() or '1440'))
            except Exception: interval=1440
            out['refresh_enabled']=1 if auto_var.get() else 0
            out['refresh_interval_minutes']=interval
            out['id']=d.get('id'); return out
        def save(test=False):
            x=collect()
            if not x['name']: x['name']='اتصال شرکت'
            now=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            if x.get('id'):
                self.db.q('''UPDATE data_sources SET name=?,db_type=?,host=?,port=?,database_name=?,username=?,password=?,driver=?,connection_string=?,query_text=?,mobile_column=?,email_column=?,first_name_column=?,last_name_column=?,status=?,last_checked='',refresh_enabled=?,refresh_interval_minutes=?,next_refresh=? WHERE id=?''', (x['name'],x['db_type'],x['host'],x['port'],x['database_name'],x['username'],x['password'],x['driver'],x['connection_string'],x['query_text'],x['mobile_column'],x['email_column'],x['first_name_column'],x['last_name_column'],'تنظیم شده — نیازمند تست',x['refresh_enabled'],x['refresh_interval_minutes'],(datetime.now()+timedelta(minutes=x['refresh_interval_minutes'])).strftime('%Y-%m-%d %H:%M:%S') if x['refresh_enabled'] else '',x['id']))
            else:
                cur=self.db.q('''INSERT INTO data_sources(name,db_type,host,port,database_name,username,password,driver,connection_string,query_text,mobile_column,email_column,first_name_column,last_name_column,status,last_checked,refresh_enabled,refresh_interval_minutes,next_refresh) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', (x['name'],x['db_type'],x['host'],x['port'],x['database_name'],x['username'],x['password'],x['driver'],x['connection_string'],x['query_text'],x['mobile_column'],x['email_column'],x['first_name_column'],x['last_name_column'],'تنظیم شده — نیازمند تست','',x['refresh_enabled'],x['refresh_interval_minutes'],(datetime.now()+timedelta(minutes=x['refresh_interval_minutes'])).strftime('%Y-%m-%d %H:%M:%S') if x['refresh_enabled'] else ''))
                x['id']=cur.lastrowid
            d.update(x); status.set('✓ تنظیمات ذخیره شد.')
            if test: test_conn(x)
            elif after_save: after_save()
        def test_conn(x=None):
            x=x or collect()
            def worker(progress): progress(20,'در حال اتصال به پایگاه داده...'); ok,msg=self._data_source_test(x); progress(100,'تست اتصال تمام شد.'); return ok,msg
            def done(res,err):
                if err: status.set('✗ اتصال ناموفق: '+str(err)); return
                ok,msg=res; st='آماده' if ok else 'غیرفعال / خطا'; did=x.get('id')
                if did: self.db.q('UPDATE data_sources SET status=?,last_checked=? WHERE id=?',(st,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),did))
                status.set(('✓ اتصال موفق: ' if ok else '✗ اتصال ناموفق: ')+str(msg));
                if after_save: after_save()
            self.run_with_progress('تست پایگاه داده','در حال بررسی اتصال بدون تغییر داده...',100,worker,done)
        self.button(buttons,'💾 ذخیره تنظیمات',lambda:save(False),True).pack(side='right',padx=4)
        self.button(buttons,'🔌 ذخیره و تست اتصال',lambda:save(True)).pack(side='right',padx=4)
        self.button(buttons,'👁 پیش‌نمایش Query',lambda:self._show_data_preview(collect())).pack(side='right',padx=4)
        self.button(buttons,'بستن',win.destroy).pack(side='left',padx=4)

    def show_data_sources(self):
        self.clear(); self.header('اتصالات پایگاه داده شرکت','خواندن اطلاعات مشتریان/کارکنان از SQL Server یا سایر بانک‌ها برای استفاده در کمپین‌ها')
        top=tk.Frame(self.main,bg=self.colors['bg']); top.pack(fill='x',padx=28,pady=(0,10))
        self.button(top,'➕ اتصال جدید',lambda:self._data_source_settings({},after_save=refresh),True).pack(side='right')
        self.button(top,'ℹ راهنمای استفاده',lambda:messagebox.showinfo('راهنما','برای SQL Server معمولاً نوع بانک را SQL Server، Server و Database را وارد کنید و Query فقط خواندنی بنویسید؛ سپس «ذخیره و تست اتصال» را بزنید. ستون‌های موبایل/ایمیل/نام را هم مشخص کنید تا در مرحله کمپین بتوانیم رکوردها را به پیامک یا ایمیل تبدیل کنیم.',parent=self)).pack(side='right',padx=5)
        wrap=tk.Frame(self.main,bg='white',highlightthickness=1,highlightbackground=self.colors['border']); wrap.pack(fill='both',expand=True,padx=28,pady=5)
        cols=('id','name','type','db','status','checked'); tree=ttk.Treeview(wrap,columns=cols,show='headings')
        for c,t,w in [('id','ID',45),('name','نام اتصال',190),('type','نوع',100),('db','Database',190),('status','وضعیت',190),('checked','آخرین تست',145)]: tree.heading(c,text=t); tree.column(c,width=w,anchor='center')
        tree.tag_configure('ok',foreground='#15803d'); tree.tag_configure('bad',foreground='#dc2626'); tree.tag_configure('pending',foreground='#b45309')
        tree.pack(side='left',fill='both',expand=True,padx=(12,0),pady=12); sb=ttk.Scrollbar(wrap,orient='vertical',command=tree.yview); tree.configure(yscrollcommand=sb.set); sb.pack(side='right',fill='y',padx=(0,12),pady=12)
        def refresh():
            for i in tree.get_children(): tree.delete(i)
            for r in self.db.c.execute('SELECT * FROM data_sources WHERE enabled=1 ORDER BY id DESC').fetchall():
                r=dict(r); st=r['status']; tag='ok' if st=='آماده' else ('bad' if 'غیرفعال' in st or 'خطا' in st else 'pending'); tree.insert('', 'end',iid=str(r['id']),values=(r['id'],r['name'],r['db_type'],r['database_name'],st,r['last_checked']),tags=(tag,))
        def selected():
            sel=tree.selection()
            if not sel:return None
            r=self.db.c.execute('SELECT * FROM data_sources WHERE id=?',(int(sel[0]),)).fetchone(); return dict(r) if r else None
        def settings():
            d=selected()
            if not d: messagebox.showwarning('انتخاب','ابتدا یک اتصال را انتخاب کنید.',parent=self); return
            self._data_source_settings(d,after_save=refresh)
        def test():
            d=selected()
            if not d: messagebox.showwarning('انتخاب','ابتدا یک اتصال را انتخاب کنید.',parent=self); return
            def worker(progress): progress(20,'در حال تست اتصال...'); ok,msg=self._data_source_test(d); progress(100,'تست تمام شد.'); return ok,msg
            def done(res,err):
                if err: messagebox.showerror('خطا',str(err),parent=self); return
                ok,msg=res; st='آماده' if ok else 'غیرفعال / خطا'; self.db.q('UPDATE data_sources SET status=?,last_checked=? WHERE id=?',(st,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),d['id'])); refresh(); messagebox.showinfo('نتیجه تست',('✓ ' if ok else '✗ ')+msg,parent=self)
            self.run_with_progress('تست پایگاه داده','در حال اتصال...',100,worker,done)
        def preview():
            d=selected()
            if d:self._show_data_preview(d)
        actions=tk.Frame(self.main,bg=self.colors['bg']); actions.pack(fill='x',padx=28,pady=10)
        self.button(actions,'⚙ تنظیمات',settings,True).pack(side='right',padx=4); self.button(actions,'🔌 تست اتصال',test).pack(side='right',padx=4); self.button(actions,'👁 پیش‌نمایش داده',preview).pack(side='right',padx=4); self.button(actions,'↻ تازه‌سازی',refresh).pack(side='right',padx=4)
        refresh()

    # ---------------- Device / Channel Manager ----------------
    def _device_save(self, d):
        cfg=json.dumps(d.get('config',{}), ensure_ascii=False)
        self.db.q("""INSERT INTO devices(name,kind,target,provider,config_json,status,enabled,last_checked)
                    VALUES(?,?,?,?,?,?,?,?)
                    ON CONFLICT(kind,target) DO UPDATE SET name=excluded.name,provider=excluded.provider,
                    config_json=excluded.config_json,status=excluded.status,enabled=excluded.enabled,last_checked=excluded.last_checked""",
                  (d.get('name',''),d.get('kind',''),d.get('target',''),d.get('provider',''),cfg,d.get('status','Unknown'),1,d.get('last_checked','')))

    def _device_list(self):
        return self.db.c.execute('SELECT * FROM devices WHERE enabled=1 ORDER BY kind,name').fetchall()

    def _device_delete(self, device_id):
        """Delete a configured channel/device from the device manager."""
        self.db.q('DELETE FROM devices WHERE id=?', (int(device_id),))

    def _find_executable(self, name, configured_key):
        configured=self.db.get(configured_key,'').strip()
        candidates=[]
        if configured: candidates.append(configured)
        found=shutil.which(name)
        if found: candidates.append(found)
        if platform.system()=='Windows':
            if name=='adb':
                candidates += [r'C:\platform-tools\adb.exe', r'C:\Android\platform-tools\adb.exe']
            if name=='gammu':
                candidates += [r'C:\Program Files\Gammu\bin\gammu.exe', r'C:\Program Files (x86)\Gammu\bin\gammu.exe']
        for c in candidates:
            if c and Path(c).exists(): return c
        return None

    def _adb_devices(self):
        adb=self._find_executable('adb','adb_path')
        out=[]
        if not adb:
            # Still show Android USB devices in the UI when ADB is missing.
            # Actual control/sending requires ADB and is never marked ready here.
            if platform.system()=='Windows':
                try:
                    ps="Get-CimInstance Win32_PnPEntity | Where-Object {$_.Name -match 'Android|ADB|MTP'} | Select-Object Name,Manufacturer,PNPDeviceID | ConvertTo-Json -Compress"
                    r=subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-Command',ps],capture_output=True,text=True,timeout=12)
                    raw=(r.stdout or '').strip()
                    if raw:
                        data=json.loads(raw)
                        if isinstance(data,dict): data=[data]
                        for x in data:
                            name=str(x.get('Name') or 'Android USB')
                            pnp=str(x.get('PNPDeviceID') or name)
                            out.append({'kind':'android','name':'Android — '+name,'target':pnp,'provider':'Windows PnP','status':'ADB نیاز دارد','detail':'دستگاه USB دیده شد؛ ADB نصب/تنظیم نشده است.','config':{}})
                except Exception:
                    pass
            return out, 'ADB روی سیستم پیدا نشد.'
        try:
            r=subprocess.run([adb,'devices','-l'],capture_output=True,text=True,timeout=8)
            for line in r.stdout.splitlines()[1:]:
                if not line.strip() or line.startswith('*'): continue
                parts=line.split()
                if len(parts)<2: continue
                serial,state=parts[0],parts[1]
                model='Android'
                for part in parts[2:]:
                    if part.startswith('model:'): model=part.split(':',1)[1].replace('_',' ')
                status='آماده' if state=='device' else ('نیازمند تأیید USB' if state=='unauthorized' else state)
                out.append({'kind':'android','name':f'Android — {model}','target':serial,'provider':'ADB','status':status,'detail':f'ADB: {Path(adb).name}','config':{'adb':adb}})
            return out, ''
        except Exception as e: return out, str(e)

    def _serial_ports(self):
        """Discover COM ports even when pyserial is not installed.
        First use pyserial, then Windows registry, then PowerShell PnP fallback.
        """
        ports=[]
        seen=set()
        def add(device, description='', manufacturer=''):
            if not device or device in seen: return
            seen.add(device)
            ports.append(type('P',(),{'device':device,'description':description or 'COM Port','manufacturer':manufacturer or ''})())
        try:
            import serial.tools.list_ports as list_ports
            for x in list(list_ports.comports()):
                add(getattr(x,'device',''), getattr(x,'description',''), getattr(x,'manufacturer',''))
        except Exception:
            pass
        if platform.system()=='Windows':
            # Registry fallback: works without any third-party Python package.
            try:
                import winreg
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'HARDWARE\DEVICEMAP\SERIALCOMM') as key:
                    i=0
                    while True:
                        try:
                            _,v,_=winreg.EnumValue(key,i); add(v,'Windows Serial COM port',''); i+=1
                        except OSError: break
            except Exception:
                pass
            # PnP fallback gives much better descriptions for USB GSM modems.
            try:
                ps = "Get-CimInstance Win32_PnPEntity | Where-Object {$_.Name -match 'COM[0-9]+'} | Select-Object Name,Manufacturer,PNPDeviceID | ConvertTo-Json -Compress"
                r=subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-Command',ps],capture_output=True,text=True,timeout=12)
                raw=(r.stdout or '').strip()
                if raw:
                    data=json.loads(raw)
                    if isinstance(data,dict): data=[data]
                    for x in data:
                        name=str(x.get('Name') or '')
                        import re as _re
                        m=_re.search(r'\b(COM\d+)\b',name,re.I)
                        if m: add(m.group(1).upper(),name,str(x.get('Manufacturer') or ''))
            except Exception:
                pass
            # Last-resort Windows fallback: MODE lists serial devices without
            # requiring PowerShell, pyserial, or extra packages.
            try:
                r=subprocess.run(['cmd','/c','mode'],capture_output=True,text=True,timeout=5)
                import re as _re
                for m in _re.finditer(r'(?im)^\s*Status for device (COM\d+)\s*:', r.stdout or ''):
                    add(m.group(1).upper(),'Windows MODE serial port','')
            except Exception:
                pass
        return ports

    def _gsm_probe(self, port):
        # Prefer Gammu identify when installed; fallback to pyserial AT probing.
        gammu=self._find_executable('gammu','gammu_path')
        if gammu:
            try:
                r=subprocess.run([gammu,'--device',port+(':' if platform.system()=='Windows' and not port.endswith(':') else ''),'--connection','at','identify'],capture_output=True,text=True,timeout=12)
                text=(r.stdout or '')+'\n'+(r.stderr or '')
                if r.returncode==0 and text.strip():
                    info={}
                    for line in text.splitlines():
                        if ':' in line:
                            k,v=line.split(':',1); info[k.strip().lower()]=v.strip()
                    return True, (info.get('manufacturer','GSM Modem'), info.get('model',''), text.strip()), 'Gammu'
            except Exception: pass
        try:
            import serial
            with serial.Serial(port,9600,timeout=1.5) as ser:
                ser.reset_input_buffer(); ser.write(b'AT\r'); time.sleep(.5)
                resp=ser.read(256).decode(errors='ignore')
                ser.write(b'ATI\r'); time.sleep(.5)
                ident=ser.read(512).decode(errors='ignore')
                ser.write(b'AT+CSQ\r'); time.sleep(.5)
                csq=ser.read(256).decode(errors='ignore')
                if 'OK' in (resp.upper()+ident.upper()):
                    return True, ('GSM Modem', ident.strip() or 'AT modem', f'پاسخ AT دریافت شد\n{csq.strip()}'), 'pyserial'
        except Exception as e:
            return False, ('GSM Modem','',''), str(e)
        return False, ('GSM Modem','','بدون پاسخ AT'), 'AT'

    def _proxy_cfg(self):
        """Return optional application proxy configuration. Direct connection remains the default."""
        enabled = self.db.get('proxy_enabled','0').strip() == '1'
        ptype = self.db.get('proxy_type','SOCKS5').strip().upper() or 'SOCKS5'
        host = self.db.get('proxy_host','').strip()
        try: port = int(self.db.get('proxy_port','1080').strip() or '1080')
        except Exception: port = 1080
        return {'enabled':enabled,'type':ptype,'host':host,'port':port,
                'user':self.db.get('proxy_user',''),'password':self.db.get('proxy_password','')}

    def _proxy_socket(self, host, port, timeout=15):
        """Create a TCP socket to host:port through the configured optional proxy."""
        cfg=self._proxy_cfg()
        if not cfg['enabled']:
            return socket.create_connection((host,port), timeout=timeout)
        if not cfg['host'] or not (1 <= cfg['port'] <= 65535):
            raise RuntimeError('پروکسی فعال است اما Host/Port آن کامل تنظیم نشده است.')
        ptype=cfg['type']
        if ptype == 'HTTP':
            import socket as _socket
            s=_socket.create_connection((cfg['host'],cfg['port']), timeout=timeout)
            s.settimeout(timeout)
            target=f'{host}:{port}'
            auth=''
            if cfg['user']:
                import base64
                raw=f"{cfg['user']}:{cfg['password']}".encode('utf-8')
                auth='Proxy-Authorization: Basic '+base64.b64encode(raw).decode('ascii')+'\r\n'
            req=f'CONNECT {target} HTTP/1.1\r\nHost: {target}\r\n{auth}\r\n'.encode('ascii')
            s.sendall(req)
            data=b''
            while b'\r\n\r\n' not in data and len(data)<65536:
                chunk=s.recv(4096)
                if not chunk: break
                data += chunk
            first=data.split(b'\r\n',1)[0].decode('latin1','replace') if data else ''
            if ' 200 ' not in (' '+first+' '):
                try:s.close()
                except Exception:pass
                raise RuntimeError('پروکسی HTTP تونل CONNECT را نپذیرفت: '+(first or 'پاسخی دریافت نشد'))
            return s
        if ptype == 'SOCKS5':
            try:
                from python_socks.sync import Proxy
                from python_socks import ProxyType
            except ImportError:
                raise RuntimeError('برای Proxy نوع SOCKS5، بسته python-socks نصب نشده است. requirements.txt را نصب کنید.')
            proxy=Proxy.from_url(self._proxy_url(cfg))
            return proxy.connect(dest_host=host, dest_port=port, timeout=timeout)
        raise RuntimeError('نوع Proxy پشتیبانی نمی‌شود: '+ptype)

    def _proxy_url(self,cfg):
        from urllib.parse import quote
        scheme='socks5'
        auth=''
        if cfg.get('user'):
            auth=quote(str(cfg['user']),safe='')+':'+quote(str(cfg.get('password','')),safe='')+'@'
        return f'{scheme}://{auth}{cfg["host"]}:{cfg["port"]}'

    def _urlopen(self, req, timeout=10):
        """Open HTTP/HTTPS requests using the app Proxy only when explicitly enabled.
        When Proxy is disabled, bypass OS/Python environment proxy variables so a
        stale HTTP(S)_PROXY setting cannot cause WinError 10061 while the browser
        itself has direct access.
        """
        cfg=self._proxy_cfg()
        if not cfg['enabled']:
            # Explicitly disable inherited environment proxies.
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
            return opener.open(req, timeout=timeout)
        if cfg['type'] == 'HTTP':
            auth=''
            if cfg['user']:
                import base64
                auth='Basic '+base64.b64encode(f"{cfg['user']}:{cfg['password']}".encode()).decode()
            proxy_url=f'http://{cfg["host"]}:{cfg["port"]}'
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({'http':proxy_url,'https':proxy_url}))
            if auth:
                req.add_header('Proxy-Authorization',auth)
            return opener.open(req, timeout=timeout)
        raise RuntimeError('برای ارتباط HTTP/HTTPS با Proxy نوع SOCKS5، این سرویس در این نسخه به صورت مستقیم تست می‌شود؛ SMTP از SOCKS5 پشتیبانی می‌کند.')

    def _panel_test(self, url, api_key=''):
        headers={'User-Agent':'SMSManager/15'}
        if api_key: headers['Authorization']='Bearer '+api_key
        req=urllib.request.Request(url,headers=headers,method='GET')
        try:
            with self._urlopen(req,timeout=8) as r:
                return True, f'HTTP {r.status}'
        except urllib.error.HTTPError as e:
            return False, f'HTTP {e.code}'
        except Exception as e: return False, str(e)

    def _smtp_test_config(self, cfg, progress=None):
        """Detailed SMTP diagnostic with stage-by-stage progress."""
        cfg = dict(cfg or {})
        host = str(cfg.get('smtp_host') or cfg.get('host') or '').strip()
        user = str(cfg.get('smtp_user') or '').strip()
        pwd = str(cfg.get('smtp_password') or '')
        try:
            port = int(str(cfg.get('smtp_port') or 587).strip())
        except Exception:
            port = 0
        ssl_mode = str(cfg.get('smtp_ssl', '0')).strip() == '1'

        def report(value, text):
            if progress:
                try:
                    progress(value, text)
                except Exception:
                    pass

        def fail(stage, detail, value=100):
            report(value, f'✗ خطا در {stage}')
            return False, f'✗ مرحله {stage}: {detail}'

        report(3, 'مرحله ۱ از ۶ — بررسی تنظیمات SMTP...')
        if not host:
            return fail('۱ — تنظیمات', f'SMTP Host وارد نشده است. مقدار دریافت‌شده: {host!r}')
        if port < 1 or port > 65535:
            return fail('۱ — تنظیمات', f'پورت SMTP نامعتبر است: {port}')
        if not user:
            return fail('۱ — تنظیمات', f'Email / نام کاربری وارد نشده است. مقدار دریافت‌شده: {user!r}')
        if not pwd:
            return fail('۱ — تنظیمات', 'App Password / رمز عبور وارد نشده است.')

        report(15, f'مرحله ۲ از ۶ — بررسی DNS برای {host}...')
        try:
            infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
            if not infos:
                return fail('۲ — DNS', f'برای {host} هیچ آدرس شبکه‌ای پیدا نشد.')
            addresses = []
            for item in infos:
                try:
                    addr = item[4][0]
                    if addr not in addresses:
                        addresses.append(addr)
                except Exception:
                    pass
            dns_detail = ', '.join(addresses[:4]) or 'آدرس پیدا شد'
        except socket.gaierror as e:
            return fail('۲ — DNS', f'نام {host} قابل شناسایی نیست.\nجزئیات: {e}')
        except Exception as e:
            return fail('۲ — DNS', f'{type(e).__name__}: {e}')

        use_proxy=self._proxy_cfg()
        route='از طریق Proxy' if use_proxy['enabled'] else 'اتصال مستقیم'
        report(32, f'مرحله ۳ از ۶ — بررسی اتصال شبکه به {host}:{port} ({route})...')
        try:
            raw_sock=self._proxy_socket(host, port, timeout=10)
            raw_sock.close()
        except TimeoutError as e:
            return fail('۳ — اتصال شبکه (TCP)', f'اتصال به {host}:{port} در ۱۰ ثانیه پاسخ نداد.\nمسیر {route} را بررسی کنید.\nجزئیات: {e}')
        except OSError as e:
            return fail('۳ — اتصال شبکه (TCP)', f'برقراری اتصال به {host}:{port} ممکن نشد.\nمسیر {route} یا فایروال/شبکه را بررسی کنید.\nجزئیات: {e}')
        except Exception as e:
            return fail('۳ — اتصال شبکه (TCP)', str(e))

        report(50, 'مرحله ۴ از ۶ — برقراری ارتباط با سرور SMTP...')
        try:
            raw_sock=self._proxy_socket(host, port, timeout=15)
            if ssl_mode:
                ss=smtplib.SMTP_SSL(timeout=15, context=ssl.create_default_context())
                ss._host=host
                ss.sock=ss.context.wrap_socket(raw_sock, server_hostname=host)
                ss.file=None
                try:
                    code,msg=ss.ehlo()
                    if code >= 400:
                        detail=msg.decode(errors='replace') if isinstance(msg,bytes) else str(msg)
                        return fail('۴ — پاسخ SMTP / EHLO', f'SMTP {code} {detail}')
                    report(76,'مرحله ۵ از ۶ — SSL/TLS برقرار شد؛ بررسی App Password...')
                    report(88,'مرحله ۶ از ۶ — بررسی App Password و احراز هویت Gmail...')
                    try: ss.login(user,pwd)
                    except smtplib.SMTPAuthenticationError as e:
                        detail=e.smtp_error.decode(errors='replace') if isinstance(e.smtp_error,bytes) else str(e.smtp_error)
                        return fail('۶ — احراز هویت',f'Gmail رمز را نپذیرفت. App Password را بررسی کنید.\nSMTP {e.smtp_code}: {detail}')
                finally:
                    try:ss.quit()
                    except Exception:
                        try:ss.close()
                        except Exception:pass
            else:
                ss=smtplib.SMTP(timeout=15)
                ss._host=host; ss.sock=raw_sock; ss.file=None
                try:
                    code,msg=ss.ehlo()
                    if code >= 400:
                        detail=msg.decode(errors='replace') if isinstance(msg,bytes) else str(msg)
                        return fail('۴ — پاسخ SMTP / EHLO',f'SMTP {code} {detail}')
                    report(68,'مرحله ۵ از ۶ — بررسی و برقراری STARTTLS...')
                    if not ss.has_extn('starttls'):
                        return fail('۵ — STARTTLS',f'سرور روی پورت {port} قابلیت STARTTLS اعلام نکرد. برای Gmail معمولاً 587 + STARTTLS یا 465 + SSL استفاده کنید.')
                    try:ss.starttls(context=ssl.create_default_context())
                    except ssl.SSLError as e:return fail('۵ — STARTTLS / TLS',f'رمزنگاری TLS برقرار نشد.\n{e}')
                    code2,msg2=ss.ehlo()
                    if code2 >= 400:
                        detail=msg2.decode(errors='replace') if isinstance(msg2,bytes) else str(msg2)
                        return fail('۵ — STARTTLS / EHLO مجدد',f'SMTP {code2} {detail}')
                    report(88,'مرحله ۶ از ۶ — بررسی App Password و احراز هویت Gmail...')
                    try:ss.login(user,pwd)
                    except smtplib.SMTPAuthenticationError as e:
                        detail=e.smtp_error.decode(errors='replace') if isinstance(e.smtp_error,bytes) else str(e.smtp_error)
                        return fail('۶ — احراز هویت',f'Gmail رمز را نپذیرفت. App Password را بررسی کنید.\nSMTP {e.smtp_code}: {detail}')
                finally:
                    try:ss.quit()
                    except Exception:
                        try:ss.close()
                        except Exception:pass
            report(100, '✓ هر ۶ مرحله با موفقیت انجام شد.')
            return True, (f'✓ اتصال SMTP کاملاً موفق بود.\n'
                          f'مراحل موفق: ۱ تنظیمات → ۲ DNS → ۳ TCP → ۴ SMTP → ۵ SSL/TLS → ۶ احراز هویت\n'
                          f'Host: {host}:{port} | IP: {dns_detail}')
        except TimeoutError as e:
            return fail('۳/۴ — اتصال', f'زمان اتصال تمام شد. احتمالاً شبکه یا VPN اتصال SMTP را مسدود کرده است.\n{e}')
        except smtplib.SMTPAuthenticationError as e:
            detail = e.smtp_error.decode(errors='replace') if isinstance(e.smtp_error, bytes) else str(e.smtp_error)
            return fail('۶ — احراز هویت', f'Gmail رمز را نپذیرفت.\nSMTP {e.smtp_code}: {detail}')
        except smtplib.SMTPNotSupportedError as e:
            return fail('۵ — قابلیت امنیتی', str(e))
        except smtplib.SMTPConnectError as e:
            return fail('۴ — پاسخ SMTP', str(e))
        except smtplib.SMTPServerDisconnected as e:
            return fail('۴ — پاسخ SMTP', str(e))
        except ssl.SSLError as e:
            return fail('۵ — SSL/TLS', str(e))
        except OSError as e:
            return fail('۳/۴ — شبکه', str(e))
        except Exception as e:
            return fail('نامشخص', f'{type(e).__name__}: {e}')

    def _smtp_test(self):
        cfg={k:self.db.get(k,'') for k in ('smtp_host','smtp_port','smtp_user','smtp_password','smtp_from','smtp_ssl')}
        ok,msg=self._smtp_test_config(cfg); self.db.set('smtp_tested','1' if ok else '0'); return ok,msg

    def _email_rows(self):
        rows=[]
        for r in self._device_list():
            d=dict(r)
            if d.get('kind')!='email': continue
            try: d['config']=json.loads(d.get('config_json') or '{}')
            except Exception: d['config']={}
            rows.append(d)
        if not rows and self.db.get('smtp_host','').strip():
            cfg={k:self.db.get(k,'') for k in ('smtp_host','smtp_port','smtp_user','smtp_password','smtp_from','smtp_ssl')}
            label=cfg.get('smtp_from') or cfg.get('smtp_user') or cfg.get('smtp_host') or 'ایمیل قدیمی'
            target=cfg.get('smtp_from') or cfg.get('smtp_user') or ('legacy-'+uuid.uuid4().hex[:8])
            tested=self.db.get('smtp_tested','0')=='1'
            self._device_save({'name':label,'kind':'email','target':target,'provider':'SMTP','status':'آماده' if tested else 'تنظیم شده — نیازمند تست','config':cfg,'last_checked':''})
            rows=[dict(r) for r in self._device_list() if r.get('kind')=='email']
        return rows

    def detect_devices(self):
        devices=[]
        # Android / ADB
        android,adb_error=self._adb_devices(); devices.extend(android)
        # Serial / GSM devices. Detection itself never depends on a previous
        # database snapshot; every click performs a fresh hardware scan.
        ports=self._serial_ports()
        for p in ports:
            port=getattr(p,'device','')
            desc=' '.join(x for x in [getattr(p,'description',''),getattr(p,'manufacturer','')] if x).strip()
            detail=desc or 'Serial COM port'
            likely=any(x in (desc+' '+port).lower() for x in ('wavecom','modem','gsm','huawei','quectel','sierra','simcom','telit','fibocom','usb serial','mobile'))
            # Probe likely modems first. For a small number of COM ports, probe all.
            if likely or len(ports)<=4:
                ok,meta,prov=self._gsm_probe(port)
                if ok:
                    detail=meta[2] if len(meta)>2 else detail
                    name=f'{meta[0]} {meta[1]}'.strip() or f'GSM — {port}'
                    devices.append({'kind':'gsm','name':name,'target':port,'provider':prov,'status':'آماده','detail':detail,'config':{'port':port,'baudrate':9600}})
                    continue
            devices.append({'kind':'serial','name':f'پورت {port}','target':port,'provider':'Windows Serial','status':'شناسایی شد','detail':detail,'config':{'port':port}})
        # Configured SMS panel
        panel_url=self.db.get('panel_url','').strip(); panel_key=self.db.get('panel_api_key','').strip()
        if panel_url:
            devices.append({'kind':'panel','name':'پنل SMS','target':panel_url,'provider':self.db.get('sms_provider','Panel API'),'status':'تنظیم شده — نیازمند تست','detail':'API Key ثبت شده' if panel_key else 'API Key ثبت نشده','config':{'url':panel_url}})
        # SMTP
        devices.extend(self._email_rows())
        # Social channels are always shown, so the user can configure them directly.
        social=[('telegram','Telegram','telegram_bot_token','Bot API رسمی'),('whatsapp','WhatsApp Business','whatsapp_token','Meta Cloud API'),('instagram','Instagram','instagram_token','Meta Graph API'),('bale','Bale','bale_bot_token','API رسمی/سازمانی'),('eitaa','Eitaa','eitaa_token','API رسمی/دسترسی سرویس'),('rubika','Rubika','rubika_token','API رسمی/دسترسی سرویس')]
        for kind,name,key,provider in social:
            token=self.db.get(key,'').strip()
            devices.append({'kind':kind,'name':name,'target':'','provider':provider,'status':'تنظیم شده — نیازمند تست' if token else 'نیازمند تنظیمات','detail':'اطلاعات دسترسی ثبت شده' if token else 'اطلاعات اتصال وارد نشده','config':{}})
        # Save current detection snapshot. Do not invent readiness for APIs.
        stamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        for d in devices:
            d['last_checked']=stamp
            self._device_save(d)
        return devices

    def _test_device(self, d):
        kind=d['kind']; target=d['target']
        if kind=='android':
            adb=d.get('config',{}).get('adb') or self._find_executable('adb','adb_path')
            if not adb: return False,'ADB پیدا نشد.'
            try:
                r=subprocess.run([adb,'-s',target,'get-state'],capture_output=True,text=True,timeout=8)
                return r.returncode==0 and r.stdout.strip()=='device', (r.stdout+r.stderr).strip() or 'Android پاسخ نداد.'
            except Exception as e:return False,str(e)
        if kind=='gsm':
            ok,meta,prov=self._gsm_probe(target); return ok, (meta[2] if len(meta)>2 else 'GSM آماده است')
        if kind=='panel': return self._panel_test(target,self.db.get('panel_api_key','').strip())
        if kind=='email': return self._smtp_test_config(d.get('config',{}))
        if kind=='telegram': return self._telegram_test()
        if kind=='whatsapp':
            token=self.db.get('whatsapp_token','').strip(); pid=self.db.get('whatsapp_phone_number_id','').strip(); ver=self.db.get('whatsapp_graph_version','v23.0').strip()
            if not token or not pid:return False,'Token و Phone Number ID را وارد کنید.'
            try:
                url=f'https://graph.facebook.com/{ver}/{pid}?fields=id,display_phone_number,verified_name'
                req=urllib.request.Request(url,headers={'Authorization':'Bearer '+token})
                with urllib.request.urlopen(req,timeout=10) as r: return True,'اتصال Meta موفق بود: '+r.read().decode('utf-8')[:300]
            except Exception as e:return False,str(e)
        if kind=='instagram':
            token=self.db.get('instagram_token','').strip(); uid=self.db.get('instagram_user_id','').strip()
            if not token:return False,'Instagram Token وارد نشده است.'
            try:
                url='https://graph.instagram.com/me?fields=id,username' if not uid else f'https://graph.instagram.com/{uid}?fields=id,username'
                req=urllib.request.Request(url,headers={'Authorization':'Bearer '+token})
                with urllib.request.urlopen(req,timeout=10) as r:return True,'اتصال Instagram موفق بود: '+r.read().decode('utf-8')[:300]
            except Exception as e:return False,str(e)
        if kind in ('bale','eitaa','rubika'):
            # Real Bot API health-check for Iranian messengers. No message is sent.
            token_key={'bale':'bale_bot_token','eitaa':'eitaa_token','rubika':'rubika_token'}[kind]
            base_key={'bale':'bale_api_base','eitaa':'eitaa_api_base','rubika':'rubika_api_base'}[kind]
            token=self.db.get(token_key,'').strip()
            if not token:
                return False,'توکن / API Key تنظیم نشده است.'
            defaults={
                'bale':'https://tapi.bale.ai',
                'eitaa':'https://eitaayar.ir/api',
                'rubika':'https://botapi.rubika.ir/v3',
            }
            base=(self.db.get(base_key,'').strip() or defaults[kind]).rstrip('/')
            if kind=='bale':
                url=f'{base}/bot{token}/getMe'
            else:
                url=f'{base}/{token}/getMe'
            try:
                req=urllib.request.Request(url, data=b'{}', headers={'Content-Type':'application/json','User-Agent':'SMS-Manager/1.0'}, method='POST')
                timeout=float(self.db.get({'bale':'bale_timeout','eitaa':'eitaa_timeout','rubika':'rubika_timeout'}[kind],'15') or 15)
                with self._urlopen(req,timeout=max(3,min(timeout,60))) as r:
                    raw=r.read().decode('utf-8','replace')
                    try: data=json.loads(raw)
                    except Exception: data=None
                    if isinstance(data,dict):
                        ok=(data.get('ok') is True) or str(data.get('status','')).upper() in ('OK','SUCCESS','TRUE') or (data.get('data') is not None and data.get('error') in (None,''))
                        if ok:
                            return True,f'اتصال واقعی به API {kind.title()} موفق بود. Endpoint: {base}'
                        detail=data.get('description') or data.get('error') or data.get('message') or data.get('status') or raw[:250]
                        return False,f'API پاسخ داد ولی اتصال/توکن تأیید نشد: {detail}'
                    return False,'پاسخ API قابل تشخیص نبود: '+raw[:300]
            except urllib.error.HTTPError as e:
                try: detail=e.read().decode('utf-8','replace')[:400]
                except Exception: detail=str(e)
                if e.code in (401,403):
                    return False,f'🔴 سرور روبیکا در دسترس است، اما Token رد شد. HTTP {e.code}: {detail}'
                return False,f'🟠 سرور روبیکا پاسخ HTTP {e.code} داد: {detail}'
            except urllib.error.URLError as e:
                reason=str(getattr(e,'reason',e))
                proxy_note='اتصال مستقیم برنامه فعال است؛ Proxy محیط سیستم نادیده گرفته شد.' if not self._proxy_cfg()['enabled'] else 'Proxy برنامه فعال است.'
                return False,f'🔴 دسترسی برنامه به API روبیکا برقرار نشد: {reason} | {proxy_note}'
            except Exception as e:
                return False,f'🔴 خطای اتصال به API روبیکا: {e}'
        return False,'این پورت به‌تنهایی کانال ارسال محسوب نمی‌شود.'

    def _set_default_device(self, device_id):
        self.db.q('UPDATE devices SET is_default=0')
        self.db.q('UPDATE devices SET is_default=1 WHERE id=?',(device_id,))
        self.db.set('default_device_id',device_id)

    def _rubika_chat_picker(self, contact_id=None, contact_name=''):
        """Simple, robust Rubika Chat ID discovery window.
        Uses the documented getUpdates endpoint and shows diagnostics in the same window.
        """
        token=self.db.get('rubika_token','').strip()
        if not token:
            messagebox.showwarning('تنظیمات ناقص','ابتدا Token روبیکا را وارد و ذخیره کنید.',parent=self)
            return
        base=(self.db.get('rubika_api_base','').strip() or 'https://botapi.rubika.ir/v3').rstrip('/')
        win=tk.Toplevel(self); win.title('دریافت Chat ID روبیکا'); win.geometry('820x650'); win.configure(bg='white'); win.transient(self); win.grab_set()
        tk.Label(win,text='دریافت خودکار Chat ID روبیکا',bg='white',fg=self.colors['primary_dark'],font=('Tahoma',14,'bold')).pack(anchor='e',padx=22,pady=(18,4))
        tk.Label(win,text='ربات را در روبیکا Start کنید و یک پیام جدید برای آن بفرستید، سپس «دریافت چت‌ها» را بزنید.',bg='white',fg='#64748b',font=('Tahoma',9),wraplength=760,justify='right').pack(anchor='e',padx=22,pady=(0,10))
        body=tk.Frame(win,bg='white'); body.pack(fill='both',expand=True,padx=20,pady=5)
        cols=('name','chat_id','preview'); tree=ttk.Treeview(body,columns=cols,show='headings',height=10)
        tree.heading('name',text='عنوان / فرستنده'); tree.heading('chat_id',text='Chat ID'); tree.heading('preview',text='آخرین پیام')
        tree.column('name',width=190,anchor='e'); tree.column('chat_id',width=300,anchor='w'); tree.column('preview',width=260,anchor='e')
        sy=ttk.Scrollbar(body,orient='vertical',command=tree.yview); tree.configure(yscrollcommand=sy.set); tree.pack(side='left',fill='both',expand=True); sy.pack(side='right',fill='y')
        status=tk.Label(win,text='آماده دریافت...',bg='white',fg='#64748b',font=('Tahoma',9),wraplength=760,justify='right'); status.pack(anchor='e',padx=22,pady=(8,4))
        diag=tk.Text(win,height=8,wrap='word',font=('Consolas',9),bg='#f8fafc',fg='#1f2937',relief='solid',bd=1)
        diag.pack(fill='x',padx=20,pady=(2,8)); diag.insert('1.0','نتیجه فنی اینجا نمایش داده می‌شود. Token هرگز نمایش داده نمی‌شود.'); diag.configure(state='disabled')
        actions=tk.Frame(win,bg='white'); actions.pack(fill='x',padx=20,pady=(2,16))
        discovered={}
        def set_diag(text):
            diag.configure(state='normal'); diag.delete('1.0','end'); diag.insert('1.0',text[:6000]); diag.configure(state='disabled')
        def recursive_chat_id(obj):
            if isinstance(obj,dict):
                for k in ('chat_id','chatId'):
                    v=obj.get(k)
                    if isinstance(v,(str,int)) and str(v).strip(): return str(v).strip()
                for k in ('chat','message','new_message','update'):
                    v=obj.get(k); r=recursive_chat_id(v)
                    if r: return r
            return ''
        def text_from_update(u):
            if not isinstance(u,dict): return ''
            for root in (u,u.get('new_message'),u.get('message')):
                if isinstance(root,dict):
                    for k in ('text','caption'):
                        if root.get(k): return str(root[k])[:180]
            return ''
        def name_from_update(u):
            if not isinstance(u,dict): return 'چت روبیکا'
            candidates=[]
            for root in (u,u.get('new_message'),u.get('message')):
                if isinstance(root,dict):
                    candidates += [root.get('sender'),root.get('chat'),root.get('author')]
            for obj in candidates:
                if isinstance(obj,dict):
                    for k in ('name','title','first_name','username','user_name'):
                        v=str(obj.get(k) or '').strip()
                        if v: return v
            return 'چت روبیکا'
        def extract_updates(data):
            if not isinstance(data,dict): return [], data
            containers=[data]
            for k in ('data','result','response'):
                v=data.get(k)
                if isinstance(v,dict): containers.append(v)
            for c in list(containers):
                for k in ('data','result','response'):
                    v=c.get(k) if isinstance(c,dict) else None
                    if isinstance(v,dict): containers.append(v)
            for c in containers:
                if isinstance(c,dict) and isinstance(c.get('updates'),list): return c['updates'],c
            return [], containers[0]
        def discover():
            tree.delete(*tree.get_children()); discovered.clear()
            status.config(text='در حال اتصال به API روبیکا...',fg='#b45309'); set_diag('در حال اجرای getUpdates ...'); win.update_idletasks()
            def worker():
                payload={'limit':100}
                # Do not use a saved offset automatically; this is a manual discovery action.
                url=f'{base}/{token}/getUpdates'
                req=urllib.request.Request(url,data=json.dumps(payload).encode('utf-8'),headers={'Content-Type':'application/json','User-Agent':'SMS-Manager/1.0'},method='POST')
                try:
                    with self._urlopen(req,timeout=20) as r:
                        raw=r.read().decode('utf-8','replace')
                    try: data=json.loads(raw)
                    except Exception: data=None
                    if not isinstance(data,dict):
                        return False,'پاسخ JSON معتبر نیست.\n\n'+raw[:5000]
                    ups,container=extract_updates(data)
                    rows=[]
                    for u in ups:
                        cid=recursive_chat_id(u)
                        if cid:
                            rows.append((cid,name_from_update(u),text_from_update(u)))
                    return True,(rows,container,raw)
                except urllib.error.HTTPError as e:
                    try: raw=e.read().decode('utf-8','replace')
                    except Exception: raw=str(e)
                    return False,f'HTTP {e.code}\n{raw[:5000]}'
                except urllib.error.URLError as e:
                    return False,f'خطای شبکه\n{getattr(e,"reason",e)}'
                except Exception as e:
                    return False,f'خطای برنامه\n{type(e).__name__}: {e}'
            def finish(result):
                ok,payload=result
                if not ok:
                    status.config(text='❌ دریافت اطلاعات ناموفق بود.',fg='#dc2626'); set_diag(str(payload).replace(token,'***TOKEN***')); return
                rows,container,raw=payload
                for cid,name,preview in rows:
                    if cid not in discovered: discovered[cid]={'name':name,'preview':preview}
                for cid,info in discovered.items(): tree.insert('', 'end', iid=cid, values=(info['name'],cid,info['preview']))
                safe=raw.replace(token,'***TOKEN***')
                if discovered:
                    status.config(text=f'🟢 {len(discovered)} مقصد پیدا شد.',fg='#15803d')
                    set_diag('API پاسخ داد و Chat ID پیدا شد.\n\n'+safe[:3000])
                else:
                    status.config(text='🟠 API پاسخ داد، اما Chat ID در Updateها پیدا نشد.',fg='#b45309')
                    set_diag('هیچ Chat ID قابل استفاده‌ای در updates پیدا نشد.\n\nپاسخ API (بدون Token):\n'+safe[:5000])
            def runner():
                result=worker(); self.after(0,lambda:finish(result))
            threading.Thread(target=runner,daemon=True).start()
        def choose():
            sel=tree.selection()
            if not sel:
                messagebox.showwarning('انتخاب مقصد','یک چت را انتخاب کنید.',parent=win); return
            cid=str(sel[0])
            if contact_id:
                self.db.q('UPDATE contacts SET rubika_chat_id=? WHERE id=?',(cid,contact_id))
                label = contact_name or 'مخاطب'
                messagebox.showinfo('Chat ID مخاطب',f'Chat ID روبیکا برای «{label}» ذخیره شد.\n\nحالا پیش‌نمایش را دوباره باز کنید تا این مخاطب قابل انتخاب و ارسال شود.',parent=win)
            else:
                self.db.set('rubika_chat_id',cid)
                messagebox.showinfo('مقصد ذخیره شد',f'Chat ID زیر برای روبیکا ذخیره شد:\n\n{cid}',parent=win)
            win.destroy()
        self.button(actions,'🔄 دریافت چت‌ها',discover,True).pack(side='right',padx=4)
        self.button(actions,'✓ انتخاب مقصد',choose).pack(side='right',padx=4)
        self.button(actions,'بستن',win.destroy).pack(side='right',padx=4)

    def _send_social_test(self, kind):
        """Send one user-approved test message through an internal messenger API."""
        names={'bale':'بله','eitaa':'ایتا','rubika':'روبیکا'}
        token_key={'bale':'bale_bot_token','eitaa':'eitaa_token','rubika':'rubika_token'}[kind]
        base_key={'bale':'bale_api_base','eitaa':'eitaa_api_base','rubika':'rubika_api_base'}[kind]
        chat_key={'bale':'bale_chat_id','eitaa':'eitaa_chat_id','rubika':'rubika_chat_id'}[kind]
        defaults={'bale':'https://tapi.bale.ai','eitaa':'https://eitaayar.ir/api','rubika':'https://botapi.rubika.ir/v3'}
        token=self.db.get(token_key,'').strip()
        if not token:
            messagebox.showwarning('تنظیمات ناقص',f'ابتدا Token / API Key {names[kind]} را وارد کنید.',parent=self)
            return
        base=(self.db.get(base_key,'').strip() or defaults[kind]).rstrip('/')
        current_chat=self.db.get(chat_key,'').strip()
        win=tk.Toplevel(self); win.title(f'ارسال پیام آزمایشی — {names[kind]}'); win.geometry('520x360'); win.configure(bg='white'); win.transient(self); win.grab_set()
        tk.Label(win,text=f'ارسال پیام آزمایشی {names[kind]}',bg='white',fg=self.colors['primary_dark'],font=('Tahoma',13,'bold')).pack(anchor='e',padx=20,pady=(18,4))
        tk.Label(win,text='این عملیات یک پیام واقعی ارسال می‌کند. قبل از ارسال مقصد و متن را بررسی کنید.',bg='white',fg='#b45309',font=('Tahoma',9)).pack(anchor='e',padx=20,pady=(0,12))
        frm=tk.Frame(win,bg='white'); frm.pack(fill='x',padx=20)
        tk.Label(frm,text='شناسه مقصد / Chat ID',bg='white',font=('Tahoma',9)).pack(anchor='e')
        chat=tk.Entry(frm,justify='right',font=('Tahoma',10)); chat.pack(fill='x',pady=(3,10)); chat.insert(0,current_chat)
        tk.Label(frm,text='متن پیام آزمایشی',bg='white',font=('Tahoma',9)).pack(anchor='e')
        msg=tk.Text(frm,height=7,wrap='word',font=('Tahoma',10)); msg.pack(fill='both',expand=True,pady=(3,8)); msg.insert('1.0',f'پیام آزمایشی از SMS Manager\nکانال: {names[kind]}')
        result=tk.Label(win,text='',bg='white',fg='#64748b',font=('Tahoma',8),wraplength=470,justify='right'); result.pack(anchor='e',padx=20,pady=4)
        actions=tk.Frame(win,bg='white'); actions.pack(fill='x',padx=20,pady=(4,16))
        def send():
            cid=chat.get().strip(); text=msg.get('1.0','end').strip()
            if not cid:
                messagebox.showwarning('شناسه مقصد','شناسه مقصد / Chat ID را وارد کنید.',parent=win); return
            if not text:
                messagebox.showwarning('متن پیام','متن پیام را وارد کنید.',parent=win); return
            if not messagebox.askyesno('تأیید ارسال',f'یک پیام واقعی به مقصد زیر ارسال شود؟\n\n{cid}\n\nاین عملیات قابل بازگشت نیست.',parent=win):
                return
            self.db.set(chat_key,cid)
            def worker(progress):
                progress(25,'در حال اتصال به سرویس...')
                if kind=='rubika':
                    url=f'{base}/{token}/sendMessage'
                    payload=json.dumps({'chat_id':cid,'text':text},ensure_ascii=False).encode('utf-8')
                    req=urllib.request.Request(url,data=payload,headers={'Content-Type':'application/json','User-Agent':'SMS-Manager/1.0'},method='POST')
                elif kind=='eitaa':
                    url=f'{base}/{token}/sendMessage'
                    payload=urllib.parse.urlencode({'chat_id':cid,'text':text}).encode('utf-8')
                    req=urllib.request.Request(url,data=payload,headers={'Content-Type':'application/x-www-form-urlencoded','User-Agent':'SMS-Manager/1.0'},method='POST')
                else:
                    url=f'{base}/bot{token}/sendMessage'
                    payload=json.dumps({'chat_id':cid,'text':text},ensure_ascii=False).encode('utf-8')
                    req=urllib.request.Request(url,data=payload,headers={'Content-Type':'application/json','User-Agent':'SMS-Manager/1.0'},method='POST')
                progress(70,'در حال ارسال پیام...')
                try:
                    with self._urlopen(req,timeout=20) as r:
                        raw=r.read().decode('utf-8','replace')
                    try:data=json.loads(raw)
                    except Exception:data=None
                    if isinstance(data,dict):
                        ok=(data.get('ok') is True) or str(data.get('status','')).upper() in ('OK','SUCCESS','TRUE') or (data.get('error') in (None,'') and data.get('message_id') is not None)
                        detail=data.get('description') or data.get('error') or data.get('message') or data.get('status') or raw[:300]
                        return ok,detail
                    return False,'پاسخ سرویس قابل تشخیص نبود: '+raw[:300]
                except urllib.error.HTTPError as e:
                    try:detail=e.read().decode('utf-8','replace')[:500]
                    except Exception:detail=str(e)
                    return False,f'HTTP {e.code}: {detail}'
                except urllib.error.URLError as e:
                    return False,f'خطای دسترسی شبکه: {getattr(e,"reason",e)}'
                except Exception as e:
                    return False,str(e)
            def done(res,err):
                if err:
                    result.config(text='خطا: '+str(err),fg='#dc2626'); return
                ok,detail=res
                if ok:
                    result.config(text='✓ پیام با موفقیت ارسال شد. '+str(detail),fg='#15803d')
                    messagebox.showinfo('ارسال موفق',f'پیام آزمایشی در {names[kind]} با موفقیت ارسال شد.\n\n{detail}',parent=win)
                else:
                    result.config(text='✗ ارسال ناموفق: '+str(detail),fg='#dc2626')
                    messagebox.showerror('ارسال ناموفق',f'پیام ارسال نشد.\n\n{detail}',parent=win)
            self.run_with_progress('ارسال پیام آزمایشی','در حال ارسال یک پیام واقعی...',100,worker,done)
        self.button(actions,'✉ ارسال پیام',send,True).pack(side='right',padx=4)
        self.button(actions,'بستن',win.destroy).pack(side='right',padx=4)

    def _device_settings(self, d, after_save=None):
        # Open per-device/channel settings. Saving marks the channel as configured but not tested.
        kind=d.get('kind','')
        titles={
            'android':'تنظیمات Android','gsm':'تنظیمات مودم GSM / Wavecom','panel':'تنظیمات پنل SMS',
            'email':'تنظیمات Email / SMTP','telegram':'تنظیمات Telegram','whatsapp':'تنظیمات WhatsApp Business',
            'instagram':'تنظیمات Instagram','bale':'تنظیمات Bale','eitaa':'تنظیمات Eitaa','rubika':'تنظیمات Rubika',
            'serial':'تنظیمات پورت سریال'}
        win=tk.Toplevel(self); win.title(titles.get(kind,'تنظیمات اتصال')); win.geometry('560x560'); win.configure(bg='white'); win.transient(self); win.grab_set()
        tk.Label(win,text=titles.get(kind,'تنظیمات اتصال'),bg='white',fg=self.colors['primary_dark'],font=('Tahoma',13,'bold')).pack(anchor='e',padx=25,pady=(20,5))
        tk.Label(win,text='اطلاعات را وارد کنید، ذخیره کنید و سپس «تست اتصال» را بزنید.',bg='white',fg='#64748b',font=('Tahoma',9)).pack(anchor='e',padx=25,pady=(0,15))
        body=tk.Frame(win,bg='white'); body.pack(fill='both',expand=True,padx=25)
        vars_={}
        def field(label,key,value='',secret=False):
            tk.Label(body,text=label,bg='white',font=('Tahoma',9)).pack(anchor='e',pady=(8,2))
            v=tk.StringVar(value=str(value or '')); e=tk.Entry(body,textvariable=v,justify='right',show='*' if secret else '')
            e.pack(fill='x'); vars_[key]=v

            # Clipboard support for Windows: Ctrl+V/C/X/A and a right-click menu.
            # This is intentionally added to every settings field so users can paste
            # SMTP hosts, Gmail addresses, App Passwords, API tokens, etc.
            def paste(_event=None):
                try:
                    value_clip=e.clipboard_get()
                    e.insert(tk.INSERT, value_clip)
                    return 'break'
                except tk.TclError:
                    return 'break'
            def copy(_event=None):
                try:
                    if e.selection_present():
                        e.clipboard_clear(); e.clipboard_append(e.selection_get())
                    return 'break'
                except tk.TclError:
                    return 'break'
            def cut(_event=None):
                copy()
                try:
                    e.delete(tk.SEL_FIRST, tk.SEL_LAST)
                except tk.TclError:
                    pass
                return 'break'
            def select_all(_event=None):
                e.select_range(0, tk.END); e.icursor(tk.END); return 'break'
            e.bind('<Control-v>', paste); e.bind('<Control-V>', paste)
            e.bind('<Control-c>', copy); e.bind('<Control-C>', copy)
            e.bind('<Control-x>', cut); e.bind('<Control-X>', cut)
            e.bind('<Control-a>', select_all); e.bind('<Control-A>', select_all)
            menu=tk.Menu(e, tearoff=0)
            menu.add_command(label='چسباندن', command=paste)
            menu.add_command(label='کپی', command=copy)
            menu.add_command(label='برش', command=cut)
            menu.add_separator(); menu.add_command(label='انتخاب همه', command=select_all)
            def popup(event):
                try: menu.tk_popup(event.x_root, event.y_root)
                finally: menu.grab_release()
            e.bind('<Button-3>', popup)
            return e
        if kind=='android':
            field('مسیر ADB (اختیاری)','adb_path',self.db.get('adb_path'))
            field('شناسه دستگاه','target',d.get('target',''))
        elif kind in ('gsm','serial'):
            field('پورت COM','target',d.get('target',''))
            field('Baud Rate','baudrate',d.get('config',{}).get('baudrate','9600'))
            field('مسیر Gammu (اختیاری)','gammu_path',self.db.get('gammu_path'))
        elif kind=='panel':
            field('آدرس API پنل','panel_url',self.db.get('panel_url'))
            field('API Key / Token','panel_api_key',self.db.get('panel_api_key'),True)
            field('نام Provider','sms_provider',self.db.get('sms_provider','Panel API'))
        elif kind=='email':
            ecfg=dict(d.get('config',{}) or {})
            field('نام این حساب ایمیل','email_name',d.get('name') or 'ایمیل جدید')
            field('SMTP Host','smtp_host',ecfg.get('smtp_host') or ecfg.get('host') or '')
            field('SMTP Port','smtp_port',ecfg.get('smtp_port','587'))
            field('نام کاربری / Email','smtp_user',ecfg.get('smtp_user',''))
            field('رمز عبور / App Password','smtp_password',ecfg.get('smtp_password',''),True)
            field('Email فرستنده','smtp_from',ecfg.get('smtp_from') or ecfg.get('smtp_user') or '')
            tk.Label(body,text='SSL مستقیم: برای پورت‌هایی مثل 465 مقدار 1 و در غیر این صورت 0',bg='white',fg='#64748b',font=('Tahoma',8)).pack(anchor='e',pady=(8,0))
            field('امنیت SMTP (1=SSL / 0=STARTTLS)','smtp_ssl',ecfg.get('smtp_ssl','0'))
        else:
            # Each social network gets its own real configuration fields.
            token_key={'telegram':'telegram_bot_token','whatsapp':'whatsapp_token','instagram':'instagram_token','bale':'bale_bot_token','eitaa':'eitaa_token','rubika':'rubika_token'}.get(kind)
            if kind=='telegram':
                field('Bot Token','telegram_bot_token',self.db.get('telegram_bot_token'),True)
                field('Chat ID / Username مقصد','telegram_chat_id',self.db.get('telegram_chat_id'))
                field('API Base URL','telegram_api_base',self.db.get('telegram_api_base','https://api.telegram.org'))
                field('Parse Mode (اختیاری)','telegram_parse_mode',self.db.get('telegram_parse_mode','HTML'))
                field('Webhook Secret (اختیاری)','telegram_webhook_secret',self.db.get('telegram_webhook_secret'),True)
            elif kind=='whatsapp':
                field('Meta Access Token','whatsapp_token',self.db.get('whatsapp_token'),True)
                field('Phone Number ID','whatsapp_phone_number_id',self.db.get('whatsapp_phone_number_id'))
                field('WhatsApp Business Account ID','whatsapp_business_account_id',self.db.get('whatsapp_business_account_id'))
                field('Graph API Version','whatsapp_graph_version',self.db.get('whatsapp_graph_version','v23.0'))
                field('Webhook Verify Token (اختیاری)','whatsapp_webhook_verify_token',self.db.get('whatsapp_webhook_verify_token'),True)
                field('Webhook Callback URL (اختیاری)','whatsapp_webhook_callback_url',self.db.get('whatsapp_webhook_callback_url'))
            elif kind=='instagram':
                field('Access Token','instagram_token',self.db.get('instagram_token'),True)
                field('Instagram Professional User ID','instagram_user_id',self.db.get('instagram_user_id'))
                field('Facebook Page ID (در صورت نیاز)','instagram_page_id',self.db.get('instagram_page_id'))
                field('Graph API Version','instagram_graph_version',self.db.get('instagram_graph_version','v23.0'))
                field('Webhook Verify Token (اختیاری)','instagram_webhook_verify_token',self.db.get('instagram_webhook_verify_token'),True)
                field('Webhook Callback URL (اختیاری)','instagram_webhook_callback_url',self.db.get('instagram_webhook_callback_url'))
            elif kind=='bale':
                field('Bot Token / API Key','bale_bot_token',self.db.get('bale_bot_token'),True)
                field('شناسه مقصد / Chat ID','bale_chat_id',self.db.get('bale_chat_id'))
                field('API Base URL','bale_api_base',self.db.get('bale_api_base') or 'https://tapi.bale.ai')
                field('Timeout (ثانیه)','bale_timeout',self.db.get('bale_timeout','15'))
                tk.Label(body,text='تست اتصال فقط getMe را اجرا می‌کند و هیچ پیامی ارسال نمی‌کند.',bg='white',fg='#64748b',font=('Tahoma',8)).pack(anchor='e',pady=(8,0))
            elif kind=='eitaa':
                field('Token / API Key','eitaa_token',self.db.get('eitaa_token'),True)
                field('شناسه مقصد / Chat ID','eitaa_chat_id',self.db.get('eitaa_chat_id'))
                field('API Base URL','eitaa_api_base',self.db.get('eitaa_api_base') or 'https://eitaayar.ir/api')
                field('Timeout (ثانیه)','eitaa_timeout',self.db.get('eitaa_timeout','15'))
                tk.Label(body,text='برای تست اتصال، برنامه از متد getMe استفاده می‌کند؛ ارسال پیام در تست انجام نمی‌شود.',bg='white',fg='#64748b',font=('Tahoma',8)).pack(anchor='e',pady=(8,0))
            elif kind=='rubika':
                field('Bot Token / API Key','rubika_token',self.db.get('rubika_token'),True)
                field('شناسه مقصد / Chat ID','rubika_chat_id',self.db.get('rubika_chat_id'))
                field('API Base URL','rubika_api_base',self.db.get('rubika_api_base') or 'https://botapi.rubika.ir/v3')
                field('Timeout (ثانیه)','rubika_timeout',self.db.get('rubika_timeout','15'))
                tk.Label(body,text='تست اتصال فقط getMe را اجرا می‌کند و هیچ پیامی ارسال نمی‌کند.',bg='white',fg='#64748b',font=('Tahoma',8)).pack(anchor='e',pady=(8,0))
        status=tk.StringVar(value='')
        tk.Label(win,textvariable=status,bg='white',font=('Tahoma',9,'bold')).pack(anchor='e',padx=25,pady=8)
        buttons=tk.Frame(win,bg='white'); buttons.pack(fill='x',padx=25,pady=18)
        def gmail_guide():
            """User-facing Gmail/SMTP setup guide, with special focus on App Password."""
            g=tk.Toplevel(win); g.title('راهنمای تنظیم Gmail / SMTP'); g.geometry('760x700'); g.minsize(620,560); g.configure(bg='white'); g.transient(win)
            tk.Label(g,text='راهنمای تنظیم Gmail برای ارسال ایمیل',bg='white',fg=self.colors['primary_dark'],font=('Tahoma',15,'bold')).pack(anchor='e',padx=24,pady=(20,4))
            tk.Label(g,text='این راهنما مخصوص حساب Gmail است و بخش App Password را مرحله‌به‌مرحله توضیح می‌دهد.',bg='white',fg='#64748b',font=('Tahoma',9)).pack(anchor='e',padx=24,pady=(0,12))
            outer=tk.Frame(g,bg='white'); outer.pack(fill='both',expand=True,padx=18,pady=4)
            canvas=tk.Canvas(outer,bg='white',highlightthickness=0)
            sb=ttk.Scrollbar(outer,orient='vertical',command=canvas.yview); canvas.configure(yscrollcommand=sb.set)
            sb.pack(side='left',fill='y'); canvas.pack(side='right',fill='both',expand=True)
            content=tk.Frame(canvas,bg='white'); cw=canvas.create_window((0,0),window=content,anchor='nw')
            content.bind('<Configure>',lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
            canvas.bind('<Configure>',lambda e: canvas.itemconfigure(cw,width=e.width))
            def section(title, body, accent=None):
                card=tk.Frame(content,bg='#f7fafc',highlightbackground='#dbe4ee',highlightthickness=1)
                card.pack(fill='x',padx=6,pady=6)
                tk.Label(card,text=title,bg='#f7fafc',fg=accent or self.colors['primary_dark'],font=('Tahoma',11,'bold'),justify='right',anchor='e').pack(fill='x',padx=14,pady=(11,5))
                tk.Label(card,text=body,bg='#f7fafc',fg='#26384a',font=('Tahoma',9),justify='right',anchor='e',wraplength=650).pack(fill='x',padx=14,pady=(0,12))
            section('۱) اول احراز هویت دومرحله‌ای Google را فعال کنید',
                    'برای ساخت App Password باید 2-Step Verification روی حساب Google فعال باشد. اگر این گزینه فعال نیست، ابتدا آن را در تنظیمات امنیت حساب Google فعال کنید.')
            section('۲) ساخت App Password — مهم‌ترین مرحله',
                    'در مرورگر وارد حساب Gmail خود شوید و صفحه App Passwords را باز کنید. اگر Google از شما خواست دوباره وارد حساب شوید، اطلاعات حساب را تأیید کنید. سپس یک App Password جدید بسازید و یک نام مثل SMS Manager برای آن انتخاب کنید.')
            section('۳) App Password چیست؟',
                    'App Password رمز اصلی Gmail شما نیست. Google یک کد ۱۶ رقمی مخصوص برنامه تولید می‌کند. همین کد را باید در فیلد «رمز عبور / App Password» برنامه وارد کنید. رمز اصلی Gmail را در این فیلد وارد نکنید.', accent='#b7791f')
            section('۴) کد ۱۶ رقمی را چگونه وارد کنم؟',
                    'کد تولیدشده را Copy کنید و در فیلد «رمز عبور / App Password» Paste کنید. اگر Google کد را با فاصله نمایش داد، برنامه می‌تواند همان مقدار را دریافت کند؛ برای اطمینان بهتر است فاصله‌ها را حذف کنید. این کد را با هیچ شخص دیگری به اشتراک نگذارید.')
            section('۵) تنظیمات پیشنهادی داخل SMS Manager',
                    'SMTP Host: smtp.gmail.com\n\nحالت اول: SMTP Port = 465 و امنیت SMTP = 1 (SSL)\n\nحالت دوم: SMTP Port = 587 و امنیت SMTP = 0 (STARTTLS)\n\nنام کاربری / Email = آدرس کامل Gmail\n\nEmail فرستنده = همان آدرس Gmail\n\nرمز عبور / App Password = کد ۱۶ رقمی Google')
            section('۶) در پایان چه کاری انجام دهم؟',
                    'روی «ذخیره و تست اتصال» کلیک کنید. برنامه مرحله‌به‌مرحله DNS، اتصال شبکه، SMTP، SSL/TLS و احراز هویت را بررسی می‌کند. اگر مشکلی وجود داشته باشد، مشخص می‌کند خطا در کدام مرحله رخ داده است.')
            section('اگر App Password را پیدا نمی‌کنم',
                    'اگر گزینه App Passwords برای شما نمایش داده نمی‌شود، ممکن است 2-Step Verification فعال نباشد یا حساب سازمانی/Workspace، Advanced Protection یا نوع دیگری از تنظیمات امنیتی مانع نمایش آن شده باشد.')
            buttons2=tk.Frame(g,bg='white'); buttons2.pack(fill='x',padx=24,pady=(8,18))
            def open_app_passwords():
                try: webbrowser.open('https://myaccount.google.com/apppasswords')
                except Exception as e: messagebox.showerror('خطا',f'باز کردن صفحه Google انجام نشد.\n{e}',parent=g)
            self.button(buttons2,'🔐 باز کردن صفحه App Passwords گوگل',open_app_passwords,True).pack(side='right',padx=4)
            self.button(buttons2,'بستن راهنما',g.destroy).pack(side='left',padx=4)

        def save(close=False):
            for k,v in vars_.items():
                if kind=='email': continue
                if k not in ('target','baudrate') or kind not in ('android','gsm','serial'):
                    self.db.set(k,v.get().strip())
            cfg=dict(d.get('config',{}) or {})
            if kind=='email':
                cfg={k:vars_[k].get().strip() for k in ('smtp_host','smtp_port','smtp_user','smtp_password','smtp_from','smtp_ssl') if k in vars_}
                name=vars_.get('email_name',tk.StringVar(value=d.get('name') or 'ایمیل جدید')).get().strip() or 'ایمیل جدید'
                target=cfg.get('smtp_from') or cfg.get('smtp_user') or d.get('target') or ('email-'+uuid.uuid4().hex[:10])
                d['name']=name
            else:
                target=vars_.get('target',tk.StringVar(value=d.get('target',''))).get().strip()
                if 'baudrate' in vars_: cfg['baudrate']=vars_['baudrate'].get().strip()
                if 'adb_path' in vars_: cfg['adb_path']=vars_['adb_path'].get().strip()
            self.db.q('''INSERT INTO devices(name,kind,target,provider,config_json,status,enabled,last_checked)
                         VALUES(?,?,?,?,?,?,1,?)
                         ON CONFLICT(kind,target) DO UPDATE SET name=excluded.name,provider=excluded.provider,
                         config_json=excluded.config_json,status=excluded.status,enabled=1,last_checked=excluded.last_checked''',
                      (d.get('name',''),kind,target,d.get('provider',''),json.dumps(cfg,ensure_ascii=False),'تنظیم شده — نیازمند تست',''))
            if kind=='email':
                for k,v in cfg.items(): self.db.set(k,v)
                self.db.set('smtp_tested','0')
                d['target']=target; d['config']=cfg
            status.set('✓ تنظیمات ذخیره شد؛ اکنون تست اتصال را اجرا کنید.')
            if after_save: after_save()
            if close: win.destroy()
        def test():
            # IMPORTANT: test the values currently visible in the form directly.
            # Do not re-read the just-saved email from SQLite here; this prevents
            # a stale/duplicate device row from causing a false "SMTP Host وارد نشده".
            save(False)
            current=dict(d)
            current['config']=dict(d.get('config',{}) or {})
            if kind=='email':
                current['config']={k: vars_[k].get().strip() for k in
                                   ('smtp_host','smtp_port','smtp_user','smtp_password','smtp_from','smtp_ssl')
                                   if k in vars_}
                current['name']=vars_.get('email_name', tk.StringVar(value=d.get('name','ایمیل جدید'))).get().strip()
                current['target']=current['config'].get('smtp_from') or current['config'].get('smtp_user') or d.get('target','')
            elif 'target' in vars_:
                current['target']=vars_['target'].get().strip()
            def worker(progress):
                if kind=='email':
                    progress(2,'آماده‌سازی تشخیص SMTP از اطلاعات همین فرم...')
                    ok,msg=self._smtp_test_config(current.get('config',{}), progress=progress)
                    if ok:
                        progress(100,'✓ تست SMTP با موفقیت کامل شد.')
                    return ok,msg
                progress(20,'در حال تست اتصال...'); ok,msg=self._test_device(current); progress(100,'تست اتصال تمام شد.'); return ok,msg
            def done(res,err):
                if err: status.set('✗ خطا: '+str(err)); return
                ok,msg=res; st='آماده' if ok else 'غیرفعال / خطا'
                self.db.q('UPDATE devices SET status=?,last_checked=? WHERE id=?',(st,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),current.get('id')))
                status.set(('✓ اتصال موفق: ' if ok else '✗ اتصال ناموفق: ')+str(msg))
                if not ok:
                    messagebox.showerror('تشخیص خطای اتصال', str(msg), parent=win)
                if after_save: after_save()
            self.run_with_progress('تست اتصال','در حال بررسی کانال بدون ارسال پیام...',100,worker,done)
        if kind=='email':
            self.button(buttons,'❓ راهنمای تنظیم Gmail',gmail_guide).pack(side='right',padx=4)
        elif kind in ('bale','eitaa','rubika'):
            def social_guide():
                names={'bale':'بله','eitaa':'ایتا','rubika':'روبیکا'}
                bases={'bale':'https://tapi.bale.ai','eitaa':'https://eitaayar.ir/api','rubika':'https://botapi.rubika.ir/v3'}
                g=tk.Toplevel(win); g.title('راهنمای تنظیم '+names[kind]); g.geometry('700x520'); g.configure(bg='white'); g.transient(win)
                tk.Label(g,text='راهنمای تنظیم '+names[kind],bg='white',fg=self.colors['primary_dark'],font=('Tahoma',15,'bold')).pack(anchor='e',padx=24,pady=(20,8))
                text=(
                    '۱) یک Bot Token / API Key معتبر از سرویس موردنظر دریافت کنید.\n'
                    '۲) Token را در همین فرم وارد کنید.\n'
                    f'۳) API Base URL پیش‌فرض: {bases[kind]}\n'
                    '۴) Chat ID / شناسه مقصد را برای ارسال‌های بعدی وارد کنید.\n'
                    '۵) ابتدا «ذخیره و تست همین سرویس» را بزنید. فقط همین سرویس بررسی می‌شود و هیچ کانال دیگری تست نمی‌شود.\n\n'
                    'اگر تست موفق شد، وضعیت سرویس در داشبورد/ارتباطات به «آماده» تغییر می‌کند.\n'
                    'اگر سرویس نیازمند Proxy باشد، از تنظیمات «اتصال و Proxy/VPN» استفاده کنید؛ Proxy اجباری نیست.'
                )
                tk.Message(g,text=text,bg='white',fg='#334155',font=('Tahoma',10),width=620,justify='right').pack(anchor='e',padx=24,pady=12)
                self.button(g,'بستن راهنما',g.destroy).pack(side='left',padx=24,pady=16)
        self.button(buttons,'💾 ذخیره تنظیمات',lambda:save(False),True).pack(side='right',padx=4)
        self.button(buttons,'🔌 ذخیره و تست همین سرویس',test).pack(side='right',padx=4)
        self.button(buttons,'بستن',win.destroy).pack(side='left',padx=4)

    def _test_social_row(self, kind, status_label):
        rows=[dict(r) for r in self._device_list()]
        d=next((x for x in rows if x.get('kind')==kind), None)
        if not d:
            names={'bale':'Bale','eitaa':'Eitaa','rubika':'Rubika','telegram':'Telegram','whatsapp':'WhatsApp Business','instagram':'Instagram'}
            d={'kind':kind,'name':names.get(kind,kind),'target':'','provider':'API','status':'نیازمند تنظیمات','config':{}}
        def worker(progress):
            progress(25,'در حال بررسی تنظیمات...')
            progress(60,'در حال تست API...')
            ok,msg=self._test_device(d)
            progress(100,'بررسی تمام شد.')
            return ok,msg
        def done(res,err):
            if err:
                status_label.config(text='خطا',fg='#dc2626'); return
            ok,msg=res
            status_label.config(text='آماده' if ok else 'خطا',fg='#15803d' if ok else '#dc2626')
            if not ok:
                messagebox.showwarning('تست اتصال',msg,parent=self)
        self.run_with_progress('تست اتصال','در حال بررسی سرویس بدون ارسال پیام...',100,worker,done)

    def _open_social_by_kind(self, kind, refresh_status=None):
        rows=[dict(r) for r in self._device_list()]
        d=next((x for x in rows if x.get('kind')==kind), None)
        if not d:
            names={'bale':'Bale','eitaa':'Eitaa','rubika':'Rubika','telegram':'Telegram','whatsapp':'WhatsApp Business','instagram':'Instagram'}
            d={'kind':kind,'name':names.get(kind,kind),'target':'','provider':'API','status':'نیازمند تنظیمات','config':{}}
        self._device_settings(d,after_save=lambda:self.show_devices(auto_scan=False))

    def _show_social_category(self, title, subtitle, social_items):
        self.clear()
        self.header(title, subtitle)
        wrap=tk.Frame(self.main,bg=self.colors['bg']); wrap.pack(fill='both',expand=True,padx=28,pady=(0,20))
        info=tk.Frame(wrap,bg='white',highlightthickness=1,highlightbackground=self.colors['border']); info.pack(fill='x',pady=(0,12))
        tk.Label(info,text='اصل سادگی: فقط سرویس موردنظر را انتخاب کنید، تنظیمات همان سرویس را وارد کنید و سپس تست اتصال را بزنید.',
                 bg='white',fg='#475569',font=('Tahoma',9),wraplength=850,justify='right').pack(anchor='e',padx=18,pady=12)
        list_frame=tk.Frame(wrap,bg='white',highlightthickness=1,highlightbackground=self.colors['border']); list_frame.pack(fill='x')
        for kind,name,desc in social_items:
            row=tk.Frame(list_frame,bg='#f8fafc'); row.pack(fill='x',padx=10,pady=6)
            left=tk.Frame(row,bg='#f8fafc'); left.pack(side='left',fill='x',expand=True)
            status=tk.StringVar(value=self._social_status(kind))
            tk.Label(left,textvariable=status,bg='#f8fafc',fg='#b45309',font=('Tahoma',8,'bold')).pack(anchor='w',padx=10,pady=(7,0))
            tk.Label(left,text=desc,bg='#f8fafc',fg='#64748b',font=('Tahoma',8)).pack(anchor='w',padx=10,pady=(1,7))
            right=tk.Frame(row,bg='#f8fafc'); right.pack(side='right',fill='x',expand=True)
            tk.Label(right,text=name,bg='#f8fafc',fg=self.colors['text'],font=('Tahoma',11,'bold')).pack(anchor='e',padx=10,pady=(7,0))
            tk.Label(right,text='تنظیمات مستقل و اتصال رسمی',bg='#f8fafc',fg='#64748b',font=('Tahoma',8)).pack(anchor='e',padx=10,pady=(1,7))
            self.button(row,'⚙ تنظیمات',lambda k=kind,sv=status:self._open_social_by_kind(k, refresh_status=sv),True).pack(side='right',padx=(4,8),pady=8)
            self.button(row,'🔌 تست',lambda k=kind,sv=status:self._test_social_row(k,sv)).pack(side='right',padx=4,pady=8)
        back=tk.Frame(wrap,bg=self.colors['bg']); back.pack(fill='x',pady=12)
        self.button(back,'← بازگشت به دستگاه‌ها و کانال‌ها',self.show_devices).pack(side='right')

    def _social_status(self, kind):
        key={'telegram':'telegram_bot_token','whatsapp':'whatsapp_token','instagram':'instagram_token','bale':'bale_bot_token','eitaa':'eitaa_token','rubika':'rubika_token'}.get(kind)
        if not key: return 'بررسی نشده'
        token=self.db.get(key,'').strip()
        if not token: return 'نیازمند تنظیمات'
        row=next((dict(r) for r in self._device_list() if r['kind']==kind),None)
        return (row or {}).get('status','تنظیم شده — نیازمند تست')

    def _open_devices_tab(self, key):
        # Social entries in the sidebar open the same unified communications
        # page and simply select the requested tab. This preserves the original
        # all-in-one device detection workflow while keeping the UI organized.
        self._device_tab_target = key
        self.show_devices()

    def show_internal_socials(self):
        self._open_devices_tab('internal')

    def show_external_socials(self):
        self._open_devices_tab('external')

    def show_devices(self, auto_scan=True):
        self.clear()
        outer=tk.Frame(self.main,bg=self.colors['bg']); outer.pack(fill='both',expand=True)
        canvas=tk.Canvas(outer,bg=self.colors['bg'],highlightthickness=0,bd=0)
        scroll=ttk.Scrollbar(outer,orient='vertical',command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set); scroll.pack(side='right',fill='y'); canvas.pack(side='left',fill='both',expand=True)
        page=tk.Frame(canvas,bg=self.colors['bg']); win=canvas.create_window((0,0),window=page,anchor='nw')
        page.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(win,width=e.width))
        def wheel(e):
            if getattr(e,'delta',0): canvas.yview_scroll(int(-e.delta/120),'units')
            return 'break'
        canvas.bind('<MouseWheel>',wheel); page.bind('<MouseWheel>',wheel)

        head=tk.Frame(page,bg=self.colors['bg']); head.pack(fill='x',padx=28,pady=(20,8))
        tk.Label(head,text='دستگاه‌ها و کانال‌های ارتباطی',bg=self.colors['bg'],fg=self.colors['text'],font=('Tahoma',21,'bold')).pack(anchor='e')
        tk.Label(head,text='همه ارتباطات در یک صفحه؛ «تست اتصال» فقط همان سرویس را بررسی می‌کند و «بررسی کلیه ارتباطات» برای بررسی یکجای همه کانال‌هاست.',bg=self.colors['bg'],fg=self.colors['muted'],font=('Tahoma',9)).pack(anchor='e',pady=(4,0))
        top=tk.Frame(page,bg=self.colors['bg']); top.pack(fill='x',padx=28,pady=(2,10))
        count=tk.StringVar(value='')
        tk.Label(top,textvariable=count,bg=self.colors['bg'],fg=self.colors['primary_dark'],font=('Tahoma',9,'bold')).pack(side='left',padx=10)
        self.button(top,'🔄 شناسایی دستگاه‌ها',lambda:refresh(),True).pack(side='left')
        self.button(top,'🩺 بررسی کلیه ارتباطات',self._test_all_connections).pack(side='left',padx=5)
        self.button(top,'ℹ راهنمای اتصال',self._device_help).pack(side='right',padx=4)
        self.button(top,'⚙ تنظیمات عمومی',self.show_settings).pack(side='right',padx=4)

        notebook=ttk.Notebook(page,height=410); notebook.pack(fill='x',padx=28,pady=5)
        categories=[
            ('📱 دستگاه‌های ارسال پیامک','sms',['android','gsm','serial']),
            ('📧 ایمیل‌ها','email',['email']),
            ('🌐 پنل‌های پیامکی','panel',['panel']),
            ('🇮🇷 شبکه‌های اجتماعی داخلی','internal',['bale','eitaa','rubika']),
            ('🌍 شبکه‌های اجتماعی خارجی','external',['telegram','whatsapp','instagram']),
        ]
        tabs={}; trees={}; current_all=[]; labels={'android':'Android','gsm':'مودم GSM','serial':'پورت سریال','panel':'پنل SMS','email':'Email / SMTP','telegram':'Telegram','whatsapp':'WhatsApp Business','instagram':'Instagram','bale':'Bale','eitaa':'Eitaa','rubika':'Rubika'}

        for title,key,kinds in categories:
            tab=tk.Frame(notebook,bg='white'); notebook.add(tab,text=title); tabs[key]={'page':tab,'kinds':set(kinds)}
            if key in ('internal','external'):
                title2='شبکه‌های اجتماعی داخلی' if key=='internal' else 'شبکه‌های اجتماعی خارجی'
                tk.Label(tab,text=title2,bg='white',fg=self.colors['primary_dark'],font=('Tahoma',12,'bold')).pack(anchor='e',padx=18,pady=(15,3))
                tk.Label(tab,text='هر سرویس تنظیمات و تست اتصال مستقل دارد. برای تغییر تنظیمات روی ⚙ بزنید.',bg='white',fg='#64748b',font=('Tahoma',9)).pack(anchor='e',padx=18,pady=(0,12))
                items=[('bale','Bale','توکن/API و مقصد'),('eitaa','Eitaa','توکن/API و مقصد'),('rubika','Rubika','توکن/API و مقصد')] if key=='internal' else [('telegram','Telegram','Bot Token و Chat ID'),('whatsapp','WhatsApp Business','Meta Token و Phone Number ID'),('instagram','Instagram','Access Token و Professional Account ID')]
                box=tk.Frame(tab,bg='white',highlightthickness=1,highlightbackground=self.colors['border']); box.pack(fill='x',padx=14,pady=(0,16))
                for kind,name,desc in items:
                    row=tk.Frame(box,bg='#f8fafc'); row.pack(fill='x',padx=7,pady=5)
                    status=tk.Label(row,text='بررسی نشده',bg='#f8fafc',fg='#b45309',font=('Tahoma',8,'bold')); status.pack(side='left',padx=5)
                    self.button(row,'تست اتصال',lambda k=kind,st=status:self._test_social_row(k,st)).pack(side='left',padx=3)
                    self.button(row,'✉ ارسال آزمایشی',lambda k=kind:self._send_social_test(k)).pack(side='left',padx=3)
                    if kind=='rubika':
                        self.button(row,'🔍 دریافت چت‌ها',self._rubika_chat_picker).pack(side='left',padx=3)
                    self.button(row,'⚙',lambda k=kind:self._open_social_by_kind(k)).pack(side='left',padx=3)
                    txt=tk.Frame(row,bg='#f8fafc'); txt.pack(side='right',fill='x',expand=True)
                    tk.Label(txt,text=name,bg='#f8fafc',fg=self.colors['text'],font=('Tahoma',10,'bold')).pack(anchor='e')
                    tk.Label(txt,text=desc,bg='#f8fafc',fg='#64748b',font=('Tahoma',8)).pack(anchor='e')
                trees[key]=None
                continue
            bar=tk.Frame(tab,bg='white'); bar.pack(fill='x',padx=10,pady=(8,4))
            local=tk.StringVar(value='0 مورد'); tk.Label(bar,textvariable=local,bg='white',fg=self.colors['primary_dark'],font=('Tahoma',9,'bold')).pack(side='left',padx=8)
            if key=='email':
                def add_email():
                    d={'kind':'email','name':'ایمیل جدید','target':'email-'+uuid.uuid4().hex[:10], 'provider':'SMTP','status':'نیازمند تنظیمات','config':{}}
                    self._device_save(d)
                    self._device_settings(d,after_save=lambda:refresh(False))
                def edit_email():
                    d=selected('email')
                    if not d:
                        messagebox.showwarning('انتخاب','ابتدا یک حساب ایمیل را انتخاب کنید.',parent=self); return
                    self._device_settings(d,after_save=lambda:refresh(False))
                def delete_email():
                    d=selected('email')
                    if not d:
                        messagebox.showwarning('انتخاب','ابتدا یک حساب ایمیل را انتخاب کنید.',parent=self); return
                    name=d.get('name') or d.get('target') or 'حساب ایمیل'
                    if not messagebox.askyesno('حذف حساب ایمیل',f'حساب «{name}» حذف شود؟\n\nاین عملیات فقط همین حساب را از برنامه حذف می‌کند و به خود حساب Gmail آسیبی نمی‌زند.',parent=self):
                        return
                    self._device_delete(d.get('id'))
                    # Keep the legacy/global SMTP settings only while at least one
                    # email account remains. Otherwise _email_rows would recreate
                    # the deleted legacy account on the next refresh.
                    remaining=[dict(r) for r in self._device_list() if dict(r).get('kind')=='email']
                    if not remaining:
                        for k in ('smtp_host','smtp_port','smtp_user','smtp_password','smtp_from','smtp_ssl','smtp_tested'):
                            self.db.set(k,'')
                    refresh(False)
                    status_msg='حساب ایمیل حذف شد.'
                    messagebox.showinfo('حذف حساب ایمیل',status_msg,parent=self)
                self.button(bar,'➕ افزودن ایمیل',add_email,True).pack(side='right',padx=3)
                self.button(bar,'⚙ مشاهده / ویرایش',edit_email).pack(side='right',padx=3)
                self.button(bar,'🗑 حذف انتخابی',delete_email).pack(side='right',padx=3)
            wrap=tk.Frame(tab,bg='white',highlightthickness=1,highlightbackground=self.colors['border']); wrap.pack(fill='both',expand=True,padx=10,pady=(2,8))
            cols=('id','name','type','target','status','default','checked'); tree=ttk.Treeview(wrap,columns=cols,show='headings',selectmode='browse')
            for c,t,w in [('id','ID',45),('name','دستگاه / سرویس',210),('type','نوع',120),('target','پورت / آدرس',220),('status','وضعیت',190),('default','پیش‌فرض',75),('checked','آخرین بررسی',145)]: tree.heading(c,text=t); tree.column(c,width=w,anchor='center')
            tree.tag_configure('ok',foreground='#15803d'); tree.tag_configure('bad',foreground='#dc2626'); tree.tag_configure('pending',foreground='#b45309')
            vsb=ttk.Scrollbar(wrap,orient='vertical',command=tree.yview); hsb=ttk.Scrollbar(wrap,orient='horizontal',command=tree.xview); tree.configure(yscrollcommand=vsb.set,xscrollcommand=hsb.set)
            tree.grid(row=0,column=0,sticky='nsew',padx=(10,0),pady=(10,0)); vsb.grid(row=0,column=1,sticky='ns',pady=(10,0)); hsb.grid(row=1,column=0,sticky='ew',padx=(10,0),pady=(0,10)); wrap.grid_rowconfigure(0,weight=1); wrap.grid_columnconfigure(0,weight=1)
            btns=tk.Frame(tab,bg='white'); btns.pack(fill='x',padx=10,pady=(0,8))
            self.button(btns,'⚙ تنظیمات',lambda k=key:configure(k),True).pack(side='right',padx=3); self.button(btns,'🔌 تست اتصال',lambda k=key:test_selected(k)).pack(side='right',padx=3); self.button(btns,'★ پیش‌فرض',lambda k=key:make_default(k)).pack(side='right',padx=3)
            trees[key]=(tree,local)
            if key=='email':
                tree.bind('<Double-1>', lambda e: edit_email())

        def items_for(key): return [d for d in current_all if d.get('kind') in tabs[key]['kinds']]
        def populate(items):
            current_all[:] = items; count.set(f'{len(items):,} کانال/مورد ثبت‌شده')
            for key,info in trees.items():
                if info is None: continue
                tree,local=info; subset=items_for(key)
                for iid in tree.get_children(): tree.delete(iid)
                for d in subset:
                    st=d.get('status',''); tag='ok' if st=='آماده' else ('bad' if ('نیازمند تنظیمات' in st or 'غیرفعال' in st or 'خطا' in st) else 'pending')
                    tree.insert('', 'end', iid=str(d.get('id','')), values=(d.get('id',''),d.get('name',''),labels.get(d.get('kind'),d.get('kind')),d.get('target',''),st,'✓' if d.get('is_default') else '',d.get('last_checked','')),tags=(tag,))
                local.set(f'{len(subset):,} مورد')
            # Update social row status labels from current DB snapshot.
            for key in ('internal','external'):
                tab=tabs[key]['page']; kinds=tabs[key]['kinds']
                # Find labels by row order; easier and robust: refresh all Label widgets whose text is a known status.
                status_by_kind={d.get('kind'):d.get('status','بررسی نشده') for d in current_all if d.get('kind') in kinds}
                for child in tab.winfo_children():
                    if not isinstance(child,tk.Frame): continue
                    for row in child.winfo_children():
                        if not isinstance(row,tk.Frame): continue
                        # The settings/test buttons carry no kind metadata, so use a custom attribute if present.
                # Status labels are refreshed by explicit row attributes below.
            if hasattr(self,'_social_status_labels'):
                for kind,lab in self._social_status_labels.items():
                    lab.config(text=next((d.get('status','بررسی نشده') for d in current_all if d.get('kind')==kind),'بررسی نشده'))

        def selected(key):
            info=trees.get(key); 
            if not info:return None
            sel=info[0].selection()
            if not sel:return None
            return next((d for d in current_all if str(d.get('id',''))==str(sel[0])),None)
        def configure(key):
            d=selected(key)
            if not d: messagebox.showwarning('انتخاب','ابتدا یک مورد را انتخاب کنید.',parent=self); return
            self._device_settings(d,after_save=lambda:refresh(False))
        def test_selected(key):
            d=selected(key)
            if not d: messagebox.showwarning('انتخاب','ابتدا یک مورد را انتخاب کنید.',parent=self); return
            def worker(progress): progress(20,'در حال تست اتصال...'); ok,msg=self._test_device(d); progress(100,'تست تمام شد.'); return ok,msg
            def done(res,err):
                if err: messagebox.showerror('خطا',str(err),parent=self); return
                ok,msg=res; st='آماده' if ok else 'غیرفعال / خطا'; self.db.q('UPDATE devices SET status=?,last_checked=? WHERE id=?',(st,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),d['id'])); refresh(False); messagebox.showinfo('نتیجه تست',('✓ اتصال موفق\n' if ok else '✗ اتصال ناموفق\n')+str(msg),parent=self)
            self.run_with_progress('تست اتصال','در حال بررسی ارتباط بدون ارسال پیام...',100,worker,done)
        def make_default(key):
            d=selected(key)
            if not d:return
            if d.get('status')!='آماده': messagebox.showwarning('کانال غیرفعال','فقط کانالی که تست آن موفق بوده می‌تواند پیش‌فرض شود.',parent=self); return
            self._set_default_device(d['id']); refresh(False)

        def refresh(show_progress=True):
            def worker(progress):
                progress(5,'شروع شناسایی Android و پورت‌های COM...'); android,adb_err=self._adb_devices(); progress(25,f'Android: {len(android):,} مورد')
                ports=self._serial_ports(); progress(40,f'پورت‌های COM: {len(ports):,} مورد'); items=list(android); total=max(1,len(ports))
                for i,p in enumerate(ports,1):
                    port=getattr(p,'device',''); desc=' '.join(x for x in [getattr(p,'description',''),getattr(p,'manufacturer','')] if x).strip(); likely=any(x in (desc+' '+port).lower() for x in ('wavecom','modem','gsm','huawei','quectel','sierra','simcom','telit','fibocom','usb serial','mobile'))
                    if likely or len(ports)<=4:
                        ok,meta,prov=self._gsm_probe(port)
                        if ok: items.append({'kind':'gsm','name':f'{meta[0]} {meta[1]}'.strip() or f'GSM — {port}','target':port,'provider':prov,'status':'آماده','detail':meta[2] if len(meta)>2 else desc,'config':{'port':port,'baudrate':9600}})
                        else: items.append({'kind':'serial','name':f'پورت {port}','target':port,'provider':'Windows Serial','status':'شناسایی شد','detail':desc or 'پورت COM شناسایی شد','config':{'port':port}})
                    else: items.append({'kind':'serial','name':f'پورت {port}','target':port,'provider':'Windows Serial','status':'شناسایی شد','detail':desc or 'پورت COM شناسایی شد','config':{'port':port}})
                    progress(40+35*i/total,f'بررسی {port} ({i}/{total})')
                stamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S'); panel_url=self.db.get('panel_url','').strip(); panel_key=self.db.get('panel_api_key','').strip()
                if panel_url: items.append({'kind':'panel','name':'پنل SMS','target':panel_url,'provider':self.db.get('sms_provider','Panel API'),'status':'تنظیم شده — نیازمند تست','detail':'API Key ثبت شده' if panel_key else 'API Key ثبت نشده','config':{'url':panel_url}})
                items.extend(self._email_rows())
                for kind,name,key,provider in [('telegram','Telegram','telegram_bot_token','Bot API رسمی'),('whatsapp','WhatsApp Business','whatsapp_token','Meta Cloud API'),('instagram','Instagram','instagram_token','Meta Graph API'),('bale','Bale','bale_bot_token','API رسمی/سازمانی'),('eitaa','Eitaa','eitaa_token','API رسمی/دسترسی سرویس'),('rubika','Rubika','rubika_token','API رسمی/دسترسی سرویس')]:
                    token=self.db.get(key,'').strip(); items.append({'kind':kind,'name':name,'target':'','provider':provider,'status':'تنظیم شده — نیازمند تست' if token else 'نیازمند تنظیمات','detail':'اطلاعات دسترسی ثبت شده' if token else 'اطلاعات اتصال وارد نشده','config':{}})
                progress(85,'در حال ثبت نتیجه شناسایی...')
                for d in items: d['last_checked']=stamp; self._device_save(d)
                progress(100,f'شناسایی کامل شد: {len(items):,} مورد'); return items,adb_err
            def done(result,err):
                if err: messagebox.showerror('خطا','شناسایی انجام نشد:\n'+str(err),parent=self); return
                rows,adb_err=result or ([], ''); dbrows=[dict(r) for r in self._device_list()]; by_key={(str(r.get('kind')),str(r.get('target'))):r for r in dbrows}
                for x in rows:
                    r=by_key.get((str(x.get('kind')),str(x.get('target'))));
                    if r:x.update(r)
                populate(rows)
                if show_progress and not any(d.get('kind') in ('android','gsm','serial') for d in rows):
                    extra=('\n\nADB: '+adb_err if adb_err else '')
                    messagebox.showwarning('نتیجه شناسایی','هیچ Android یا پورت COM پیدا نشد.\n\nAndroid: USB Debugging و ADB را بررسی کنید.\nمودم: در Device Manager بخش Ports (COM & LPT) را بررسی کنید.'+extra,parent=self)
            if show_progress: self.run_with_progress('شناسایی دستگاه‌ها','در حال بررسی واقعی دستگاه‌ها، پورت‌ها و کانال‌ها...',100,worker,done)
            else:
                try: rows,err=worker(lambda *_:None); done((rows,err),None)
                except Exception as e: done(None,e)

        self._social_status_labels={}
        # Store status labels so refresh can update them without reconstructing the tabs.
        for key in ('internal','external'):
            tab=tabs[key]['page']
            for child in tab.winfo_children():
                if isinstance(child,tk.Frame):
                    for row in child.winfo_children():
                        if isinstance(row,tk.Frame):
                            # identify the status label by its current text
                            for w in row.winfo_children():
                                if isinstance(w,tk.Label) and w.cget('text')=='بررسی نشده':
                                    # map rows by the order of the services
                                    pass
        # Robustly tag the status labels by scanning the service rows in order.
        for key,order in [('internal',['bale','eitaa','rubika']),('external',['telegram','whatsapp','instagram'])]:
            tab=tabs[key]['page']; idx=0
            for child in tab.winfo_children():
                if isinstance(child,tk.Frame):
                    for row in child.winfo_children():
                        if isinstance(row,tk.Frame) and idx<len(order):
                            for w in row.winfo_children():
                                if isinstance(w,tk.Label) and w.cget('text')=='بررسی نشده': self._social_status_labels[order[idx]]=w; idx+=1; break

        # Select requested sidebar tab after construction.
        target=getattr(self,'_device_tab_target',None); self._device_tab_target=None
        if auto_scan:
            refresh(True)
        else:
            # Rebuild the screen from the saved DB snapshot only. Do not scan
            # Android/COM/SMS/other APIs when the user merely tested one channel.
            try:
                rows=[dict(r) for r in self._device_list()]
                populate(rows)
            except Exception:
                pass
        if target in tabs:
            for i,(_,key,_) in enumerate(categories):
                if key==target: notebook.select(i); break

    def _test_all_connections(self):
        """Test all configured/registered communication channels explicitly.
        This is the only action intended to run a broad connection check.
        It does not rediscover hardware; it tests the current saved device rows.
        """
        rows=[dict(r) for r in self._device_list()]
        testable=[]
        for d in rows:
            kind=d.get('kind','')
            status=d.get('status','') or ''
            # Skip rows that are only placeholders / unconfigured entries.
            if status in ('نیازمند تنظیمات','بررسی نشده'):
                continue
            if kind=='serial':
                continue
            if kind in ('android','gsm','panel','email','telegram','whatsapp','instagram','bale','eitaa','rubika'):
                testable.append(d)
        if not testable:
            messagebox.showinfo('بررسی کلیه ارتباطات','هیچ کانال تنظیم‌شده‌ای برای بررسی وجود ندارد.\nابتدا کانال‌های موردنظر را تنظیم کنید.',parent=self)
            return

        def worker(progress):
            results=[]
            total=len(testable)
            for i,d in enumerate(testable,1):
                name=d.get('name') or d.get('kind') or 'کانال'
                progress((i-1)*100/total, f'در حال تست {name} ({i}/{total})...')
                try:
                    ok,msg=self._test_device(d)
                except Exception as e:
                    ok,msg=False,str(e)
                results.append((d,ok,msg))
                st='آماده' if ok else 'غیرفعال / خطا'
                try:
                    self.db.q('UPDATE devices SET status=?,last_checked=? WHERE id=?',
                              (st,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),d.get('id')))
                except Exception:
                    pass
            progress(100,'بررسی کلیه ارتباطات تمام شد.')
            return results

        def done(results,err):
            if err:
                messagebox.showerror('بررسی کلیه ارتباطات',str(err),parent=self)
                return
            results=results or []
            ok_count=sum(1 for _,ok,_ in results if ok)
            bad_count=len(results)-ok_count
            lines=[f'تعداد کانال‌های بررسی‌شده: {len(results)}',f'موفق: {ok_count}',f'ناموفق: {bad_count}','']
            for d,ok,msg in results:
                mark='✓' if ok else '✗'
                short=str(msg).replace('\n',' ')[:180]
                lines.append(f'{mark} {d.get("name",d.get("kind","کانال"))}: {short}')
            try:
                self.show_devices(auto_scan=False)
            except Exception:
                pass
            messagebox.showinfo('نتیجه بررسی کلیه ارتباطات','\n'.join(lines),parent=self)

        self.run_with_progress('بررسی کلیه ارتباطات','در حال تست همه کانال‌های تنظیم‌شده؛ این عملیات فقط با درخواست شما اجرا می‌شود.',100,worker,done)

    def _device_help(self):
        messagebox.showinfo('راهنمای دستگاه‌ها',
            'Android: USB Debugging باید فعال باشد و ADB در برنامه قابل دسترسی باشد. برنامه ابتدا ADB را پیدا می‌کند و سپس adb devices را اجرا می‌کند.\n\n'
            'مودم GSM/Wavecom: دستگاه باید در Ports (COM & LPT) دیده شود. در صورت نصب Gammu، برنامه اطلاعات مدل/IMEI را دقیق‌تر می‌خواند؛ در غیر این صورت AT Probe با pyserial استفاده می‌شود.\n\n'
            'پنل SMS: آدرس API و کلید را در تنظیمات وارد کنید؛ تست فقط اتصال را بررسی می‌کند و پیام ارسال نمی‌کند.\n\n'
            'Email: اطلاعات SMTP را وارد کنید؛ تست شامل اتصال و در صورت وجود، احراز هویت است.\n\n'
            'Telegram/WhatsApp/Instagram و سایر شبکه‌ها فقط از مسیر API رسمی یا اتصال معتبر استفاده می‌شوند و برنامه وضعیت جعلی «آماده ارسال» نشان نمی‌دهد.', parent=self)

    # ---------------- Backup / Restore ----------------
    def _backup_dir(self):
        raw = self.db.get("backup_path")
        d = Path(raw) if raw else (DATA / "backups")
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _backup_enabled(self):
        return self.db.get("backup_auto", "0") == "1"

    def _create_backup(self, destination=None, reason="دستی"):
        """Create a consistent SQLite backup while the application is running."""
        if not self.backup_lock.acquire(blocking=False):
            return None, "پشتیبان‌گیری دیگری در حال انجام است."
        tmp_db = None
        try:
            dest = Path(destination) if destination else self._backup_dir()
            dest.mkdir(parents=True, exist_ok=True)
            if not os.access(str(dest), os.W_OK):
                return None, f"امکان نوشتن در پوشه پشتیبان وجود ندارد: {dest}"
            stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")
            zip_path = dest / f"SMSManager_Backup_{stamp}.zip"
            tmp_db = dest / f".backup_{stamp}.db"

            # Use the application's live SQLite connection. This avoids copying a
            # stale/non-existent DB path and keeps the snapshot transaction-safe.
            dst = sqlite3.connect(str(tmp_db))
            try:
                with self.db.lock:
                    self.db.c.backup(dst)
                dst.commit()
            finally:
                dst.close()

            if not tmp_db.exists() or tmp_db.stat().st_size == 0:
                return None, "فایل Snapshot پایگاه داده ساخته نشد."

            manifest = {
                "created_at": datetime.now().isoformat(timespec="seconds"),
                "reason": reason,
                "application": "SMS Manager",
                "database": "sms_manager.db",
                "database_size": tmp_db.stat().st_size,
                "format": "sqlite-online-backup"
            }
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
                z.write(tmp_db, "data/sms_manager.db")
                z.writestr("backup_info.json", json.dumps(manifest, ensure_ascii=False, indent=2))

            if not zip_path.exists() or zip_path.stat().st_size == 0:
                return None, "فایل ZIP پشتیبان ایجاد نشد."

            self._prune_backups()
            return zip_path, None
        except Exception as e:
            return None, f"خطا در ایجاد پشتیبان: {e}"
        finally:
            try:
                if tmp_db and tmp_db.exists(): tmp_db.unlink()
            except Exception:
                pass
            self.backup_lock.release()

    def _prune_backups(self):
        try:
            keep = int(self.db.get("backup_keep", "20") or 20)
        except Exception:
            keep = 20
        keep = max(1, min(500, keep))
        files = sorted(self._backup_dir().glob("SMSManager_Backup_*.zip"), key=lambda p:p.stat().st_mtime, reverse=True)
        for old in files[keep:]:
            try: old.unlink()
            except Exception: pass

    def _backup_scheduler_start(self):
        def loop():
            while not self.backup_stop.wait(30):
                try:
                    if not self._backup_enabled():
                        continue
                    mins = int(self.db.get("backup_interval", "10") or 10)
                    mins = max(1, min(10080, mins))
                    last = float(self.db.get("backup_last_epoch", "0") or 0)
                    if time.time() - last >= mins * 60:
                        path, err = self._create_backup(reason=f"خودکار هر {mins} دقیقه")
                        if path:
                            self.db.set("backup_last_epoch", str(time.time()))
                            self.db.set("backup_last", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                except Exception:
                    pass
        self.backup_thread = threading.Thread(target=loop, daemon=True)
        self.backup_thread.start()

    def _manual_backup(self):
        def worker(progress):
            progress(20, "در حال ایجاد Snapshot امن از پایگاه داده...")
            path, err = self._create_backup(reason="دستی")
            progress(100, "پشتیبان‌گیری کامل شد." if path else "خطا در پشتیبان‌گیری")
            return path, err
        def done(result, error):
            if error:
                messagebox.showerror("پشتیبان‌گیری", str(error), parent=self); return
            path, err = result
            if err: messagebox.showerror("پشتیبان‌گیری", err, parent=self)
            else:
                self.db.set("backup_last", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                messagebox.showinfo("پشتیبان‌گیری", f"پشتیبان با موفقیت ایجاد شد.\n\n{path}", parent=self)
                self.show_backup()
        self.run_with_progress("پشتیبان‌گیری", "در حال آماده‌سازی...", 100, worker, done)

    def _restore_backup(self):
        path = filedialog.askopenfilename(parent=self, title="انتخاب فایل پشتیبان", filetypes=[("SMS Manager Backup","*.zip"),("ZIP","*.zip")])
        if not path: return
        if not messagebox.askyesno("بازیابی پشتیبان", "با بازیابی، اطلاعات فعلی برنامه با اطلاعات پشتیبان جایگزین می‌شود.\n\nقبل از بازیابی یک پشتیبان اضطراری از وضعیت فعلی ساخته می‌شود. ادامه می‌دهید؟", parent=self): return
        def worker(progress):
            emergency, err = self._create_backup(reason="قبل از بازیابی")
            if err: return None, "ایجاد پشتیبان اضطراری ناموفق بود: " + err
            progress(25, "پشتیبان اضطراری ایجاد شد؛ در حال بررسی فایل...")
            try:
                with zipfile.ZipFile(path, "r") as z:
                    names=z.namelist()
                    dbname="data/sms_manager.db" if "data/sms_manager.db" in names else next((n for n in names if n.endswith("sms_manager.db")), None)
                    if not dbname: return None, "فایل پشتیبان معتبر نیست؛ sms_manager.db داخل آن پیدا نشد."
                    tmp=DATA / ".restore_sms_manager.db"
                    with z.open(dbname) as src, open(tmp,"wb") as dst: shutil.copyfileobj(src,dst)
                progress(65, "فایل بررسی شد؛ در حال جایگزینی امن پایگاه داده...")
                # Close old connection, replace DB, reopen it.
                try: self.db.c.close()
                except Exception: pass
                shutil.copy2(tmp, DB_FILE)
                try: tmp.unlink()
                except Exception: pass
                self.db = DB()
                progress(100, "بازیابی کامل شد.")
                return True, None
            except Exception as e:
                return None, str(e)
        def done(result,error):
            if error: messagebox.showerror("بازیابی", str(error), parent=self); return
            ok,err=result
            if err: messagebox.showerror("بازیابی", err, parent=self)
            else:
                messagebox.showinfo("بازیابی", "اطلاعات با موفقیت بازیابی شد. برنامه برای نمایش اطلاعات جدید بازخوانی می‌شود.", parent=self)
                self.show_dashboard()
        self.run_with_progress("بازیابی پشتیبان", "در حال آماده‌سازی...", 100, worker, done)

    def _choose_backup_dir(self):
        d=filedialog.askdirectory(parent=self, title="انتخاب محل ذخیره پشتیبان‌ها")
        if d:
            self.db.set("backup_path", d); self.show_backup()

    def show_backup(self):
        self.clear(); self.header("پشتیبان‌گیری و بازیابی", "حفاظت از کل اطلاعات برنامه با پشتیبان‌گیری خودکار و بازیابی امن")
        outer=tk.Frame(self.main,bg=self.colors["bg"]); outer.pack(fill="both",expand=True,padx=28,pady=8)
        card=tk.Frame(outer,bg="white",highlightthickness=1,highlightbackground=self.colors["border"]); card.pack(fill="x",pady=6)
        tk.Label(card,text="💾 پشتیبان‌گیری خودکار",bg="white",fg=self.colors["text"],font=("Tahoma",13,"bold")).pack(anchor="e",padx=22,pady=(18,4))
        tk.Label(card,text="می‌توانید برنامه را طوری تنظیم کنید که بدون دخالت کاربر، از کل پایگاه داده در بازه دلخواه نسخه پشتیبان بسازد.",bg="white",fg=self.colors["muted"],font=("Tahoma",9),wraplength=900,justify="right").pack(anchor="e",padx=22,pady=(0,12))
        row=tk.Frame(card,bg="white"); row.pack(fill="x",padx=22,pady=8)
        auto=tk.IntVar(value=1 if self._backup_enabled() else 0)
        tk.Checkbutton(row,text="فعال‌سازی پشتیبان‌گیری خودکار",variable=auto,bg="white",font=("Tahoma",10,"bold"),anchor="e",command=lambda:self.db.set("backup_auto","1" if auto.get() else "0")).pack(side="right")
        tk.Label(row,text="فاصله زمانی:",bg="white",font=("Tahoma",9)).pack(side="right",padx=(25,6))
        interval=ttk.Combobox(row,state="readonly",width=15,values=["5 دقیقه","10 دقیقه","15 دقیقه","30 دقیقه","1 ساعت","6 ساعت","12 ساعت","روزانه"],justify="right")
        vals={"5 دقیقه":"5","10 دقیقه":"10","15 دقیقه":"15","30 دقیقه":"30","1 ساعت":"60","6 ساعت":"360","12 ساعت":"720","روزانه":"1440"}
        rev={v:k for k,v in vals.items()}; interval.set(rev.get(self.db.get("backup_interval","10"),"10 دقیقه")); interval.pack(side="right")
        def save_interval(*_): self.db.set("backup_interval",vals.get(interval.get(),"10"))
        interval.bind("<<ComboboxSelected>>",save_interval)
        exitv=tk.IntVar(value=1 if self.db.get("backup_on_exit","0")=="1" else 0)
        tk.Checkbutton(card,text="هنگام خروج از نرم‌افزار نیز یک پشتیبان کامل بگیر",variable=exitv,bg="white",font=("Tahoma",10),command=lambda:self.db.set("backup_on_exit","1" if exitv.get() else "0")).pack(anchor="e",padx=22,pady=7)
        r2=tk.Frame(card,bg="white");r2.pack(fill="x",padx=22,pady=8)
        tk.Label(r2,text="محل ذخیره:",bg="white",font=("Tahoma",9,"bold")).pack(side="right")
        loc=tk.Label(r2,text=str(self._backup_dir()),bg="#f5f7fb",fg=self.colors["text"],anchor="e",padx=8)
        loc.pack(side="right",fill="x",expand=True,padx=10)
        self.button(r2,"انتخاب محل",self._choose_backup_dir).pack(side="right")
        r3=tk.Frame(card,bg="white");r3.pack(fill="x",padx=22,pady=(4,18))
        tk.Label(r3,text="تعداد نسخه‌های نگهداری‌شده:",bg="white",font=("Tahoma",9)).pack(side="right")
        keep=ttk.Combobox(r3,state="readonly",width=10,values=["5","10","20","50","100"],justify="right");keep.set(self.db.get("backup_keep","20"));keep.pack(side="right",padx=8);keep.bind("<<ComboboxSelected>>",lambda e:self.db.set("backup_keep",keep.get()))
        tk.Label(r3,text="آخرین پشتیبان: "+(self.db.get("backup_last") or "هنوز انجام نشده"),bg="white",fg=self.colors["muted"],font=("Tahoma",9)).pack(side="right",padx=25)
        actions=tk.Frame(outer,bg=self.colors["bg"]);actions.pack(fill="x",pady=12)
        self.button(actions,"💾 پشتیبان‌گیری همین الان",self._manual_backup,True).pack(side="right",padx=5)
        self.button(actions,"♻ بازیابی پشتیبان",self._restore_backup).pack(side="right",padx=5)
        self.button(actions,"📂 باز کردن پوشه پشتیبان‌ها",lambda: os.startfile(str(self._backup_dir())) if platform.system()=="Windows" else None).pack(side="right",padx=5)
        info=tk.Frame(outer,bg="#eef8f3",highlightthickness=1,highlightbackground="#b9dfcc");info.pack(fill="x",pady=8)
        tk.Label(info,text="امنیت اطلاعات",bg="#eef8f3",fg="#17633f",font=("Tahoma",10,"bold")).pack(anchor="e",padx=18,pady=(12,3))
        tk.Label(info,text="هر فایل پشتیبان شامل یک Snapshot سازگار از پایگاه داده است. قبل از هر بازیابی نیز یک پشتیبان اضطراری از وضعیت فعلی ساخته می‌شود تا امکان برگشت وجود داشته باشد.",bg="#eef8f3",fg="#285b47",font=("Tahoma",9),wraplength=1000,justify="right").pack(anchor="e",padx=18,pady=(0,12))

    def _on_close(self):
        self.backup_stop.set()
        if self.db.get("backup_on_exit","0")=="1":
            # Synchronous final backup ensures it completes before process exit.
            path, err = self._create_backup(reason="هنگام خروج")
            if err:
                if not messagebox.askyesno("خروج", "پشتیبان‌گیری هنگام خروج ناموفق بود:\n"+err+"\n\nآیا با این حال از برنامه خارج می‌شوید؟", parent=self): return
        try: self.db.c.close()
        except Exception: pass
        self.destroy()

    def show_settings(self):
        self.clear(); self.header("تنظیمات","تنظیمات عمومی و مسیر اتصال سرویس‌ها")
        outer=tk.Frame(self.main,bg=self.colors["bg"]); outer.pack(fill="both",expand=True,padx=28,pady=8)
        nb=ttk.Notebook(outer); nb.pack(fill="both",expand=True)
        general=tk.Frame(nb,bg="white"); proxy=tk.Frame(nb,bg="white")
        nb.add(general,text="⚙ تنظیمات عمومی"); nb.add(proxy,text="🌐 اتصال و Proxy / VPN")
        # General settings: keep existing behavior, now in its own tab.
        canvas=tk.Canvas(general,bg="white",highlightthickness=0); scroll=ttk.Scrollbar(general,orient="vertical",command=canvas.yview)
        body=tk.Frame(canvas,bg="white"); body.bind("<Configure>",lambda e:canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0),window=body,anchor="nw",width=canvas.winfo_reqwidth() or 900); canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left",fill="both",expand=True); scroll.pack(side="right",fill="y")
        fields=[("نام نرم‌افزار","app_name"),("نام سازمان / مجموعه","company_name")]
        entries={}
        for lab,key in fields:
            tk.Label(body,text=lab,bg="white",font=("Tahoma",9)).pack(anchor="e",padx=35,pady=(11,2))
            e=tk.Entry(body,justify="right")
            e.pack(fill="x",padx=35); e.insert(0,self.db.get(key)); entries[key]=e
        tk.Label(body,text="تنظیمات اتصال Email، SMS، Telegram، WhatsApp و سایر کانال‌ها در بخش «دستگاه‌ها و کانال‌ها» مدیریت می‌شوند و عمداً از اینجا حذف شده‌اند تا تنظیمات عمومی خلوت بماند.",bg="#eef7fc",fg="#31566f",font=("Tahoma",9),wraplength=900,justify="right").pack(fill="x",padx=35,pady=(16,12))
        def save_general():
            app_name=(entries["app_name"].get().strip() or "SMS Manager")
            company=entries["company_name"].get().strip()
            self.db.set("app_name",app_name); self.db.set("company_name",company)
            self.app_name=app_name; self.company_name=company
            self.title(f"{self.app_name} | سامانه مدیریت پیامک، مخاطبین و قرعه‌کشی")
            if hasattr(self,"brand_title_label"):
                self.brand_title_label.configure(text=self.app_name.upper())
            if hasattr(self,"brand_sub_label"):
                self.brand_sub_label.configure(text=(self.company_name or "CRM  •  پیامک  •  مخاطبین"))
            messagebox.showinfo("تنظیمات","✓ تنظیمات ذخیره و اعمال شد.",parent=self)
        self.button(body,"💾 ذخیره و اعمال تنظیمات",save_general,True).pack(anchor="e",padx=35,pady=22)
        # Proxy tab
        pad=tk.Frame(proxy,bg="white"); pad.pack(fill="both",expand=True,padx=28,pady=24)
        tk.Label(pad,text="مدیریت مسیر اتصال اینترنت",bg="white",fg=self.colors["primary_dark"],font=("Tahoma",15,"bold")).pack(anchor="e")
        tk.Label(pad,text="استفاده از Proxy کاملاً اختیاری است. اگر فعال نکنید، برنامه مثل قبل از اتصال عادی سیستم استفاده می‌کند.",bg="white",fg=self.colors["muted"],font=("Tahoma",9),wraplength=900,justify="right").pack(anchor="e",pady=(5,18))
        enabled=tk.IntVar(value=1 if self.db.get('proxy_enabled','0')=='1' else 0)
        tk.Checkbutton(pad,text="استفاده از Proxy برای ارتباطات خارجی",variable=enabled,bg="white",font=("Tahoma",10,"bold"),anchor="e").pack(fill="x",pady=8)
        form=tk.Frame(pad,bg="white"); form.pack(fill="x",pady=8)
        vars={k:tk.StringVar(value=self.db.get(k,default)) for k,default in [('proxy_type','SOCKS5'),('proxy_host',''),('proxy_port','1080'),('proxy_user',''),('proxy_password','')]}
        def row(label,var,show=None,values=None):
            tk.Label(form,text=label,bg="white",font=("Tahoma",9)).pack(anchor="e",pady=(8,2))
            if values:
                w=ttk.Combobox(form,textvariable=var,values=values,state="readonly",justify="right")
            else:
                w=tk.Entry(form,textvariable=var,justify="right",show=show or "")
            w.pack(fill="x"); return w
        row("نوع Proxy",vars['proxy_type'],values=['SOCKS5','HTTP'])
        row("Proxy Host / IP",vars['proxy_host'])
        row("Proxy Port",vars['proxy_port'])
        row("نام کاربری (اختیاری)",vars['proxy_user'])
        row("رمز عبور (اختیاری)",vars['proxy_password'],show='*')
        info=tk.Frame(pad,bg="#eef7fc",highlightthickness=1,highlightbackground="#c8e0ef"); info.pack(fill="x",pady=16)
        tk.Label(info,text="نکته مهم",bg="#eef7fc",fg=self.colors['primary_dark'],font=("Tahoma",10,"bold")).pack(anchor="e",padx=14,pady=(10,3))
        tk.Label(info,text="اگر VPN شما یک Proxy محلی ایجاد می‌کند (مثلاً 127.0.0.1 با یک پورت مشخص)، همان Host و Port را اینجا وارد کنید. اگر VPN کل سیستم را تونل می‌کند، معمولاً نیازی به فعال‌کردن این گزینه نیست.",bg="#eef7fc",fg="#31566f",font=("Tahoma",9),wraplength=900,justify="right").pack(anchor="e",padx=14,pady=(0,10))
        status=tk.StringVar(value="Proxy غیرفعال است؛ اتصال عادی سیستم استفاده می‌شود.")
        tk.Label(pad,textvariable=status,bg="white",fg=self.colors['muted'],font=("Tahoma",9),wraplength=900,justify="right").pack(anchor="e",pady=5)
        def save_proxy():
            try:
                port=int(vars['proxy_port'].get().strip() or '0')
            except Exception: port=0
            if enabled.get() and (not vars['proxy_host'].get().strip() or not (1<=port<=65535)):
                messagebox.showerror("Proxy","برای فعال‌کردن Proxy باید Host و Port معتبر وارد کنید.",parent=self); return
            self.db.set('proxy_enabled','1' if enabled.get() else '0')
            for k,v in vars.items(): self.db.set(k,v.get().strip())
            status.set("✓ تنظیمات Proxy ذخیره شد. مسیر جدید از تست‌های بعدی استفاده می‌شود.")
        def test_proxy():
            save_proxy()
            if not enabled.get():
                status.set("✓ Proxy غیرفعال است؛ تست با اتصال عادی انجام می‌شود."); return
            try:
                sock=self._proxy_socket('www.google.com',443,timeout=10); sock.close()
                status.set("✓ Proxy با موفقیت به اینترنت وصل شد.")
            except Exception as e:
                status.set("✗ تست Proxy ناموفق بود: "+str(e))
        btns=tk.Frame(pad,bg="white"); btns.pack(fill="x",pady=14)
        self.button(btns,"💾 ذخیره Proxy",save_proxy,True).pack(side="right",padx=4)
        self.button(btns,"🔍 تست Proxy",test_proxy).pack(side="right",padx=4)
        tk.Label(pad,text="در نسخه‌های بعدی همین مسیر Proxy به‌صورت مشترک برای سرویس‌های خارجی مانند Telegram / WhatsApp / Instagram نیز استفاده خواهد شد.",bg="white",fg="#64748b",font=("Tahoma",8),wraplength=900,justify="right").pack(anchor="e",pady=(8,0))
    def placeholder(self):messagebox.showinfo("ماژول","این قسمت در نسخه بعدی به سرویس واقعی متصل می‌شود.")
